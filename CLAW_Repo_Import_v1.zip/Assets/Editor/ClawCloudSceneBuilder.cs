#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor.Build;
#if CLAW_PHOTON_FUSION
using Fusion;
#endif

/// <summary>Generates the three prototype scenes before a cloud build. These are blockout scenes, not final art.</summary>
public static class ClawCloudSceneBuilder
{
    private const string Maps = "Assets/CLAW/Maps/";
    private const string Scenes = "Assets/CLAW/Scenes/";
    private struct Spec { public string scene, model; public Vector3 spawn; public Spec(string s,string m,Vector3 p){scene=s;model=m;spawn=p;} }
    private static readonly Spec[] Specs = {
        new Spec("WarehouseLobby","Warehouse_Lobby",new Vector3(0,0.15f,-3f)),
        new Spec("ColdStorage","Cold_Storage",new Vector3(0,0.15f,2f)),
        new Spec("MaintenanceTunnels","Maintenance_Tunnels",new Vector3(0,0.15f,-15f))
    };

    [MenuItem("CLAW/Generate All Prototype Scenes")]
    public static void GenerateFromMenu() { GenerateAllScenes(); }

    public static void GenerateAllScenes()
    {
        Directory.CreateDirectory(Scenes);
        var buildScenes = new EditorBuildSettingsScene[Specs.Length];
        for (int i=0;i<Specs.Length;i++)
        {
            string path = Scenes + Specs[i].scene + ".unity";
            CreateScene(Specs[i], path);
            buildScenes[i] = new EditorBuildSettingsScene(path,true);
        }
        EditorBuildSettings.scenes = buildScenes;
        PlayerSettings.productName = "CLAW";
        PlayerSettings.companyName = "CLAW";
        PlayerSettings.bundleVersion = "0.3.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android,"com.clawvr.game");
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android,ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29;
        AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        Debug.Log("[CLAW] Generated warehouse, cold storage, and maintenance prototype scenes.");
    }

    private static void CreateScene(Spec spec,string scenePath)
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var session = new GameObject("CLAW_Session"); session.AddComponent<ClawGameSession>();
        GameObject map = AssetDatabase.LoadAssetAtPath<GameObject>(Maps + spec.model + ".obj");
        if (map == null) throw new FileNotFoundException("Missing map OBJ: " + Maps + spec.model + ".obj");
        GameObject instance = Object.Instantiate(map); instance.name = spec.model;
        AddStaticMeshColliders(instance);

        var lightGo = new GameObject("AmbientKeyLight");
        Light light = lightGo.AddComponent<Light>(); light.type=LightType.Directional; light.intensity=0.9f;
        lightGo.transform.rotation=Quaternion.Euler(48f,-28f,0f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(.28f,.30f,.34f);

        Vector3 spawn = spec.spawn;
        var spawnObject = new GameObject("PlayerSpawnPoint"); spawnObject.transform.position = spawn;
        var initialiser = new GameObject("CLAW_SceneInitialiser").AddComponent<ClawSceneInitialiser>();
        initialiser.Configure(spec.scene,spawnObject.transform);
#if CLAW_PHOTON_FUSION
        var networkScene=new GameObject("CLAW_NetworkSceneController");
        networkScene.AddComponent<NetworkObject>();
        networkScene.AddComponent<ClawNetworkSceneController>();
#endif
        MakeCheckpoint("SpawnCheckpoint",spawn + Vector3.forward*1.5f);
        MakeCore("SignalCore_A",spawn + new Vector3(-3f,1.25f,5f));
        MakeCore("SignalCore_B",spawn + new Vector3(3f,1.25f,9f));
        MakeCore("SignalCore_C",spawn + new Vector3(0f,2.3f,14f));
        MakeExtractionGate("ExtractionGate",spawn + new Vector3(0f,1.0f,18f));

        if (spec.scene == "WarehouseLobby")
        {
            MakeLabel("CLAW // ABANDONED WAREHOUSE", new Vector3(0,7.7f,8f));
            MakeLabel("TRAINING // FIND 3 SIGNAL CORES", new Vector3(0,3.0f,5f));
            MakePortal("Portal_ColdStorage", "ColdStorage", spawn + new Vector3(-6f,1.4f,1f), new Color(.20f,.65f,.95f));
            MakePortal("Portal_Maintenance", "MaintenanceTunnels", spawn + new Vector3(6f,1.4f,1f), new Color(.65f,.25f,.85f));
        }
        else if (spec.scene == "ColdStorage")
        {
            MakeLabel("CLAW // COLD STORAGE", new Vector3(0,5.8f,6f));
            MakePortal("Portal_Warehouse", "WarehouseLobby", spawn + new Vector3(-5f,1.4f,1f), new Color(.20f,.65f,.95f));
            MakePortal("Portal_Maintenance", "MaintenanceTunnels", spawn + new Vector3(5f,1.4f,1f), new Color(.65f,.25f,.85f));
        }
        else
        {
            MakeLabel("CLAW // MAINTENANCE TUNNELS", new Vector3(0,4.8f,5f));
            MakePortal("Portal_Warehouse", "WarehouseLobby", spawn + new Vector3(-5f,1.4f,1f), new Color(.20f,.65f,.95f));
            MakePortal("Portal_ColdStorage", "ColdStorage", spawn + new Vector3(5f,1.4f,1f), new Color(.20f,.85f,.68f));
        }
        EditorSceneManager.SaveScene(scene,scenePath);
    }

    private static void AddStaticMeshColliders(GameObject root)
    {
        foreach (var filter in root.GetComponentsInChildren<MeshFilter>(true))
        {
            if (filter.sharedMesh==null || filter.GetComponent<Collider>()!=null) continue;
            var collider=filter.gameObject.AddComponent<MeshCollider>(); collider.sharedMesh=filter.sharedMesh;
            GameObjectUtility.SetStaticEditorFlags(filter.gameObject,StaticEditorFlags.BatchingStatic|StaticEditorFlags.OccludeeStatic);
        }
    }

    private static void MakeCore(string name,Vector3 pos)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Sphere); go.name=name; go.transform.position=pos; go.transform.localScale=Vector3.one*.34f;
        go.GetComponent<Renderer>().sharedMaterial=MakeMaterial("SignalCore",new Color(.1f,.85f,.9f));
        var col=go.GetComponent<SphereCollider>(); col.isTrigger=true; go.AddComponent<ClawCollectible>();
    }
    private static void MakeCheckpoint(string name,Vector3 pos)
    {
        var go=new GameObject(name); go.transform.position=pos; var col=go.AddComponent<SphereCollider>(); col.radius=.8f; col.isTrigger=true; go.AddComponent<ClawCheckpoint>();
    }
    private static void MakeExtractionGate(string name,Vector3 pos)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube); go.name=name; go.transform.position=pos; go.transform.localScale=new Vector3(2.2f,2.4f,.25f);
        go.GetComponent<Renderer>().sharedMaterial=MakeMaterial("ExtractionGate",new Color(.2f,.8f,.62f));
        var box=go.GetComponent<BoxCollider>(); box.isTrigger=true; go.AddComponent<ClawExtractionGate>();
        MakeLabel("EXTRACT",pos+Vector3.up*1.6f);
    }
    private static void MakePortal(string name,string destination,Vector3 pos,Color color)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cylinder); go.name=name; go.transform.position=pos; go.transform.rotation=Quaternion.Euler(90f,0f,0f); go.transform.localScale=new Vector3(1.5f,.18f,1.5f);
        go.GetComponent<Renderer>().sharedMaterial=MakeMaterial(name,color);
        var col=go.GetComponent<CapsuleCollider>(); col.isTrigger=true; var portal=go.AddComponent<ClawTravelPortal>(); portal.SetDestination(destination);
        MakeLabel(destination.Replace("Tunnels","Tunnel"),pos+Vector3.up*1.3f);
    }
    private static void MakeLabel(string text,Vector3 pos)
    {
        var go=new GameObject("Label_"+text.Replace(' ','_')); go.transform.position=pos;
        var tm=go.AddComponent<TextMesh>(); tm.text=text; tm.characterSize=.20f; tm.fontSize=56; tm.anchor=TextAnchor.MiddleCenter; tm.alignment=TextAlignment.Center; tm.color=Color.white;
    }
    private static Material MakeMaterial(string key,Color color)
    {
        const string folder="Assets/CLAW/Materials";
        if(!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder("Assets/CLAW","Materials");
        string path=folder+"/"+key+".mat";
        var existing=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(existing!=null) { existing.color=color; EditorUtility.SetDirty(existing); return existing; }
        Shader shader=Shader.Find("Universal Render Pipeline/Lit"); if(shader==null) shader=Shader.Find("Standard");
        var material=new Material(shader){color=color}; AssetDatabase.CreateAsset(material,path); return material;
    }
}
#endif
