#if UNITY_EDITOR
using System.IO;
using System.Collections;
using System.Reflection;
using UnityEditor;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine;
using UnityEngine.XR.Management;

/// <summary>
/// Creates Android XR Plug-in Management settings and assigns Unity OpenXR.
/// The Meta Quest feature group and Touch Plus profile still need enabling in OpenXR settings.
/// </summary>
public static class ClawQuestXRSetup
{
    private const string SettingsAssetPath = "Assets/XR/Settings/XRGeneralSettingsPerBuildTarget.asset";
    private const string OpenXRLoaderType = "UnityEngine.XR.OpenXR.OpenXRLoader";

    [MenuItem("CLAW/Quest/Configure Android OpenXR")]
    public static void ConfigureAndroidOpenXR()
    {
        XRGeneralSettingsPerBuildTarget buildSettings = null;
        EditorBuildSettings.TryGetConfigObject(XRGeneralSettings.k_SettingsKey, out buildSettings);

        if (buildSettings == null)
        {
            string[] guids = AssetDatabase.FindAssets("t:XRGeneralSettingsPerBuildTarget");
            if (guids.Length > 0)
            {
                string existingPath = AssetDatabase.GUIDToAssetPath(guids[0]);
                buildSettings = AssetDatabase.LoadAssetAtPath<XRGeneralSettingsPerBuildTarget>(existingPath);
            }
        }

        if (buildSettings == null)
        {
            Directory.CreateDirectory("Assets/XR/Settings");
            buildSettings = ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();
            AssetDatabase.CreateAsset(buildSettings, SettingsAssetPath);
        }

        EditorBuildSettings.AddConfigObject(XRGeneralSettings.k_SettingsKey, buildSettings, true);

        if (!buildSettings.HasSettingsForBuildTarget(BuildTargetGroup.Android))
            buildSettings.CreateDefaultSettingsForBuildTarget(BuildTargetGroup.Android);

        if (!buildSettings.HasManagerSettingsForBuildTarget(BuildTargetGroup.Android))
            buildSettings.CreateDefaultManagerSettingsForBuildTarget(BuildTargetGroup.Android);

        XRManagerSettings manager = buildSettings.ManagerSettingsForBuildTarget(BuildTargetGroup.Android);
        if (manager == null)
        {
            Debug.LogError("[CLAW] Could not create Android XR Manager settings.");
            return;
        }

        manager.automaticLoading = true;
        manager.automaticRunning = true;

        bool assigned = XRPackageMetadataStore.IsLoaderAssigned(OpenXRLoaderType, BuildTargetGroup.Android)
            || XRPackageMetadataStore.AssignLoader(manager, OpenXRLoaderType, BuildTargetGroup.Android);

        EditorUtility.SetDirty(buildSettings);
        EditorUtility.SetDirty(manager);
        AssetDatabase.SaveAssets();

        if (!assigned)
        {
            Debug.LogError("[CLAW] OpenXR loader assignment failed. Confirm com.unity.xr.openxr finished importing, then run this menu again.");
            return;
        }

        bool metaGroupEnabled = TryEnableMetaQuestFeatureGroup();
        if (metaGroupEnabled)
            Debug.Log("[CLAW] Android OpenXR Loader and Meta Quest feature group configured. Verify controller interaction profile and Android validation before building.");
        else
            Debug.LogWarning("[CLAW] Android OpenXR Loader assigned. Meta Quest feature group was not found automatically; enable it manually in Project Settings > XR Plug-in Management > OpenXR (Android).");
    }

    private static bool TryEnableMetaQuestFeatureGroup()
    {
        Type managerType = FindType("UnityEditor.XR.OpenXR.Features.OpenXRFeatureSetManager");
        if (managerType == null) return false;

        MethodInfo listMethod = managerType.GetMethod("FeatureSetsForBuildTarget", BindingFlags.Public | BindingFlags.Static);
        MethodInfo applyMethod = managerType.GetMethod("SetFeaturesFromEnabledFeatureSets", BindingFlags.Public | BindingFlags.Static);
        if (listMethod == null || applyMethod == null) return false;

        object rawSets = listMethod.Invoke(null, new object[] { BuildTargetGroup.Android });
        if (!(rawSets is IEnumerable sets)) return false;
        bool found = false;
        foreach (object featureSet in sets)
        {
            string name = GetStringMember(featureSet, "name");
            if (string.IsNullOrEmpty(name) || name.IndexOf("Meta Quest", System.StringComparison.OrdinalIgnoreCase) < 0)
                continue;
            SetBoolMember(featureSet, "isEnabled", true);
            found = true;
        }
        if (found) applyMethod.Invoke(null, new object[] { BuildTargetGroup.Android });
        return found;
    }

    private static Type FindType(string fullName)
    {
        foreach (Assembly assembly in System.AppDomain.CurrentDomain.GetAssemblies())
        {
            Type found = assembly.GetType(fullName, false);
            if (found != null) return found;
        }
        return null;
    }

    private static string GetStringMember(object target, string name)
    {
        if (target == null) return null;
        Type type = target.GetType();
        PropertyInfo property = type.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        if (property != null && property.CanRead) return property.GetValue(target, null) as string;
        FieldInfo field = type.GetField(name, BindingFlags.Public | BindingFlags.Instance);
        return field != null ? field.GetValue(target) as string : null;
    }

    private static void SetBoolMember(object target, string name, bool value)
    {
        if (target == null) return;
        Type type = target.GetType();
        PropertyInfo property = type.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        if (property != null && property.CanWrite && property.PropertyType == typeof(bool))
        {
            property.SetValue(target, value, null);
            return;
        }
        FieldInfo field = type.GetField(name, BindingFlags.Public | BindingFlags.Instance);
        if (field != null && field.FieldType == typeof(bool)) field.SetValue(target, value);
    }
}
#endif
