#if UNITY_EDITOR && CLAW_PHOTON_FUSION
using System;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Fusion;

/// <summary>Builds the registered network-avatar prefab. Fusion SDK and Weaver must be installed first.</summary>
public static class ClawNetworkAvatarPrefabBuilder
{
    [MenuItem("CLAW/Networking/Build Network Avatar Prefab")]
    public static void Build()
    {
        const string folder="Assets/Resources";
        if(!AssetDatabase.IsValidFolder(folder))AssetDatabase.CreateFolder("Assets","Resources");
        var root=new GameObject("CLAW_NetworkPlayer");
        root.AddComponent<NetworkObject>();
        root.AddComponent<NetworkTransform>();
        root.AddComponent<ClawNetworkAvatar>();
        root.AddComponent<ClawFusionChatRelay>();
        Transform avatar=new GameObject("Avatar").transform;avatar.SetParent(root.transform,false);
        Material body=Mat(new Color(.30f,.22f,.58f));
        Material face=Mat(new Color(.76f,.83f,.94f));
        Material eyes=Mat(new Color(.08f,.88f,.96f));
        AddPrimitive(PrimitiveType.Sphere,"Body",avatar,new Vector3(0,1.02f,0),new Vector3(.64f,.68f,.46f),body);
        GameObject head=AddPrimitive(PrimitiveType.Sphere,"Head",avatar,new Vector3(0,1.78f,0),new Vector3(.60f,.60f,.58f),body);
        AddPrimitive(PrimitiveType.Cube,"Face",head.transform,new Vector3(0,-.02f,.47f),new Vector3(.37f,.25f,.045f),face);
        AddPrimitive(PrimitiveType.Sphere,"LeftEye",head.transform,new Vector3(-.095f,.035f,.515f),new Vector3(.055f,.065f,.025f),eyes);
        AddPrimitive(PrimitiveType.Sphere,"RightEye",head.transform,new Vector3(.095f,.035f,.515f),new Vector3(.055f,.065f,.025f),eyes);
        AddPrimitive(PrimitiveType.Cylinder,"LeftArm",avatar,new Vector3(-.35f,1.15f,0),new Vector3(.17f,.48f,.17f),body);
        AddPrimitive(PrimitiveType.Cylinder,"RightArm",avatar,new Vector3(.35f,1.15f,0),new Vector3(.17f,.48f,.17f),body);
        AddPrimitive(PrimitiveType.Sphere,"LeftHand",avatar,new Vector3(-.52f,1.05f,0),new Vector3(.2f,.13f,.22f),body);
        AddPrimitive(PrimitiveType.Sphere,"RightHand",avatar,new Vector3(.52f,1.05f,0),new Vector3(.2f,.13f,.22f),body);
        var label=new GameObject("NameLabel");label.transform.SetParent(avatar,false);label.transform.localPosition=new Vector3(0,2.28f,0);
        var tag=label.AddComponent<TextMesh>();tag.text="Player";tag.characterSize=.12f;tag.fontSize=48;tag.anchor=TextAnchor.MiddleCenter;tag.alignment=TextAlignment.Center;tag.color=Color.white;

        AddVoiceComponents(root);
        var prefab=PrefabUtility.SaveAsPrefabAsset(root,folder+"/CLAW_NetworkPlayer.prefab");
        UnityEngine.Object.DestroyImmediate(root);
        AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        Debug.Log("[CLAW] Built "+AssetDatabase.GetAssetPath(prefab)+". Next run Fusion > Rebuild Object Table.");
    }

    private static void AddVoiceComponents(GameObject root)
    {
        Type recorder=FindType("Recorder");
        Type speaker=FindType("Speaker");
        Type voiceNetwork=FindType("VoiceNetworkObject");
        if(recorder!=null)
        {
            var source=root.GetComponent<AudioSource>();if(source==null)source=root.AddComponent<AudioSource>();
            source.spatialBlend=1f;source.rolloffMode=AudioRolloffMode.Logarithmic;source.maxDistance=18f;
            Component rec=root.AddComponent(recorder);
            var tx=recorder.GetProperty("TransmitEnabled");if(tx!=null&&tx.CanWrite)tx.SetValue(rec,false,null);
        }
        if(speaker!=null && root.GetComponent(speaker)==null)root.AddComponent(speaker);
        if(voiceNetwork!=null && root.GetComponent(voiceNetwork)==null)root.AddComponent(voiceNetwork);
    }

    private static Type FindType(string shortName)
    {
        foreach(var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            try
            {
                Type found=assembly.GetTypes().FirstOrDefault(t=>t.Name==shortName);
                if(found!=null)return found;
            }
            catch(ReflectionTypeLoadException ex)
            {
                Type found=ex.Types.FirstOrDefault(t=>t!=null&&t.Name==shortName);
                if(found!=null)return found;
            }
        }
        return null;
    }

    private static GameObject AddPrimitive(PrimitiveType type,string name,Transform parent,Vector3 position,Vector3 scale,Material material)
    {
        var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent,false);
        go.transform.localPosition=position;go.transform.localScale=scale;go.GetComponent<Renderer>().sharedMaterial=material;
        var collider=go.GetComponent<Collider>();if(collider!=null)UnityEngine.Object.DestroyImmediate(collider);
        return go;
    }

    private static Material Mat(Color color)
    {
        var material=new Material(Shader.Find("Universal Render Pipeline/Lit")??Shader.Find("Standard")){color=color};
        return material;
    }
}
#endif
