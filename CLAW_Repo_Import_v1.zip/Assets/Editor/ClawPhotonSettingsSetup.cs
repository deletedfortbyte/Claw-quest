#if UNITY_EDITOR && CLAW_PHOTON_FUSION
using System;
using System.Reflection;
using Fusion.Photon.Realtime;
using UnityEditor;
using UnityEngine;

/// <summary>Applies Photon app IDs already supplied for CLAW. Fusion App ID is intentionally not guessed.</summary>
public static class ClawPhotonSettingsSetup
{
    private const string RealtimeAppId = "fb543344-8340-44db-8cbe-1317a4da2932";
    private const string VoiceAppId = "3dc6b6f5-b032-4561-af6d-f2c0089fbe63";

    [MenuItem("CLAW/Networking/Apply Known Photon App IDs")]
    public static void ApplyKnownIds()
    {
        PhotonAppSettings global = PhotonAppSettings.Global;
        if (global == null)
        {
            string[] guids = AssetDatabase.FindAssets("t:PhotonAppSettings");
            foreach (string guid in guids)
            {
                global = AssetDatabase.LoadAssetAtPath<PhotonAppSettings>(AssetDatabase.GUIDToAssetPath(guid));
                if (global != null) break;
            }
        }
        if (global == null)
        {
            Debug.LogError("[CLAW] PhotonAppSettings was not found. Install Photon Fusion 2 first, then create its Realtime Settings asset.");
            return;
        }

        object settings = GetMember(global, "AppSettings");
        if (settings == null)
        {
            Debug.LogError("[CLAW] PhotonAppSettings.AppSettings was not available in this SDK version.");
            return;
        }
        bool realtimeSet = SetMember(settings, "AppIdRealtime", RealtimeAppId);
        bool voiceSet = SetMember(settings, "AppIdVoice", VoiceAppId);
        EditorUtility.SetDirty(global);
        AssetDatabase.SaveAssets();

        if (!realtimeSet || !voiceSet)
            Debug.LogWarning("[CLAW] Some Photon settings fields were not found. Check the installed SDK version and enter the IDs manually.");
        Debug.Log("[CLAW] Applied the supplied Realtime and Voice App IDs. You must still create a separate App ID of type Fusion and enter it as AppIdFusion.");
    }

    private static object GetMember(object target, string name)
    {
        if (target == null) return null;
        Type type = target.GetType();
        PropertyInfo property = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (property != null && property.CanRead) return property.GetValue(target, null);
        FieldInfo field = type.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        return field != null ? field.GetValue(target) : null;
    }

    private static bool SetMember(object target, string name, string value)
    {
        if (target == null) return false;
        Type type = target.GetType();
        PropertyInfo property = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (property != null && property.CanWrite && property.PropertyType == typeof(string))
        { property.SetValue(target, value, null); return true; }
        FieldInfo field = type.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (field != null && field.FieldType == typeof(string))
        { field.SetValue(target, value); return true; }
        return false;
    }
}
#endif
