#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.Build;
using UnityEngine;

/// <summary>Validates the source layout, generates map scenes and builds an ARM64 Quest APK when run in Unity.</summary>
public static class ClawAndroidBuild
{
    [MenuItem("CLAW/Build/Validate Project")]
    public static void ValidateProject()
    {
        bool ok=ValidateSourceFiles();
        if(ok) Debug.Log("[CLAW] Source layout check passed. This is not a Unity compile or headset test.");
    }

    private static bool ValidateSourceFiles()
    {
        string[] maps={"Warehouse_Lobby","Cold_Storage","Maintenance_Tunnels"};
        bool ok=true;
        foreach(string map in maps)
        {
            string path="Assets/CLAW/Maps/"+map+".obj";
            if(!File.Exists(path)){Debug.LogError("[CLAW] Missing map model: "+path);ok=false;}
            string mtl="Assets/CLAW/Maps/"+map+".mtl";
            if(!File.Exists(mtl)){Debug.LogError("[CLAW] Missing map material file: "+mtl);ok=false;}
        }
        if(!File.Exists("Packages/manifest.json")){Debug.LogError("[CLAW] Packages/manifest.json is missing.");ok=false;}
        string[] requiredScripts={
            "Assets/CLAW/Scripts/ClawHandPushLocomotion.cs",
            "Assets/CLAW/Scripts/ClawPlayerRigFactory.cs",
            "Assets/CLAW/Scripts/ClawSceneInitialiser.cs",
            "Assets/Editor/ClawCloudSceneBuilder.cs",
            "Assets/Editor/ClawBuildPreprocessor.cs"
        };
        foreach(string path in requiredScripts)
            if(!File.Exists(path)){Debug.LogError("[CLAW] Required source is missing: "+path);ok=false;}
        return ok;
    }

    [MenuItem("CLAW/Build/Check Android OpenXR Setup")]
    public static void CheckAndroidOpenXRSetup()
    {
        if(IsAndroidOpenXRConfigured(out string message)) Debug.Log("[CLAW] "+message);
        else Debug.LogError("[CLAW] "+message);
    }

    public static bool IsAndroidOpenXRConfigured(out string message)
    {
        Type generalType=System.Type.GetType("UnityEditor.XR.Management.XRGeneralSettingsPerBuildTarget, Unity.XR.Management.Editor");
        if(generalType==null){message="XR Plug-in Management settings type not found. Install XR Plug-in Management, then enable OpenXR for Android.";return false;}
        var getSettings=generalType.GetMethod("XRGeneralSettingsForBuildTarget",System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Static);
        if(getSettings==null){message="Could not read XR settings for Android. Open Project Settings > XR Plug-in Management.";return false;}
        object general=getSettings.Invoke(null,new object[]{BuildTargetGroup.Android});
        if(general==null){message="No XR General Settings asset exists for Android. Enable XR Plug-in Management and OpenXR for Android.";return false;}
        object manager=GetMember(general,"Manager");
        object assignedLoaders=GetMember(manager,"loaders");
        if(!(assignedLoaders is System.Collections.IEnumerable)) assignedLoaders=GetMember(manager,"activeLoaders");
        if(assignedLoaders is System.Collections.IEnumerable loaders)
        {
            foreach(object loader in loaders)
            {
                if(loader!=null && loader.GetType().Name.Contains("OpenXRLoader"))
                {message="Android OpenXR Loader is configured.";return true;}
            }
        }
        message="Android OpenXR Loader is not active. Enable OpenXR in Project Settings > XR Plug-in Management > Android before building.";
        return false;
    }

    private static object GetMember(object target,string name)
    {
        if(target==null)return null;
        var type=target.GetType();
        var property=type.GetProperty(name,System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance);
        if(property!=null&&property.CanRead)return property.GetValue(target,null);
        var field=type.GetField(name,System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance);
        return field!=null?field.GetValue(target):null;
    }

    [MenuItem("CLAW/Build/Build Android APK")]
    public static void BuildAndroidApk()
    {
        if(!ValidateSourceFiles()) return;
        ClawQuestXRSetup.ConfigureAndroidOpenXR();
        if(!IsAndroidOpenXRConfigured(out string xrMessage))
        {
            Debug.LogError("[CLAW] Build stopped to avoid creating a non-VR Android APK. "+xrMessage);
            return;
        }
        ClawCloudSceneBuilder.GenerateAllScenes();
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android,BuildTarget.Android);
        ConfigureAndroidPlayerSettings();

        string[] scenes=EditorBuildSettings.scenes.Where(s=>s.enabled).Select(s=>s.path).ToArray();
        if(scenes.Length==0){Debug.LogError("[CLAW] No scenes in Build Settings. Scene generation failed.");return;}
        Directory.CreateDirectory("Builds/Android");
        var options=new BuildPlayerOptions{scenes=scenes,locationPathName="Builds/Android/CLAW-Quest.apk",target=BuildTarget.Android,options=BuildOptions.None};
        BuildReport report=BuildPipeline.BuildPlayer(options);
        if(report.summary.result==BuildResult.Succeeded)
            Debug.Log("[CLAW] APK built: "+options.locationPathName+" ("+report.summary.totalSize+" bytes)");
        else
            Debug.LogError("[CLAW] Android build failed: "+report.summary.result+". Check the full Unity Editor log.");
    }

    public static void ConfigureAndroidPlayerSettings()
    {
        PlayerSettings.productName="CLAW";
        PlayerSettings.companyName="CLAW";
        PlayerSettings.bundleVersion="0.3.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android,"com.clawvr.game");
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android,ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel29;
        PlayerSettings.colorSpace=ColorSpace.Linear;
        PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
    }

    // Unity Build Automation can be configured to call this static method after importing the project.
    public static void BuildAndroidCI()
    {
        string apkPath="Builds/Android/CLAW-Quest.apk";
        if(File.Exists(apkPath)) File.Delete(apkPath);
        BuildAndroidApk();
        if(!File.Exists(apkPath))
            throw new System.Exception("CLAW Android build did not produce an APK. Check the Unity build log for XR or compiler errors.");
        var info=new FileInfo(apkPath);
        if(info.Length < 1024*1024)
            throw new System.Exception("CLAW APK output is unexpectedly small; refusing to publish a likely invalid artifact.");
    }
}
#endif
