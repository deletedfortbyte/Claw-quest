#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

/// <summary>Ensures generated map scenes exist before a cloud or local Android player build.</summary>
public sealed class ClawBuildPreprocessor : IPreprocessBuildWithReport
{
    public int callbackOrder => -1000;

    public void OnPreprocessBuild(BuildReport report)
    {
        if (report.summary.platform != BuildTarget.Android) return;
        ClawQuestXRSetup.ConfigureAndroidOpenXR();
        if (!ClawAndroidBuild.IsAndroidOpenXRConfigured(out string xrMessage))
            throw new BuildFailedException("CLAW requires Android OpenXR for a Quest build. " + xrMessage);
        ClawCloudSceneBuilder.GenerateAllScenes();
        ClawAndroidBuild.ConfigureAndroidPlayerSettings();
        UnityEngine.Debug.Log("[CLAW] Android pre-build: generated all three map scenes and applied ARM64/IL2CPP settings.");
    }
}
#endif
