using UnityEngine;
using UnityEngine.XR;

/// <summary>Builds the original legless CLAW avatar and first-person XR rig from primitives at runtime.</summary>
public static class ClawPlayerRigFactory
{
    public static GameObject LocalPlayer { get; private set; }

    public static GameObject Create(Vector3 spawnPosition)
    {
        if (LocalPlayer!=null) Object.Destroy(LocalPlayer);
        var root=new GameObject("CLAW_LocalPlayer");
        root.transform.position=spawnPosition; root.tag="Player"; root.layer=8;
        LocalPlayer=root;

        var rb=root.AddComponent<Rigidbody>(); rb.mass=48f; rb.useGravity=true;
        rb.interpolation=RigidbodyInterpolation.Interpolate; rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
        rb.constraints=RigidbodyConstraints.FreezeRotation;
        var capsule=root.AddComponent<CapsuleCollider>(); capsule.center=new Vector3(0,.82f,0); capsule.height=1.6f; capsule.radius=.29f;

        Material bodyMat=MakeMaterial(new Color(.30f,.22f,.58f));
        Material handMat=MakeMaterial(new Color(.50f,.39f,.86f));
        Material faceMat=MakeMaterial(new Color(.76f,.83f,.94f));
        Material darkMat=MakeMaterial(new Color(.055f,.07f,.12f));
        Material eyeMat=MakeMaterial(new Color(.08f,.88f,.96f),true);

        Transform avatar=new GameObject("AvatarVisuals").transform; avatar.SetParent(root.transform,false);
        var torso=Primitive(PrimitiveType.Sphere,"BodyShell",avatar,new Vector3(0,1.02f,0),new Vector3(.64f,.68f,.46f),bodyMat);
        Object.Destroy(torso.GetComponent<Collider>());
        var head=Primitive(PrimitiveType.Sphere,"RoundHead",avatar,new Vector3(0,1.78f,0),new Vector3(.60f,.60f,.58f),bodyMat);
        Object.Destroy(head.GetComponent<Collider>());
        var face=Primitive(PrimitiveType.Cube,"FlatFace",head.transform,new Vector3(0,-.02f,.47f),new Vector3(.37f,.25f,.045f),faceMat);
        Object.Destroy(face.GetComponent<Collider>());
        face.transform.localScale=new Vector3(.37f,.25f,.045f);
        var leftEye=Primitive(PrimitiveType.Sphere,"LeftEye",head.transform,new Vector3(-.095f,.035f,.515f),new Vector3(.055f,.065f,.025f),eyeMat);
        var rightEye=Primitive(PrimitiveType.Sphere,"RightEye",head.transform,new Vector3(.095f,.035f,.515f),new Vector3(.055f,.065f,.025f),eyeMat);
        Object.Destroy(leftEye.GetComponent<Collider>()); Object.Destroy(rightEye.GetComponent<Collider>());
        var mouth=Primitive(PrimitiveType.Cube,"FaceMark",head.transform,new Vector3(0,-.105f,.515f),new Vector3(.13f,.018f,.018f),darkMat);
        Object.Destroy(mouth.GetComponent<Collider>());

        // The local player sees tracked hands and arms; hide the head shell to avoid camera clipping.
        head.GetComponent<Renderer>().enabled=false;
        face.GetComponent<Renderer>().enabled=false;
        leftEye.GetComponent<Renderer>().enabled=false; rightEye.GetComponent<Renderer>().enabled=false;
        mouth.GetComponent<Renderer>().enabled=false;

        Transform trackingOrigin=new GameObject("XR_TrackingOrigin").transform; trackingOrigin.SetParent(root.transform,false);
        var cameraObject=new GameObject("Main Camera"); cameraObject.tag="MainCamera"; cameraObject.transform.SetParent(trackingOrigin,false);
        var cam=cameraObject.AddComponent<Camera>(); cam.nearClipPlane=.05f; cam.farClipPlane=120f;
        cam.stereoTargetEye=StereoTargetEyeMask.Both; cam.fieldOfView=82f;
        cameraObject.AddComponent<AudioListener>();
        var hudObject=new GameObject("CLAW_HUD");
        hudObject.transform.SetParent(cameraObject.transform,false);
        hudObject.transform.localPosition=new Vector3(-.43f,-.28f,1.0f);
        hudObject.transform.localRotation=Quaternion.identity;
        var hudText=hudObject.AddComponent<TextMesh>();
        hudText.text="CLAW";hudText.characterSize=.018f;hudText.fontSize=40;
        hudText.anchor=TextAnchor.UpperLeft;hudText.alignment=TextAlignment.Left;
        hudText.color=new Color(.64f,.88f,1f);
        hudObject.AddComponent<ClawLocalHud>();

        Transform leftHand=MakeHand(root.transform,"LeftHand",handMat);
        Transform rightHand=MakeHand(root.transform,"RightHand",handMat);
        Transform leftArm=MakeArm(root.transform,"LeftArm",bodyMat);
        Transform rightArm=MakeArm(root.transform,"RightArm",bodyMat);
        MakeFinger(leftHand,handMat,-.055f); MakeFinger(leftHand,handMat,-.018f); MakeFinger(leftHand,handMat,.018f); MakeFinger(leftHand,handMat,.055f);
        MakeFinger(rightHand,handMat,-.055f); MakeFinger(rightHand,handMat,-.018f); MakeFinger(rightHand,handMat,.018f); MakeFinger(rightHand,handMat,.055f);

        var mover=root.AddComponent<ClawHandPushLocomotion>();
        mover.Configure(trackingOrigin,cameraObject.transform,leftHand,rightHand,leftArm,rightArm);
        root.AddComponent<ClawFallRecovery>(); root.AddComponent<ClawPlayerColor>();
#if CLAW_PLAYFAB_PHOTON && CLAW_PHOTON_FUSION
        root.AddComponent<ClawPlayFabPhotonAuth>();
#endif
        root.AddComponent<ClawVRUIInteractor>().Configure(cameraObject.transform,leftHand,rightHand);
        root.AddComponent<ClawVoiceControls>();
        ClawRuntimeMenu.Create(cameraObject.transform,root);
        return root;
    }

    private static GameObject Primitive(PrimitiveType type,string name,Transform parent,Vector3 localPos,Vector3 localScale,Material mat)
    {
        var go=GameObject.CreatePrimitive(type); go.name=name; go.transform.SetParent(parent,false);
        go.transform.localPosition=localPos; go.transform.localScale=localScale;
        go.GetComponent<Renderer>().sharedMaterial=mat; return go;
    }

    private static Transform MakeHand(Transform parent,string name,Material mat)
    {
        var palm=Primitive(PrimitiveType.Sphere,name,parent,new Vector3(0,1.2f,0),new Vector3(.20f,.13f,.22f),mat);
        Object.Destroy(palm.GetComponent<Collider>()); return palm.transform;
    }

    private static Transform MakeArm(Transform parent,string name,Material mat)
    {
        var arm=Primitive(PrimitiveType.Cylinder,name,parent,new Vector3(0,1.25f,0),new Vector3(.17f,.45f,.17f),mat);
        Object.Destroy(arm.GetComponent<Collider>()); return arm.transform;
    }

    private static void MakeFinger(Transform hand,Material mat,float x)
    {
        var finger=Primitive(PrimitiveType.Capsule,"Finger",hand,new Vector3(x,-.09f,.075f),new Vector3(.035f,.075f,.035f),mat);
        Object.Destroy(finger.GetComponent<Collider>());
    }

    private static Material MakeMaterial(Color color,bool emission=false)
    {
        Shader shader=Shader.Find("Universal Render Pipeline/Lit"); if(shader==null) shader=Shader.Find("Standard");
        var m=new Material(shader){color=color};
        if(emission && m.HasProperty("_EmissionColor")){m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color*1.5f);}
        return m;
    }
}
