using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public sealed class ClawFallRecovery : MonoBehaviour
{
    [SerializeField] private float fallLimit = -12f;
    private Rigidbody body;
    private void Awake() { body = GetComponent<Rigidbody>(); }
    private void FixedUpdate()
    {
        if (transform.position.y > fallLimit) return;
        Vector3 target = ClawGameSession.Instance != null && ClawGameSession.Instance.HasCheckpoint
            ? ClawGameSession.Instance.Checkpoint : Vector3.zero;
        body.position = target + Vector3.up * 0.12f;
        body.velocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        ClawGameSession.Instance?.SetStatus("Returned to the last checkpoint.");
    }
}
