#if CLAW_PHOTON_FUSION
using System.Collections.Generic;
using System.Threading.Tasks;
using Fusion;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Photon Fusion Shared Mode: private six-character invites and public quick matchmaking.</summary>
public sealed class ClawFusionRoomConnector : MonoBehaviour
{
    [SerializeField,Min(2)] private int playerLimit=10;
    public static ClawFusionRoomConnector Instance {get;private set;}
    private NetworkRunner runner;
    private GameObject runnerRoot;
    private bool busy;
    public bool Connected => runner!=null && runner.IsRunning;

    public static ClawFusionRoomConnector EnsureInstance()
    {
        if(Instance!=null)return Instance;
        var host=new GameObject("CLAW_NetworkService");
        DontDestroyOnLoad(host);
        return host.AddComponent<ClawFusionRoomConnector>();
    }

    private void Awake()
    {
        if(Instance!=null&&Instance!=this){Destroy(gameObject);return;}
        Instance=this;DontDestroyOnLoad(gameObject);
    }

    public async void QuickPlay(){await StartRoom(null,true,true);}
    public async void CreatePrivateRoom(string code){await StartRoom(ClawRoomCode.Normalize(code),true,false);}
    public async void JoinPrivateRoom(string code)
    {
        code=ClawRoomCode.Normalize(code);
        if(!ClawRoomCode.IsValid(code)){SetStatus("Invalid room code. Use six letters/numbers.");return;}
        await StartRoom(code,false,false);
    }

    private async Task StartRoom(string sessionName,bool allowCreate,bool visible)
    {
        if(busy)return;
        if(Connected){SetStatus("Already connected to a room.");return;}
        busy=true;
        try
        {
#if CLAW_PLAYFAB_PHOTON
            if(!ClawPlayFabPhotonAuth.Ready){SetStatus("Sign in through PlayFab before joining online.");return;}
#endif
            runnerRoot=new GameObject("CLAW_NetworkRunner");
            DontDestroyOnLoad(runnerRoot);
            runner=runnerRoot.AddComponent<NetworkRunner>();
            runner.ProvideInput=true;
            bool voiceReady=ClawPhotonVoiceBootstrap.AttachToRunner(runnerRoot);
            if(!voiceReady)Debug.LogWarning("[CLAW] Photon Voice for Fusion add-on not detected; voice chat is disabled.");
            var sceneManager=runnerRoot.AddComponent<NetworkSceneManagerDefault>();
            var bootstrap=runnerRoot.AddComponent<ClawFusionPlayerSpawner>();
            var avatarPrefab=Resources.Load<NetworkObject>("CLAW_NetworkPlayer");
            if(avatarPrefab==null){SetStatus("Network avatar prefab missing. Run CLAW > Networking > Build Network Avatar Prefab in Unity.");CleanupRunner();return;}
            bootstrap.SetPlayerPrefab(avatarPrefab);
            NetworkSceneInfo sceneInfo=new NetworkSceneInfo();
            SceneRef activeScene=SceneRef.FromIndex(SceneManager.GetActiveScene().buildIndex);
            if(activeScene.IsValid)sceneInfo.AddSceneRef(activeScene,LoadSceneMode.Single);
            Dictionary<string,SessionProperty> roomProperties=null;
            if(allowCreate && ClawGameSession.Instance!=null)
            {
                roomProperties=new Dictionary<string,SessionProperty>
                {
                    {"mode",(int)ClawGameSession.Instance.Mode}
                };
            }
            var args=new StartGameArgs
            {
                GameMode=GameMode.Shared,
                SessionName=sessionName,
                PlayerCount=playerLimit,
                IsOpen=true,
                IsVisible=visible,
                EnableClientSessionCreation=allowCreate,
                CustomLobbyName="CLAW",
                SessionProperties=roomProperties,
                Scene=sceneInfo,
                SceneManager=sceneManager
#if CLAW_PLAYFAB_PHOTON
                ,AuthValues=ClawPlayFabPhotonAuth.AuthValues
#endif
            };
            string modeName=ClawGameSession.Instance!=null?ClawGameSession.Instance.Mode.ToString():"Expedition";
            SetStatus(visible?"Finding a public "+modeName+" room...":(allowCreate?"Creating private room...":"Joining private room..."));
            StartGameResult result=await runner.StartGame(args);
            if(!result.Ok)
            {
                SetStatus("Could not connect: "+result.ShutdownReason);
                await runner.Shutdown();CleanupRunner();return;
            }
            string joined=runner.SessionInfo.Name;
            if(runner.SessionInfo.Properties!=null && runner.SessionInfo.Properties.TryGetValue("mode",out SessionProperty roomMode) && roomMode.IsInt)
            {
                ClawGameMode hostMode=(ClawGameMode)Mathf.Clamp((int)roomMode.PropertyValue,0,5);
                ClawModeDirector director=FindObjectOfType<ClawModeDirector>();
                if(director!=null)director.ApplyRoomMode(hostMode);
                else ClawGameSession.Instance?.SetMode(hostMode);
            }
            string connectedStatus=visible?"Connected to public room.":"Connected to private room: "+joined;
            if(!voiceReady)connectedStatus+=" Voice is disabled until Photon Voice for Fusion is installed and configured.";
            SetStatus(connectedStatus);
            if(!visible)ClawRuntimeMenu.AppendChat("Room invite code: "+joined);
        }
        catch(System.Exception e)
        {
            Debug.LogException(e);SetStatus("Online connection failed. Check Photon Fusion configuration.");
            if(runner!=null){try{await runner.Shutdown();}catch{ } CleanupRunner();}
        }
        finally{busy=false;}
    }

    public async void LeaveRoom()
    {
        if(runner==null)return;
        try{await runner.Shutdown();}catch(System.Exception e){Debug.LogWarning(e.Message);}
        CleanupRunner();SetStatus("You left the room.");
    }

    private void CleanupRunner()
    {
        runner=null;
        if(runnerRoot!=null){Destroy(runnerRoot);runnerRoot=null;}
        ClawFusionChatRelay.Local=null;
    }

    private static void SetStatus(string value){ClawGameSession.Instance?.SetStatus(value);Debug.Log("[CLAW] "+value);}
    private void OnDestroy()
    {
        if(Instance==this)Instance=null;
        if(runner!=null&&runner.IsRunning)runner.Shutdown();
    }
}
#endif
