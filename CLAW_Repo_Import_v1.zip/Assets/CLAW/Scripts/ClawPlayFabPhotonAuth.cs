#if CLAW_PLAYFAB_PHOTON && CLAW_PHOTON_FUSION
using System;
using Fusion.Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine;

/// <summary>Prototype PlayFab device login -> short-lived Photon Fusion token. Never stores a developer secret in the client.</summary>
public sealed class ClawPlayFabPhotonAuth : MonoBehaviour
{
    private const string DefaultTitleId="A03E5";
    public static AuthenticationValues AuthValues {get;private set;}
    public static bool Ready {get;private set;}
    public static event Action<bool,string> Completed;

    public void LoginWithDeviceForPrototype()
    {
        Ready=false;AuthValues=null;
        if(string.IsNullOrEmpty(PlayFabSettings.TitleId))PlayFabSettings.TitleId=DefaultTitleId;
        string deviceId=PlayFabSettings.DeviceUniqueIdentifier;
        if(string.IsNullOrEmpty(deviceId)){Fail("This device did not provide an install ID.");return;}
        var request=new LoginWithCustomIDRequest{CreateAccount=true,CustomId=deviceId};
        PlayFabClientAPI.LoginWithCustomID(request,OnLogin,OnError);
    }

    private void OnLogin(LoginResult result)
    {
        if(result==null||string.IsNullOrEmpty(result.PlayFabId)){Fail("PlayFab login did not return a player ID.");return;}
        string fusionAppId=PhotonAppSettings.Global!=null?PhotonAppSettings.Global.AppSettings.AppIdFusion:null;
        if(string.IsNullOrEmpty(fusionAppId)){Fail("Set a Photon App ID of type Fusion in Fusion Realtime Settings first.");return;}
        var request=new GetPhotonAuthenticationTokenRequest{PhotonApplicationId=fusionAppId};
        PlayFabClientAPI.GetPhotonAuthenticationToken(request,token=>
        {
            if(token==null||string.IsNullOrEmpty(token.PhotonCustomAuthenticationToken)){Fail("PlayFab returned an empty Photon token.");return;}
            var auth=new AuthenticationValues{AuthType=CustomAuthenticationType.Custom};
            auth.AddAuthParameter("username",result.PlayFabId);
            auth.AddAuthParameter("token",token.PhotonCustomAuthenticationToken);
            AuthValues=auth;Ready=true;Completed?.Invoke(true,"Signed in through PlayFab.");
            ClawGameSession.Instance?.SetStatus("Signed in. Online rooms are ready.");
        },OnError);
    }

    private void OnError(PlayFabError error){Fail(error!=null?error.ErrorMessage:"Unknown PlayFab error.");}
    private void Fail(string message){Ready=false;AuthValues=null;Debug.LogError("[CLAW] "+message);ClawGameSession.Instance?.SetStatus(message);Completed?.Invoke(false,message);}
}
#endif
