using System.Collections.Generic;
using UnityEngine;

/// <summary>Cycles the avatar's body/arm color while preserving face and eye materials.</summary>
public sealed class ClawPlayerColor : MonoBehaviour
{
    private static readonly Color[] Palette = {
        new Color(.48f,.31f,.86f), new Color(.13f,.72f,.68f), new Color(.67f,.84f,.24f),
        new Color(.94f,.52f,.18f), new Color(.22f,.49f,.88f), new Color(.86f,.27f,.37f)
    };
    private readonly List<Renderer> tintable = new List<Renderer>();
    private MaterialPropertyBlock block;
    private static readonly int BaseColor = Shader.PropertyToID("_BaseColor");
    private static readonly int ColorId = Shader.PropertyToID("_Color");
    private int selected;

    private void Awake()
    {
        block = new MaterialPropertyBlock();
        foreach (Renderer renderer in GetComponentsInChildren<Renderer>(true))
        {
            string n = renderer.transform.name;
            if (n.Contains("Face") || n.Contains("Eye") || n.Contains("Mark") || n.Contains("NameLabel")) continue;
            tintable.Add(renderer);
        }
        selected = Mathf.Abs(PlayerPrefs.GetInt("CLAW_COLOR", 0)) % Palette.Length;
        Apply();
    }

    public void SelectNext()
    {
        selected = (selected + 1) % Palette.Length;
        PlayerPrefs.SetInt("CLAW_COLOR", selected);
        PlayerPrefs.Save();
        Apply();
    }

    private void Apply()
    {
        foreach (Renderer renderer in tintable)
        {
            if (renderer == null) continue;
            renderer.GetPropertyBlock(block);
            block.SetColor(BaseColor, Palette[selected]);
            block.SetColor(ColorId, Palette[selected]);
            renderer.SetPropertyBlock(block);
        }
    }
}
