using UnityEngine;

[RequireComponent(typeof(TextMesh))]
public sealed class ClawLocalHud : MonoBehaviour
{
    private TextMesh label;
    private void Awake(){label=GetComponent<TextMesh>();}
    private void Update()
    {
        if(label==null||ClawGameSession.Instance==null)return;
        var s=ClawGameSession.Instance;
        label.text=$"CLAW  //  {s.CurrentMap}\nMODE  {s.Mode}\nSIGNAL CORES  {s.SignalCores}/{s.RequiredCores}\n{s.Status}";
    }
}
