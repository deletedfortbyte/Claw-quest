#if CLAW_PHOTON_FUSION
using System.Collections.Generic;
using Fusion;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Transient room text chat and first-slice shared objective relay for Fusion Shared Mode.</summary>
public sealed class ClawFusionChatRelay : NetworkBehaviour
{
    public static ClawFusionChatRelay Local { get; set; }
    private static readonly HashSet<string> CollectedThisScene = new HashSet<string>();
    private static float lastChatSendTime = -100f;

    public static bool Send(string text)
    {
        if (Local == null || Local.Object == null || !Local.Object.HasStateAuthority || string.IsNullOrWhiteSpace(text))
            return false;
        if (Time.unscaledTime - lastChatSendTime < 1.0f) return false;

        string safeText = text.Trim().Replace("\r", " ").Replace("\n", " ");
        if (safeText.Length > 80) safeText = safeText.Substring(0, 80);
        string name = PlayerPrefs.GetString("CLAW_NAME", "Player");
        string raw = name + ": " + safeText;
        if (raw.Length > 120) raw = raw.Substring(0, 120);
        lastChatSendTime = Time.unscaledTime;
        Local.RPC_Broadcast(raw);
        return true;
    }

    public static bool SendObjective(string objectName)
    {
        if (Local == null || Local.Object == null || !Local.Object.HasStateAuthority || string.IsNullOrWhiteSpace(objectName))
            return false;
        Local.RPC_CollectCore(objectName);
        return true;
    }

    public static bool SendExtraction()
    {
        if (Local == null || Local.Object == null || !Local.Object.HasStateAuthority) return false;
        Local.RPC_CompleteExtraction();
        return true;
    }

    [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
    private void RPC_Broadcast(NetworkString<_128> line)
    {
        ClawRuntimeMenu.AppendChat(line.ToString());
    }

    [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
    private void RPC_CollectCore(NetworkString<_32> objectName)
    {
        string key = SceneManager.GetActiveScene().name + "::" + objectName.ToString();
        if (!CollectedThisScene.Add(key)) return;
        GameObject go = GameObject.Find(objectName.ToString());
        if (go != null)
        {
            ClawCollectible collectible = go.GetComponent<ClawCollectible>();
            if (collectible != null) collectible.CollectFromNetwork();
        }
    }

    [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
    private void RPC_CompleteExtraction()
    {
        ClawExtractionGate gate = FindObjectOfType<ClawExtractionGate>();
        if (gate != null) gate.CompleteFromNetwork();
        else ClawGameSession.Instance?.TryExtract();
    }
}
#endif
