using UnityEngine;

public static class ClawRoomCode
{
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    public const int Length = 6;
    public static string Generate()
    {
        char[] code = new char[Length];
        for (int i = 0; i < code.Length; i++) code[i] = Alphabet[Random.Range(0, Alphabet.Length)];
        return new string(code);
    }
    public static bool IsValid(string raw)
    {
        string code = (raw ?? string.Empty).Trim().ToUpperInvariant();
        if (code.Length != Length) return false;
        for (int i = 0; i < code.Length; i++) if (Alphabet.IndexOf(code[i]) < 0) return false;
        return true;
    }
    public static string Normalize(string raw) => (raw ?? string.Empty).Trim().ToUpperInvariant();
}
