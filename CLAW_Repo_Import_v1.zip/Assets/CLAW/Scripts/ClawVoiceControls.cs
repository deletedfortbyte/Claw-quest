using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.XR;

/// <summary>
/// Local voice privacy controls. Default is silent; holding X on the left controller enables
/// transmission. Incoming speakers can always be muted from the in-headset menu.
/// </summary>
public sealed class ClawVoiceControls : MonoBehaviour
{
    public static bool IsMuted { get; private set; }
    public static bool VoiceComponentsFound { get; private set; }

    private readonly List<MonoBehaviour> recorders = new List<MonoBehaviour>();
    private readonly List<MonoBehaviour> speakers = new List<MonoBehaviour>();
    private float refreshTimer;
    private bool lastTransmit;
    private bool permissionRequested;
    private bool missingVoiceReported;

    public static void ToggleMuteAll()
    {
        IsMuted = !IsMuted;
        var controls = FindObjectOfType<ClawVoiceControls>();
        if (controls != null) controls.ApplySpeakerMute();
    }

    private void Awake()
    {
        IsMuted = false;
        RefreshVoiceComponents();
        lastTransmit = false;
        ApplySpeakerMute();
    }

    private void Update()
    {
        bool pushToTalk = false;
        InputDevice left = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        if (left.isValid) left.TryGetFeatureValue(CommonUsages.primaryButton, out pushToTalk);

        bool mayTransmit = pushToTalk && !IsMuted && HasMicrophonePermission();
        if (mayTransmit != lastTransmit)
        {
            SetRecorderTransmit(mayTransmit);
            lastTransmit = mayTransmit;
        }

        refreshTimer -= Time.unscaledDeltaTime;
        if (refreshTimer <= 0f)
        {
            refreshTimer = 1f;
            RefreshVoiceComponents();
            ApplySpeakerMute();
            if (!VoiceComponentsFound && !missingVoiceReported)
            {
                missingVoiceReported = true;
                ClawGameSession.Instance?.SetStatus("Voice SDK not installed. Online voice is unavailable.");
            }
        }
    }

    private bool HasMicrophonePermission()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (UnityEngine.Android.Permission.HasUserAuthorizedPermission(UnityEngine.Android.Permission.Microphone))
            return true;
        if (!permissionRequested)
        {
            permissionRequested = true;
            UnityEngine.Android.Permission.RequestUserPermission(UnityEngine.Android.Permission.Microphone);
            ClawGameSession.Instance?.SetStatus("Allow microphone access to use push-to-talk.");
        }
        return false;
#else
        return true;
#endif
    }

    private void RefreshVoiceComponents()
    {
        recorders.Clear();
        speakers.Clear();
        foreach (MonoBehaviour component in Resources.FindObjectsOfTypeAll<MonoBehaviour>())
        {
            if (component == null || !component.gameObject.scene.IsValid()) continue;
            string typeName = component.GetType().Name;
            if (typeName == "Recorder") recorders.Add(component);
            else if (typeName == "Speaker") speakers.Add(component);
        }
        VoiceComponentsFound = recorders.Count > 0 && speakers.Count > 0;
        // Never leave a newly spawned Recorder transmitting by default.
        SetRecorderTransmit(lastTransmit && !IsMuted);
    }

    private void SetRecorderTransmit(bool enabled)
    {
        bool allow = enabled && !IsMuted && recorders.Count > 0;
        foreach (MonoBehaviour recorder in recorders)
            SetBoolProperty(recorder, "TransmitEnabled", allow);
    }

    private void ApplySpeakerMute()
    {
        foreach (MonoBehaviour speaker in speakers)
        {
            if (speaker == null) continue;
            foreach (AudioSource source in speaker.GetComponentsInChildren<AudioSource>(true))
                source.mute = IsMuted;
        }
    }

    private static void SetBoolProperty(object target, string name, bool value)
    {
        if (target == null) return;
        PropertyInfo property = target.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        if (property != null && property.CanWrite && property.PropertyType == typeof(bool))
            property.SetValue(target, value, null);
    }

    private void OnDisable()
    {
        SetRecorderTransmit(false);
        lastTransmit = false;
    }
}
