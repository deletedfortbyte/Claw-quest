using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Collider))]
public sealed class ClawTravelPortal : MonoBehaviour
{
    [SerializeField] private string sceneToLoad;
    private bool loading;
    public void SetDestination(string sceneName) { sceneToLoad = sceneName; }
    private void Reset() { GetComponent<Collider>().isTrigger = true; }
    private void OnTriggerEnter(Collider other)
    {
        if (loading || !other.CompareTag("Player") || string.IsNullOrWhiteSpace(sceneToLoad)) return;
        loading = true;
        ClawGameSession.Instance?.SetStatus("Travelling...");
#if CLAW_PHOTON_FUSION
        if(ClawNetworkSceneController.RequestTravel(sceneToLoad))return;
#endif
        SceneManager.LoadScene(sceneToLoad);
    }
}
