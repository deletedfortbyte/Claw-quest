using UnityEngine;

/// <summary>Simple obstacle-aware roaming threat for the solo survival/hide-and-seek slice.</summary>
[RequireComponent(typeof(SphereCollider))]
public sealed class ClawMonsterAI : MonoBehaviour
{
    [SerializeField] private float moveSpeed=2.15f;
    [SerializeField] private float turnSpeed=4f;
    [SerializeField] private float catchDistance=1.05f;
    private Transform target;
    private float retargetTimer;
    private float catchCooldown;
    private Vector3 home;
    private bool caught;

    private void Start(){home=transform.position;if(ClawPlayerRigFactory.LocalPlayer!=null)target=ClawPlayerRigFactory.LocalPlayer.transform;}

    private void Update()
    {
        if(caught){catchCooldown-=Time.deltaTime;if(catchCooldown<=0)caught=false;return;}
        if(target==null&&ClawPlayerRigFactory.LocalPlayer!=null)target=ClawPlayerRigFactory.LocalPlayer.transform;
        if(target==null)return;
        retargetTimer-=Time.deltaTime;
        Vector3 flat=target.position-transform.position;flat.y=0;
        if(flat.magnitude>catchDistance)
        {
            Vector3 direction=flat.normalized;
            Vector3 move=direction;
            if(Physics.SphereCast(transform.position+Vector3.up*.6f,.35f,direction,out RaycastHit hit,.9f,~(1<<8),QueryTriggerInteraction.Ignore))
                move=Vector3.ProjectOnPlane(direction,hit.normal).normalized;
            transform.position+=move*moveSpeed*Time.deltaTime;
            if(move.sqrMagnitude>.01f){Quaternion look=Quaternion.LookRotation(move,Vector3.up);transform.rotation=Quaternion.Slerp(transform.rotation,look,turnSpeed*Time.deltaTime);}
        }
        else CatchPlayer();
    }

    private void OnTriggerEnter(Collider other){if(!caught&&other.CompareTag("Player"))CatchPlayer();}
    private void CatchPlayer()
    {
        if(caught)return;caught=true;catchCooldown=2.0f;transform.position=home;
        var body=ClawPlayerRigFactory.LocalPlayer!=null?ClawPlayerRigFactory.LocalPlayer.GetComponent<Rigidbody>():null;
        if(body!=null && ClawGameSession.Instance!=null)
        {
            body.position=ClawGameSession.Instance.Checkpoint+Vector3.up*.15f;
            body.velocity=Vector3.zero;body.angularVelocity=Vector3.zero;
        }
        ClawGameSession.Instance?.SetStatus("The creature found you. You returned to the last checkpoint.");
    }
}
