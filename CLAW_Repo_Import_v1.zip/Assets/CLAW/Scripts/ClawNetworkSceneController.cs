#if CLAW_PHOTON_FUSION
using Fusion;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Scene object whose Shared Mode State Authority is the Master Client; it coordinates map travel.</summary>
public sealed class ClawNetworkSceneController : NetworkBehaviour
{
    public static bool RequestTravel(string sceneName)
    {
        if(string.IsNullOrWhiteSpace(sceneName))return false;
        var controller=FindObjectOfType<ClawNetworkSceneController>();
        if(controller==null||controller.Runner==null)return false;
        controller.RPC_RequestTravel(sceneName);
        return true;
    }

    [Rpc(RpcSources.All,RpcTargets.StateAuthority)]
    private void RPC_RequestTravel(NetworkString<_32> sceneName)
    {
        if(!Runner.IsSceneAuthority)return;
        string path="Assets/CLAW/Scenes/"+sceneName.ToString()+".unity";
        int index=SceneUtility.GetBuildIndexByScenePath(path);
        if(index<0){Debug.LogError("[CLAW] Map scene is not in Build Settings: "+path);return;}
        Runner.LoadScene(SceneRef.FromIndex(index),LoadSceneMode.Single);
    }
}
#endif
