using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Self-building in-headset lobby/menu. Uses stock UGUI so the offline project has no TMP dependency.</summary>
public sealed class ClawRuntimeMenu : MonoBehaviour
{
    public static bool IsOpen { get; private set; }
    public static Canvas ActiveCanvas { get; private set; }
    public static ClawRuntimeMenu Instance { get; private set; }

    private Text statusText,chatText,roomCodeText,modeText;
    private InputField roomInput,chatInput,nameInput,activeInput;
    private RectTransform keyboardPanel;
    private readonly List<string> chatLines=new List<string>();
    private string lastStatus="";

    public static void Toggle(){if(Instance!=null)Instance.SetOpen(!IsOpen);}

    public static void Create(Transform camera,GameObject player)
    {
        var root=new GameObject("CLAW_InHeadsetMenu");
        root.transform.SetParent(camera,false);
        root.transform.localPosition=new Vector3(0,.04f,1.22f);
        root.transform.localRotation=Quaternion.identity;
        var menu=root.AddComponent<ClawRuntimeMenu>();
        menu.Build(camera);
    }

    private void Awake(){Instance=this;}

    private void Build(Transform camera)
    {
        if(EventSystem.current==null)
        {
            var eventObject=new GameObject("CLAW_EventSystem");
            eventObject.AddComponent<EventSystem>();
            eventObject.AddComponent<StandaloneInputModule>();
        }
        ActiveCanvas=gameObject.AddComponent<Canvas>();
        ActiveCanvas.renderMode=RenderMode.WorldSpace;
        ActiveCanvas.worldCamera=camera.GetComponent<Camera>();
        ActiveCanvas.sortingOrder=50;
        var scaler=gameObject.AddComponent<CanvasScaler>();scaler.dynamicPixelsPerUnit=8;
        gameObject.AddComponent<GraphicRaycaster>();
        var canvasRect=GetComponent<RectTransform>();canvasRect.sizeDelta=new Vector2(760,840);
        transform.localScale=Vector3.one*.00135f;

        var panel=MakeRect("Panel",transform,new Vector2(760,840),new Vector2(0,0));
        var image=panel.gameObject.AddComponent<Image>();image.color=new Color(.035f,.045f,.075f,.96f);
        MakeText("Title",panel,"CLAW",34,TextAnchor.MiddleLeft,new Vector2(-300,370),new Vector2(650,55),new Color(.50f,.86f,1f));
        MakeText("Subtitle",panel,"ABANDONED FACILITY // MULTIPLAYER VR",14,TextAnchor.MiddleLeft,new Vector2(-300,333),new Vector2(650,32),Color.white);

        statusText=MakeText("Status",panel,"Loading CLAW...",15,TextAnchor.MiddleLeft,new Vector2(-300,285),new Vector2(650,50),new Color(.7f,.9f,.8f));
        AddButton(panel,"PUBLIC QUICK PLAY",new Vector2(-160,215),new Vector2(290,58),()=>QuickPlay());
        AddButton(panel,"CREATE PRIVATE ROOM",new Vector2(160,215),new Vector2(290,58),()=>CreatePrivateRoom());

        MakeText("RoomLabel",panel,"PRIVATE ROOM CODE",13,TextAnchor.MiddleLeft,new Vector2(-300,140),new Vector2(240,28),new Color(.75f,.8f,.9f));
        roomInput=MakeInput(panel,"Enter 6-character code",new Vector2(0,140),new Vector2(250,48));
        roomInput.onSelect.AddListener(_=>ShowKeyboard(roomInput));
        AddButton(panel,"JOIN",new Vector2(245,140),new Vector2(130,48),()=>JoinPrivateRoom());
        roomCodeText=MakeText("RoomCode",panel,"Your code will appear here",13,TextAnchor.MiddleLeft,new Vector2(-300,93),new Vector2(650,30),new Color(.5f,.85f,1f));

        MakeText("NameLabel",panel,"DISPLAY NAME",13,TextAnchor.MiddleLeft,new Vector2(-300,42),new Vector2(180,28),Color.white);
        nameInput=MakeInput(panel,"Enter a player name",new Vector2(-35,42),new Vector2(300,46));
        nameInput.onSelect.AddListener(_=>ShowKeyboard(nameInput));
        nameInput.text=PlayerPrefs.GetString("CLAW_NAME","Player");
        AddButton(panel,"SAVE NAME",new Vector2(245,42),new Vector2(130,46),()=>SaveName());

        modeText=MakeText("Mode",panel,"MODE: EXPEDITION",15,TextAnchor.MiddleLeft,new Vector2(-300,-25),new Vector2(265,36),Color.white);
        AddButton(panel,"CHANGE MODE",new Vector2(-5,-25),new Vector2(195,46),()=>NextMode());
        AddButton(panel,"RELOAD MAP",new Vector2(240,-25),new Vector2(195,46),()=>ReloadMap());
        AddButton(panel,"CHANGE COLOR",new Vector2(-170,-86),new Vector2(240,48),()=>ChangeColor());
        AddButton(panel,"MUTE VOICE",new Vector2(100,-86),new Vector2(240,48),()=>ToggleVoiceMute());
#if CLAW_PLAYFAB_PHOTON && CLAW_PHOTON_FUSION
        AddButton(panel,"PLAYFAB SIGN IN",new Vector2(-170,-118),new Vector2(240,44),()=>SignIn());
#endif

        MakeText("ChatHeading",panel,"ROOM CHAT",14,TextAnchor.MiddleLeft,new Vector2(-300,-155),new Vector2(220,28),new Color(.65f,.84f,1f));
        chatText=MakeText("ChatFeed",panel,"Chat is ready. Be respectful; you can mute voice at any time.",12,TextAnchor.UpperLeft,new Vector2(-285,-240),new Vector2(570,118),Color.white);
        chatInput=MakeInput(panel,"Type a short message...",new Vector2(-95,-330),new Vector2(420,48));
        chatInput.onSelect.AddListener(_=>ShowKeyboard(chatInput));
        AddButton(panel,"SEND",new Vector2(245,-330),new Vector2(130,48),()=>SendChat());
        AddButton(panel,"LEAVE ROOM",new Vector2(-130,-390),new Vector2(205,48),()=>LeaveRoom());
        AddButton(panel,"CLOSE MENU",new Vector2(130,-390),new Vector2(205,48),()=>SetOpen(false));
        BuildVirtualKeyboard(panel);

        SetOpen(true);
        if(ClawGameSession.Instance!=null)RefreshLabels(ClawGameSession.Instance);
    }

    private void Update()
    {
        if(ClawGameSession.Instance!=null)RefreshLabels(ClawGameSession.Instance);
    }

    private void RefreshLabels(ClawGameSession session)
    {
        if(statusText!=null && lastStatus!=session.Status){lastStatus=session.Status;statusText.text=session.Status;}
        if(modeText!=null)modeText.text="MODE: "+session.Mode.ToString().ToUpperInvariant();
    }

    private void SetOpen(bool open)
    {
        IsOpen=open;
        if(ActiveCanvas!=null)ActiveCanvas.gameObject.SetActive(open);
    }

    private void BuildVirtualKeyboard(Transform parent)
    {
        keyboardPanel=MakeRect("VirtualKeyboard",parent,new Vector2(700,420),new Vector2(0,-170));
        var background=keyboardPanel.gameObject.AddComponent<Image>();
        background.color=new Color(.025f,.035f,.06f,.99f);
        MakeText("KeyboardTitle",keyboardPanel,"ON-SCREEN KEYBOARD",15,TextAnchor.MiddleCenter,new Vector2(0,184),new Vector2(640,28),new Color(.55f,.86f,1f));

        string digits="1234567890";
        for(int i=0;i<digits.Length;i++)
        {
            string key=digits[i].ToString();
            AddButton(keyboardPanel,key,new Vector2(-270+i*60,135),new Vector2(54,42),()=>AppendKeyboard(key));
        }
        AddKeyboardRow("QWERTYUIOP",82,-261,58);
        AddKeyboardRow("ASDFGHJKL",28,-232,58);
        AddKeyboardRow("ZXCVBNM",-26,-174,58);
        AddButton(keyboardPanel,"SPACE",new Vector2(-190,-100),new Vector2(190,44),()=>AppendKeyboard(" "));
        AddButton(keyboardPanel,"BACKSPACE",new Vector2(5,-100),new Vector2(140,44),()=>BackspaceKeyboard());
        AddButton(keyboardPanel,"CLEAR",new Vector2(150,-100),new Vector2(100,44),()=>ClearKeyboard());
        AddButton(keyboardPanel,"DONE",new Vector2(265,-100),new Vector2(100,44),()=>FinishKeyboard());
        keyboardPanel.gameObject.SetActive(false);
    }

    private void AddKeyboardRow(string keys,float y,float startX,float step)
    {
        for(int i=0;i<keys.Length;i++)
        {
            string key=keys[i].ToString();
            AddButton(keyboardPanel,key,new Vector2(startX+i*step,y),new Vector2(52,42),()=>AppendKeyboard(key));
        }
    }

    private void ShowKeyboard(InputField field)
    {
        activeInput=field;
        if(keyboardPanel!=null)keyboardPanel.gameObject.SetActive(true);
        SetStatus("Use the on-screen keys, then press DONE.");
    }

    private void AppendKeyboard(string value)
    {
        if(activeInput==null)return;
        int limit=activeInput.characterLimit>0?activeInput.characterLimit:90;
        if(activeInput.text.Length>=limit)return;
        activeInput.text+=value;
        activeInput.caretPosition=activeInput.text.Length;
    }

    private void BackspaceKeyboard()
    {
        if(activeInput==null||activeInput.text.Length==0)return;
        activeInput.text=activeInput.text.Substring(0,activeInput.text.Length-1);
        activeInput.caretPosition=activeInput.text.Length;
    }

    private void ClearKeyboard()
    {
        if(activeInput!=null)activeInput.text="";
    }

    private void FinishKeyboard()
    {
        if(keyboardPanel!=null)keyboardPanel.gameObject.SetActive(false);
        activeInput=null;
        if(EventSystem.current!=null)EventSystem.current.SetSelectedGameObject(null);
    }

    private void QuickPlay()
    {
#if CLAW_PHOTON_FUSION
        ClawFusionRoomConnector.EnsureInstance().QuickPlay();
#else
        SetStatus("Online services are not installed in this source build yet.");
#endif
    }

    private void CreatePrivateRoom()
    {
        string code=ClawRoomCode.Generate();
        if(roomInput!=null)roomInput.text=code;
        if(roomCodeText!=null)roomCodeText.text="SHARE THIS CODE WITH FRIENDS:  "+code;
#if CLAW_PHOTON_FUSION
        ClawFusionRoomConnector.EnsureInstance().CreatePrivateRoom(code);
#else
        SetStatus("Room code created locally: "+code+". Photon Fusion must be installed to make it joinable online.");
#endif
    }

    private void JoinPrivateRoom()
    {
        string code=ClawRoomCode.Normalize(roomInput!=null?roomInput.text:"");
        if(!ClawRoomCode.IsValid(code)){SetStatus("Enter a valid 6-character room code.");return;}
#if CLAW_PHOTON_FUSION
        ClawFusionRoomConnector.EnsureInstance().JoinPrivateRoom(code);
#else
        SetStatus("Code accepted locally. Photon Fusion must be installed to join online.");
#endif
    }

    private void NextMode()
    {
        if(ClawGameSession.Instance==null)return;
        int next=((int)ClawGameSession.Instance.Mode+1)%6;
        ClawGameSession.Instance.SetMode((ClawGameMode)next);
        ClawGameSession.Instance.SetStatus("Mode changed. Reload the current map to apply the selected rules.");
    }

    private void SaveName()
    {
        string value=nameInput!=null?nameInput.text.Trim():"Player";
        if(string.IsNullOrEmpty(value))value="Player";
        if(value.Length>16)value=value.Substring(0,16);
        PlayerPrefs.SetString("CLAW_NAME",value);PlayerPrefs.Save();
        ClawGameSession.Instance?.SetStatus("Player name saved: "+value);
    }

    private void LeaveRoom()
    {
#if CLAW_PHOTON_FUSION
        if(ClawFusionRoomConnector.Instance!=null)ClawFusionRoomConnector.Instance.LeaveRoom();
#else
        SetStatus("You are in offline training; no online room is connected.");
#endif
    }

    private void ReloadMap()
    {
        var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
#if CLAW_PHOTON_FUSION
        if(ClawFusionRoomConnector.Instance!=null && ClawFusionRoomConnector.Instance.Connected)
        {
            ClawNetworkSceneController.RequestTravel(scene.name);
            return;
        }
#endif
        UnityEngine.SceneManagement.SceneManager.LoadScene(scene.buildIndex);
    }

    private void ChangeColor()
    {
        var player=ClawPlayerRigFactory.LocalPlayer;
        if(player!=null){var color=player.GetComponent<ClawPlayerColor>();if(color!=null)color.SelectNext();}
        SetStatus("Avatar color changed.");
    }

#if CLAW_PLAYFAB_PHOTON && CLAW_PHOTON_FUSION
    private void SignIn()
    {
        var player=ClawPlayerRigFactory.LocalPlayer;
        var auth=player!=null?player.GetComponent<ClawPlayFabPhotonAuth>():null;
        if(auth==null){SetStatus("PlayFab authentication component is unavailable.");return;}
        SetStatus("Signing in...");auth.LoginWithDeviceForPrototype();
    }
#endif

    private void ToggleVoiceMute()
    {
        ClawVoiceControls.ToggleMuteAll();
        SetStatus(ClawVoiceControls.IsMuted?"Voice muted locally.":"Voice unmuted locally. Hold X on the left controller to talk when Voice is installed.");
    }

    private void SendChat()
    {
        string message=chatInput!=null?chatInput.text.Trim():"";
        if(string.IsNullOrEmpty(message))return;
        if(message.Length>90)message=message.Substring(0,90);
        string playerName=PlayerPrefs.GetString("CLAW_NAME","Player");
        string line=playerName+": "+message;
#if CLAW_PHOTON_FUSION
        bool sent=ClawFusionChatRelay.Send(message);
        if(!sent)AppendChat("[LOCAL] "+line);
#else
        AppendChat("[LOCAL] "+line);
#endif
        if(chatInput!=null)chatInput.text="";
    }

    public static void AppendChat(string line)
    {
        if(Instance==null)return;
        Instance.chatLines.Add(line);
        while(Instance.chatLines.Count>5)Instance.chatLines.RemoveAt(0);
        if(Instance.chatText!=null)Instance.chatText.text=string.Join("\n",Instance.chatLines);
    }

    private void SetStatus(string value){ClawGameSession.Instance?.SetStatus(value);if(statusText!=null)statusText.text=value;}

    private static RectTransform MakeRect(string name,Transform parent,Vector2 size,Vector2 anchored)
    {
        var go=new GameObject(name,typeof(RectTransform));var rect=go.GetComponent<RectTransform>();
        rect.SetParent(parent,false);rect.anchorMin=rect.anchorMax=new Vector2(.5f,.5f);rect.pivot=new Vector2(.5f,.5f);
        rect.sizeDelta=size;rect.anchoredPosition=anchored;return rect;
    }

    private static Text MakeText(string name,Transform parent,string value,int size,TextAnchor anchor,Vector2 pos,Vector2 dimensions,Color color)
    {
        var rect=MakeRect(name,parent,dimensions,pos);var text=rect.gameObject.AddComponent<Text>();
        text.font=Resources.GetBuiltinResource<Font>("Arial.ttf");text.text=value;text.fontSize=size;text.alignment=anchor;text.color=color;
        text.horizontalOverflow=HorizontalWrapMode.Wrap;text.verticalOverflow=VerticalWrapMode.Overflow;
        return text;
    }

    private void AddButton(Transform parent,string label,Vector2 pos,Vector2 size,UnityEngine.Events.UnityAction action)
    {
        var rect=MakeRect("Button_"+label.Replace(' ','_'),parent,size,pos);
        var image=rect.gameObject.AddComponent<Image>();image.color=new Color(.12f,.20f,.32f,.98f);
        var button=rect.gameObject.AddComponent<Button>();button.targetGraphic=image;button.onClick.AddListener(action);
        var text=MakeText("Label",rect,label,15,TextAnchor.MiddleCenter,Vector2.zero,size,new Color(.88f,.94f,1f));
        text.fontStyle=FontStyle.Bold;
    }

    private InputField MakeInput(Transform parent,string placeholder,Vector2 pos,Vector2 size)
    {
        var rect=MakeRect("Input_"+placeholder.Replace(' ','_'),parent,size,pos);
        var image=rect.gameObject.AddComponent<Image>();image.color=new Color(.09f,.12f,.18f,1f);
        var field=rect.gameObject.AddComponent<InputField>();
        var textRect=MakeRect("Text",rect,new Vector2(size.x-18,size.y-8),Vector2.zero);
        var text=textRect.gameObject.AddComponent<Text>();text.font=Resources.GetBuiltinResource<Font>("Arial.ttf");text.fontSize=15;text.color=Color.white;
        text.alignment=TextAnchor.MiddleLeft;text.supportRichText=false;field.textComponent=text;
        var placeRect=MakeRect("Placeholder",rect,new Vector2(size.x-18,size.y-8),Vector2.zero);
        var place=placeRect.gameObject.AddComponent<Text>();place.font=Resources.GetBuiltinResource<Font>("Arial.ttf");place.fontSize=14;place.fontStyle=FontStyle.Italic;
        place.color=new Color(.5f,.57f,.67f);place.text=placeholder;place.alignment=TextAnchor.MiddleLeft;field.placeholder=place;
        field.lineType=InputField.LineType.SingleLine;field.characterLimit=placeholder.Contains("code")?6:90;
        return field;
    }
}
