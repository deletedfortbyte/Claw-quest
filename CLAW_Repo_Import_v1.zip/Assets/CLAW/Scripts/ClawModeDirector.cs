using UnityEngine;

/// <summary>Local first-slice mode rules. Networked competitive variants need authoritative shared state.</summary>
public sealed class ClawModeDirector : MonoBehaviour
{
    [SerializeField] private float survivalSeconds = 180f;
    private float elapsed;
    private bool finished;
    private GameObject threat;

    private void Start()
    {
        ConfigureFromSession();
    }

    /// <summary>Applies the private-room owner's advertised mode to this local prototype scene.</summary>
    public void ApplyRoomMode(ClawGameMode mode)
    {
        ClawGameSession.Instance?.SetMode(mode);
        if (threat != null) Destroy(threat);
        threat = null;
        elapsed = 0f;
        finished = false;
        ConfigureFromSession();
    }

    private void ConfigureFromSession()
    {
        ClawGameSession session = ClawGameSession.Instance;
        if (session == null) return;
        if (session.Mode == ClawGameMode.MonsterSurvival ||
            session.Mode == ClawGameMode.HideAndSeek ||
            session.Mode == ClawGameMode.Infection)
            CreateThreat();

        switch (session.Mode)
        {
            case ClawGameMode.Parkour:
                session.SetStatus("Parkour time trial started. Reach the extraction marker!");
                break;
            case ClawGameMode.MonsterSurvival:
                session.SetStatus("Survive for 3 minutes. Avoid the roaming creature.");
                break;
            case ClawGameMode.HideAndSeek:
                session.SetStatus("Hide and seek: avoid being found and reach extraction.");
                break;
            case ClawGameMode.Infection:
                session.SetStatus("Infection training: avoid the creature, find 3 signal cores, then extract.");
                break;
        }
    }

    private void Update()
    {
        ClawGameSession session = ClawGameSession.Instance;
        if (session == null || finished) return;
        elapsed += Time.deltaTime;
        if (session.Mode == ClawGameMode.MonsterSurvival)
        {
            float left = Mathf.Max(0f, survivalSeconds - elapsed);
            if (left <= 0f)
            {
                finished = true;
                session.CompleteSurvival();
                if (threat != null) threat.SetActive(false);
            }
            else if (Time.frameCount % 45 == 0)
                session.SetStatus("SURVIVE  " + Mathf.CeilToInt(left) + "s remaining. Keep moving!");
        }
        else if (session.Mode == ClawGameMode.Parkour && session.ObjectiveComplete)
        {
            finished = true;
            session.RecordParkourTime(elapsed);
        }
    }

    private void CreateThreat()
    {
        GameObject player = ClawPlayerRigFactory.LocalPlayer;
        if (player == null) return;
        Vector3 spawn = player.transform.position + new Vector3(0f, 0f, 12f);
        threat = new GameObject("CLAW_Roaming_Threat");
        threat.transform.position = spawn;
        Material shell = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard"));
        shell.color = new Color(.12f, .16f, .22f);

        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        body.name = "ThreatBody";
        body.transform.SetParent(threat.transform, false);
        body.transform.localPosition = new Vector3(0f, .75f, 0f);
        body.transform.localScale = new Vector3(.85f, 1.15f, .75f);
        body.GetComponent<Renderer>().sharedMaterial = shell;
        Destroy(body.GetComponent<Collider>());

        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "ThreatHead";
        head.transform.SetParent(threat.transform, false);
        head.transform.localPosition = new Vector3(0f, 1.5f, .08f);
        head.transform.localScale = Vector3.one * .58f;
        head.GetComponent<Renderer>().sharedMaterial = shell;
        Destroy(head.GetComponent<Collider>());

        SphereCollider trigger = threat.AddComponent<SphereCollider>();
        trigger.isTrigger = true;
        trigger.radius = .9f;
        trigger.center = new Vector3(0f, .8f, 0f);
        threat.AddComponent<ClawMonsterAI>();
    }
}
