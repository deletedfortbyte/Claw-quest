using UnityEngine;

/// <summary>Creates the local XR player and local game-mode controller for each generated map scene.</summary>
public sealed class ClawSceneInitialiser : MonoBehaviour
{
    [SerializeField] private string mapName="WarehouseLobby";
    [SerializeField] private Transform playerSpawn;
    public void Configure(string sceneName,Transform spawn){mapName=sceneName;playerSpawn=spawn;}

    private void Start()
    {
        if(ClawGameSession.Instance==null)
        {
            var session=new GameObject("CLAW_Session_Runtime");
            session.AddComponent<ClawGameSession>();
        }
        Vector3 spawn=playerSpawn!=null?playerSpawn.position:Vector3.zero;
        ClawGameSession.Instance?.BeginMap(mapName,spawn);
        ClawPlayerRigFactory.Create(spawn);
        if(GetComponent<ClawModeDirector>()==null) gameObject.AddComponent<ClawModeDirector>();
    }
}
