#if CLAW_PHOTON_FUSION
using Fusion;
using UnityEngine;

/// <summary>Shared-mode spawner: every peer creates exactly its own player avatar.</summary>
public sealed class ClawFusionPlayerSpawner : SimulationBehaviour, IPlayerJoined
{
    [SerializeField] private NetworkObject playerPrefab;
    public void SetPlayerPrefab(NetworkObject prefab){playerPrefab=prefab;}

    public void PlayerJoined(PlayerRef player)
    {
        if(player!=Runner.LocalPlayer || playerPrefab==null)return;
        if(Runner.TryGetPlayerObject(player,out _))return;
        Vector3 position=ClawPlayerRigFactory.LocalPlayer!=null?ClawPlayerRigFactory.LocalPlayer.transform.position:Vector3.zero;
        NetworkObject avatar=Runner.Spawn(playerPrefab,position,Quaternion.identity);
        Runner.SetPlayerObject(player,avatar);
        var data=avatar.GetComponent<ClawNetworkAvatar>();
        if(data!=null)data.InitialiseLocalPlayer();
    }
}
#endif
