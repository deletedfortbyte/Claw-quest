using UnityEngine;

[RequireComponent(typeof(Collider))]
public sealed class ClawCheckpoint : MonoBehaviour
{
    [SerializeField] private Transform respawnPoint;
    private void Reset() { GetComponent<Collider>().isTrigger = true; }
    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        Vector3 p = respawnPoint != null ? respawnPoint.position : transform.position;
        ClawGameSession.Instance?.SetCheckpoint(p);
        ClawGameSession.Instance?.SetStatus("Checkpoint reached.");
    }
}
