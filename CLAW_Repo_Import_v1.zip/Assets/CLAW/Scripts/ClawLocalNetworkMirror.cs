#if CLAW_PHOTON_FUSION
using UnityEngine;

/// <summary>Marker component binding the local tracked body to its network avatar.</summary>
public sealed class ClawLocalNetworkMirror : MonoBehaviour
{
    private ClawNetworkAvatar avatar;
    public void Bind(ClawNetworkAvatar target){avatar=target;}
    private void OnDisable(){avatar=null;}
}
#endif
