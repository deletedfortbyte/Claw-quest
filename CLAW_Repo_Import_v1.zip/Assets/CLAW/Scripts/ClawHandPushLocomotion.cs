using UnityEngine;
using UnityEngine.XR;

/// <summary>Surface-contact locomotion: tracked controller movement pushes the body in the opposite direction.</summary>
[RequireComponent(typeof(Rigidbody), typeof(CapsuleCollider))]
public sealed class ClawHandPushLocomotion : MonoBehaviour
{
    [SerializeField] private Transform trackingOrigin, head, leftHand, rightHand, leftArm, rightArm;
    [SerializeField, Range(.04f,.2f)] private float handRadius = .09f;
    [SerializeField, Range(.4f,1.8f)] private float pushStrength = 1.1f;
    [SerializeField, Range(.005f,.08f)] private float minimumDelta = .012f;
    [SerializeField, Range(.12f,.45f)] private float maximumDelta = .34f;
    [SerializeField, Range(.05f,.35f)] private float maximumBodyStep = .24f;
    [SerializeField] private LayerMask surfaceMask = ~0;

    private Rigidbody body;
    private Vector3 lastLeftLocal, lastRightLocal;
    private bool hasLeft, hasRight;
    private InputDevice leftDevice, rightDevice;

    public Transform LeftHand => leftHand;
    public Transform RightHand => rightHand;
    public Transform Head => head;

    public void Configure(Transform origin, Transform headTransform, Transform left, Transform right, Transform armL, Transform armR)
    { trackingOrigin=origin; head=headTransform; leftHand=left; rightHand=right; leftArm=armL; rightArm=armR; }

    private void Awake()
    {
        body=GetComponent<Rigidbody>();
        surfaceMask &= ~(1 << gameObject.layer);
        leftDevice=InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        rightDevice=InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
    }

    private void OnEnable() { hasLeft=false; hasRight=false; }

    private void LateUpdate()
    {
        if (trackingOrigin == null) return;
        UpdateDeviceReferences();
        InputDevice hmd=InputDevices.GetDeviceAtXRNode(XRNode.Head);
        if (head!=null && hmd.isValid)
        {
            if (hmd.TryGetFeatureValue(CommonUsages.devicePosition,out Vector3 hp)) head.localPosition=hp;
            if (hmd.TryGetFeatureValue(CommonUsages.deviceRotation,out Quaternion hr)) head.localRotation=hr;
        }
        UpdateTrackedHand(leftDevice,leftHand);
        UpdateTrackedHand(rightDevice,rightHand);
        UpdateArm(leftArm,new Vector3(-.28f,1.18f,0f),leftHand);
        UpdateArm(rightArm,new Vector3(.28f,1.18f,0f),rightHand);
    }

    private void FixedUpdate()
    {
        UpdateHand(XRNode.LeftHand,leftHand,ref lastLeftLocal,ref hasLeft);
        UpdateHand(XRNode.RightHand,rightHand,ref lastRightLocal,ref hasRight);
    }

    private void UpdateDeviceReferences()
    {
        if (!leftDevice.isValid) leftDevice=InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        if (!rightDevice.isValid) rightDevice=InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
    }

    private void UpdateTrackedHand(InputDevice device,Transform visual)
    {
        if (visual==null || !device.isValid) return;
        if (device.TryGetFeatureValue(CommonUsages.devicePosition,out Vector3 p)) visual.position=trackingOrigin.TransformPoint(p);
        if (device.TryGetFeatureValue(CommonUsages.deviceRotation,out Quaternion r)) visual.rotation=trackingOrigin.rotation*r;
    }

    private void UpdateHand(XRNode node,Transform visual,ref Vector3 previousLocal,ref bool initialized)
    {
        InputDevice device=node==XRNode.LeftHand?leftDevice:rightDevice;
        if (!device.isValid || !device.TryGetFeatureValue(CommonUsages.devicePosition,out Vector3 localPosition))
        { initialized=false; return; }

        Vector3 currentLocal=localPosition;
        Vector3 currentWorld=trackingOrigin.TransformPoint(currentLocal);
        if (visual!=null) visual.position=currentWorld;
        if (!initialized) { previousLocal=currentLocal; initialized=true; return; }

        Vector3 localDelta=currentLocal-previousLocal;
        previousLocal=currentLocal;
        float distance=localDelta.magnitude;
        if (distance<minimumDelta || distance>maximumDelta) return;

        Vector3 worldDelta=trackingOrigin.TransformDirection(localDelta);
        Vector3 sweepStart=currentWorld-worldDelta;
        bool touching=Physics.CheckSphere(sweepStart,handRadius+.025f,surfaceMask,QueryTriggerInteraction.Ignore)
            || Physics.CheckSphere(currentWorld,handRadius+.025f,surfaceMask,QueryTriggerInteraction.Ignore)
            || Physics.SphereCast(sweepStart,handRadius,worldDelta.normalized,out _,distance,surfaceMask,QueryTriggerInteraction.Ignore);
        if (!touching) return;

        Vector3 step=Vector3.ClampMagnitude(-worldDelta*pushStrength,maximumBodyStep);
        // Keep the hand-push movement collision-aware so a long reach cannot teleport through a wall.
        if (body.SweepTest(step.normalized,out RaycastHit hit,step.magnitude,QueryTriggerInteraction.Ignore))
            step*=Mathf.Clamp01(hit.distance/Mathf.Max(.001f,step.magnitude)-.03f);
        body.MovePosition(body.position+step);
    }

    private static void UpdateArm(Transform arm,Vector3 shoulderLocal,Transform hand)
    {
        if (arm==null||hand==null||arm.parent==null) return;
        Vector3 shoulder=arm.parent.TransformPoint(shoulderLocal);
        Vector3 d=hand.position-shoulder;
        if (d.sqrMagnitude<.0001f) return;
        arm.position=(shoulder+hand.position)*.5f;
        arm.rotation=Quaternion.FromToRotation(Vector3.up,d.normalized);
        arm.localScale=new Vector3(.17f,d.magnitude*.5f,.17f);
    }
}
