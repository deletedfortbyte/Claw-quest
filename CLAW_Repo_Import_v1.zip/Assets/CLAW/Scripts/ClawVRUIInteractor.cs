using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR;

/// <summary>Controller laser pointer for the world-space in-headset menu.</summary>
public sealed class ClawVRUIInteractor : MonoBehaviour
{
    [SerializeField] private Transform cameraTransform,leftHand,rightHand;
    private bool menuPressed;
    private readonly Dictionary<XRNode,bool> wasPressed=new Dictionary<XRNode,bool>();
    private readonly List<RaycastResult> results=new List<RaycastResult>();
    public void Configure(Transform camera,Transform left,Transform right){cameraTransform=camera;leftHand=left;rightHand=right;}

    private void Update()
    {
        var left=InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        if(left.isValid&&left.TryGetFeatureValue(CommonUsages.menuButton,out bool pressed))
        {
            if(pressed&&!menuPressed)ClawRuntimeMenu.Toggle();
            menuPressed=pressed;
        }
        ProcessHand(XRNode.LeftHand,leftHand);
        ProcessHand(XRNode.RightHand,rightHand);
    }

    private void ProcessHand(XRNode node,Transform hand)
    {
        if(hand==null||!ClawRuntimeMenu.IsOpen)return;
        InputDevice device=InputDevices.GetDeviceAtXRNode(node);
        if(!device.isValid)return;
        bool down=false;
        if(!device.TryGetFeatureValue(CommonUsages.triggerButton,out down) && device.TryGetFeatureValue(CommonUsages.trigger,out float trigger))down=trigger>.72f;
        bool previous=wasPressed.ContainsKey(node)&&wasPressed[node];
        wasPressed[node]=down;
        if(!down||previous||EventSystem.current==null||cameraTransform==null)return;

        var canvas=ClawRuntimeMenu.ActiveCanvas;
        if(canvas==null)return;
        RectTransform rect=canvas.GetComponent<RectTransform>();
        Plane plane=new Plane(rect.forward,rect.position);
        Ray ray=new Ray(hand.position,hand.forward);
        if(!plane.Raycast(ray,out float enter)||enter<0)return;
        Vector3 hit=ray.GetPoint(enter);
        Vector3 screen=cameraTransform.GetComponent<Camera>().WorldToScreenPoint(hit);
        var pointer=new PointerEventData(EventSystem.current){position=new Vector2(screen.x,screen.y),button=PointerEventData.InputButton.Left};
        results.Clear();canvas.GetComponent<GraphicRaycaster>().Raycast(pointer,results);
        if(results.Count==0)return;
        GameObject target=results[0].gameObject;
        ExecuteEvents.ExecuteHierarchy(target,pointer,ExecuteEvents.pointerEnterHandler);
        GameObject clickHandler=ExecuteEvents.GetEventHandler<IPointerClickHandler>(target);
        if(clickHandler==null)return;
        pointer.pointerPress=clickHandler;
        pointer.rawPointerPress=target;
        ExecuteEvents.Execute(clickHandler,pointer,ExecuteEvents.pointerDownHandler);
        ExecuteEvents.Execute(clickHandler,pointer,ExecuteEvents.pointerUpHandler);
        ExecuteEvents.Execute(clickHandler,pointer,ExecuteEvents.pointerClickHandler);
        pointer.pointerPress=null;
    }
}
