using UnityEngine;

public enum ClawGameMode { Expedition, Infection, MonsterSurvival, HideAndSeek, Parkour, FreeRoam }

/// <summary>Persistent local game state, objectives, progression and map selection.</summary>
public sealed class ClawGameSession : MonoBehaviour
{
    public static ClawGameSession Instance { get; private set; }
    public int SignalCores { get; private set; }
    public int RequiredCores { get; private set; } = 3;
    public string Status { get; private set; } = "Explore the warehouse.";
    public string CurrentMap { get; private set; } = "WarehouseLobby";
    public Vector3 Checkpoint { get; private set; }
    public bool HasCheckpoint { get; private set; }
    public bool ObjectiveComplete { get; private set; }
    public bool SurvivalComplete { get; private set; }
    public ClawGameMode Mode { get; private set; } = ClawGameMode.Expedition;
    public int CoresTotal { get; private set; }
    public int AreasSecured { get; private set; }
    public int BestParkourSeconds { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        CoresTotal = PlayerPrefs.GetInt("CLAW_CORES_TOTAL", 0);
        AreasSecured = PlayerPrefs.GetInt("CLAW_AREAS_SECURED", 0);
        BestParkourSeconds = PlayerPrefs.GetInt("CLAW_BEST_PARKOUR", 0);
        Mode = (ClawGameMode)Mathf.Clamp(PlayerPrefs.GetInt("CLAW_MODE", 0), 0, 5);
    }

    public void SetMode(ClawGameMode mode)
    {
        Mode = mode;
        PlayerPrefs.SetInt("CLAW_MODE", (int)mode);
        PlayerPrefs.Save();
        SetStatus("Mode: " + Mode.ToString());
    }

    public void BeginMap(string mapName, Vector3 spawn)
    {
        CurrentMap = mapName;
        SignalCores = 0;
        ObjectiveComplete = false;
        SurvivalComplete = false;
        SetCheckpoint(spawn);
        switch (Mode)
        {
            case ClawGameMode.FreeRoam: Status = "Free roam. Explore the map and find shortcuts."; break;
            case ClawGameMode.Parkour: Status = "Time trial: reach the extraction marker."; break;
            case ClawGameMode.MonsterSurvival: Status = "Survive the roaming creature. Find safe routes."; break;
            case ClawGameMode.HideAndSeek: Status = "Hide, move quietly, and reach the exit."; break;
            case ClawGameMode.Infection: Status = "Infection training: avoid contact and reach extraction."; break;
            default: Status = "Find 3 signal cores, then reach extraction."; break;
        }
    }

    public bool UsesCoreObjective => Mode == ClawGameMode.Expedition || Mode == ClawGameMode.Infection;

    public void CollectCore()
    {
        if (ObjectiveComplete || !UsesCoreObjective) return;
        SignalCores++;
        CoresTotal++;
        PlayerPrefs.SetInt("CLAW_CORES_TOTAL", CoresTotal);
        PlayerPrefs.Save();
        Status = SignalCores >= RequiredCores ? "All cores found. Reach the extraction gate." : $"Signal cores: {SignalCores}/{RequiredCores}";
    }

    public bool TryExtract()
    {
        if (ObjectiveComplete) return true;
        if (Mode == ClawGameMode.MonsterSurvival && !SurvivalComplete)
        { Status = "Survive the full 3 minutes before extracting."; return false; }
        if (Mode == ClawGameMode.FreeRoam) { Status = "Free roam: explore every corner."; return true; }
        if (UsesCoreObjective && SignalCores < RequiredCores)
        { Status = $"Need {RequiredCores - SignalCores} more signal core(s)."; return false; }
        ObjectiveComplete = true;
        AreasSecured++;
        PlayerPrefs.SetInt("CLAW_AREAS_SECURED", AreasSecured);
        PlayerPrefs.Save();
        Status = "Area secured. Use a portal to continue exploring.";
        return true;
    }

    public void CompleteSurvival(){SurvivalComplete=true;SetStatus("You survived! Reach the extraction gate.");}

    public void RecordParkourTime(float elapsed)
    {
        int seconds = Mathf.Max(1, Mathf.RoundToInt(elapsed));
        if (BestParkourSeconds == 0 || seconds < BestParkourSeconds)
        {
            BestParkourSeconds = seconds;
            PlayerPrefs.SetInt("CLAW_BEST_PARKOUR", seconds);
            PlayerPrefs.Save();
            SetStatus("New best time: " + seconds + "s");
        }
        else SetStatus("Time: " + seconds + "s | Best: " + BestParkourSeconds + "s");
    }

    public void SetCheckpoint(Vector3 point) { Checkpoint = point; HasCheckpoint = true; }
    public void SetStatus(string value) { Status = value; }
}
