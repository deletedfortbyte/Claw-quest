#if CLAW_PHOTON_FUSION
using Fusion;
using UnityEngine;

/// <summary>Replicated avatar pose, display name, palette and tracked hands for Fusion Shared Mode.</summary>
public sealed class ClawNetworkAvatar : NetworkBehaviour
{
    [Networked] public NetworkString<_16> PlayerName {get;set;}
    [Networked] public int ColorIndex {get;set;}
    [Networked] public Vector3 HeadLocal {get;set;}
    [Networked] public Vector3 LeftHandLocal {get;set;}
    [Networked] public Vector3 RightHandLocal {get;set;}

    private Transform head,leftHand,rightHand,leftArm,rightArm;
    private TextMesh nameLabel;
    private Renderer[] renderers;
    private static readonly Color[] Palette={new Color(.48f,.31f,.86f),new Color(.13f,.72f,.68f),new Color(.67f,.84f,.24f),new Color(.94f,.52f,.18f),new Color(.22f,.49f,.88f),new Color(.86f,.27f,.37f)};

    public override void Spawned()
    {
        head=transform.Find("Avatar/Head");leftHand=transform.Find("Avatar/LeftHand");rightHand=transform.Find("Avatar/RightHand");
        leftArm=transform.Find("Avatar/LeftArm");rightArm=transform.Find("Avatar/RightArm");
        var label=transform.Find("Avatar/NameLabel");if(label!=null)nameLabel=label.GetComponent<TextMesh>();
        renderers=GetComponentsInChildren<Renderer>(true);
        if(Object.HasStateAuthority)
        {
            PlayerName=PlayerPrefs.GetString("CLAW_NAME","Player");
            ColorIndex=Mathf.Abs(PlayerPrefs.GetInt("CLAW_COLOR",0))%Palette.Length;
            ClawFusionChatRelay.Local=GetComponent<ClawFusionChatRelay>();
            var local=ClawPlayerRigFactory.LocalPlayer;
            if(local!=null)local.GetComponent<ClawLocalNetworkMirror>()?.Bind(this);
            // Hide only the duplicate local network visuals; remote peers still see this avatar.
            foreach(var renderer in renderers)renderer.enabled=false;
        }
        ApplyColor();
    }

    public void InitialiseLocalPlayer()
    {
        if(!Object.HasStateAuthority)return;
        PlayerName=PlayerPrefs.GetString("CLAW_NAME","Player");
        ColorIndex=Mathf.Abs(PlayerPrefs.GetInt("CLAW_COLOR",0))%Palette.Length;
        ClawFusionChatRelay.Local=GetComponent<ClawFusionChatRelay>();
        var local=ClawPlayerRigFactory.LocalPlayer;
        if(local!=null)
        {
            var mirror=local.GetComponent<ClawLocalNetworkMirror>();
            if(mirror==null)mirror=local.AddComponent<ClawLocalNetworkMirror>();
            mirror.Bind(this);
        }
    }

    public override void FixedUpdateNetwork()
    {
        if(!Object.HasStateAuthority)return;
        var local=ClawPlayerRigFactory.LocalPlayer;
        if(local==null)return;
        transform.SetPositionAndRotation(local.transform.position,local.transform.rotation);
        ColorIndex=Mathf.Abs(PlayerPrefs.GetInt("CLAW_COLOR",0))%Palette.Length;
        PlayerName=PlayerPrefs.GetString("CLAW_NAME","Player");
        var mover=local.GetComponent<ClawHandPushLocomotion>();
        if(mover!=null)
        {
            HeadLocal=transform.InverseTransformPoint(mover.Head.position);
            LeftHandLocal=transform.InverseTransformPoint(mover.LeftHand.position);
            RightHandLocal=transform.InverseTransformPoint(mover.RightHand.position);
        }
    }

    public override void Render()
    {
        if(Object.HasStateAuthority)return;
        if(head!=null)head.localPosition=HeadLocal;
        if(leftHand!=null)leftHand.localPosition=LeftHandLocal;
        if(rightHand!=null)rightHand.localPosition=RightHandLocal;
        UpdateArm(leftArm,new Vector3(-.28f,1.18f,0f),leftHand);
        UpdateArm(rightArm,new Vector3(.28f,1.18f,0f),rightHand);
        if(nameLabel!=null)nameLabel.text=PlayerName.ToString();
        ApplyColor();
    }

    private void UpdateArm(Transform arm,Vector3 shoulderLocal,Transform hand)
    {
        if(arm==null||hand==null)return;
        Vector3 shoulder=arm.parent.TransformPoint(shoulderLocal);
        Vector3 handWorld=transform.TransformPoint(hand.localPosition);
        Vector3 d=handWorld-shoulder;
        if(d.sqrMagnitude<.0001f)return;
        arm.position=(shoulder+handWorld)*.5f;
        arm.rotation=Quaternion.FromToRotation(Vector3.up,d.normalized);
        arm.localScale=new Vector3(.17f,d.magnitude*.5f,.17f);
    }

    private void ApplyColor()
    {
        if(renderers==null)return;
        Color color=Palette[Mathf.Abs(ColorIndex)%Palette.Length];
        var block=new MaterialPropertyBlock();
        foreach(var r in renderers)
        {
            if(r==null)continue;
            string n=r.transform.name;
            if(n.Contains("Face")||n.Contains("Eye")||n.Contains("NameLabel"))continue;
            r.GetPropertyBlock(block);block.SetColor("_BaseColor",color);block.SetColor("_Color",color);r.SetPropertyBlock(block);
        }
    }
}
#endif
