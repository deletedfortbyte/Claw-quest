using System;
using System.Reflection;
using UnityEngine;

/// <summary>Optional Photon Voice for Fusion bootstrap without a hard package dependency in offline builds.</summary>
public static class ClawPhotonVoiceBootstrap
{
    public static bool AttachToRunner(GameObject runnerObject)
    {
        Type clientType=FindType("FusionVoiceClient");
        if(clientType==null)return false;
        Component client=runnerObject.GetComponent(clientType);
        if(client==null)client=runnerObject.AddComponent(clientType);
        SetBool(client,"UseFusionAppSettings",true);
        // This project uses a Recorder on each network-avatar prefab, paired by VoiceNetworkObject.
        SetBool(client,"UsePrimaryRecorder",false);
        return true;
    }

    private static Type FindType(string shortName)
    {
        foreach(var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            try{foreach(Type type in assembly.GetTypes())if(type.Name==shortName)return type;}
            catch(ReflectionTypeLoadException ex){foreach(Type type in ex.Types)if(type!=null&&type.Name==shortName)return type;}
        }
        return null;
    }
    private static void SetBool(object target,string name,bool value)
    {
        PropertyInfo p=target.GetType().GetProperty(name,BindingFlags.Instance|BindingFlags.Public);
        if(p!=null&&p.CanWrite&&p.PropertyType==typeof(bool))p.SetValue(target,value,null);
    }
}
