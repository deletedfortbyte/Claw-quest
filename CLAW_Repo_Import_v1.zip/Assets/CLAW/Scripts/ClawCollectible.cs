using UnityEngine;

[RequireComponent(typeof(Collider))]
public sealed class ClawCollectible : MonoBehaviour
{
    private bool collected;
    private bool pendingNetwork;
    private void Reset(){GetComponent<Collider>().isTrigger=true;}

    private void OnTriggerEnter(Collider other)
    {
        if(collected||pendingNetwork||!other.CompareTag("Player"))return;
#if CLAW_PHOTON_FUSION
        pendingNetwork=ClawFusionChatRelay.SendObjective(name);
        if(pendingNetwork)return;
#endif
        CollectLocal();
    }

    public void CollectFromNetwork(){pendingNetwork=false;CollectLocal();}
    private void CollectLocal()
    {
        if(collected)return;
        collected=true;
        ClawGameSession.Instance?.CollectCore();
        Destroy(gameObject);
    }
}
