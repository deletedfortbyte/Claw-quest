using UnityEngine;

[RequireComponent(typeof(Collider))]
public sealed class ClawExtractionGate : MonoBehaviour
{
    private bool triggered;
    private void Reset(){GetComponent<Collider>().isTrigger=true;}
    private void OnTriggerEnter(Collider other)
    {
        if(triggered||!other.CompareTag("Player"))return;
        var session=ClawGameSession.Instance;
        if(session==null)return;
        if(session.UsesCoreObjective && session.SignalCores<session.RequiredCores){session.TryExtract();return;}
#if CLAW_PHOTON_FUSION
        if(ClawFusionChatRelay.SendExtraction()){triggered=true;return;}
#endif
        triggered=session.TryExtract();
    }
    public void CompleteFromNetwork(){triggered=true;ClawGameSession.Instance?.TryExtract();}
}
