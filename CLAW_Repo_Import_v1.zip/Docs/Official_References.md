# Official References (checked 2026-11-19)

- Unity 6 support / Unity 6.3 LTS: https://unity.com/releases/unity-6/support
- Unity Build Automation quick start: https://learn.unity.com/tutorial/unity-build-automation
- Unity Build Automation source control: https://docs.unity.com/en-us/build-automation/get-started-with-build-automation/connect-your-version-control-system
- Unity Build Automation custom scripts: https://docs.unity.com/en-us/build-automation/advanced-build-configuration/run-custom-scripts-during-the-build-process
- Unity Build Automation specify scenes: https://docs.unity.com/en-us/build-automation/advanced-build-configuration/specify-the-scene-to-be-built
- Meta XR Plugin Management / OpenXR setup: https://developers.meta.com/vr/documentation/unity/unity-xr-plugin/
- Fusion 2 matchmaking: https://doc.photonengine.com/fusion/v2/manual/connection-and-matchmaking/matchmaking
- Fusion 2 + PlayFab authentication: https://doc.photonengine.com/fusion/v2/manual/connection-and-matchmaking/authentication/playfab
- Photon Voice for Fusion: https://doc.photonengine.com/voice/v2/getting-started/voice-for-fusion
- PlayFab Photon quickstart: https://learn.microsoft.com/en-us/xbox/playfab/live-service-management/service-gateway/add-ons/photon/quickstart
