# Meta Quest 3S configuration checklist

This project targets standalone Android VR. The settings below are prerequisites; the presence of an OpenXR package in `manifest.json` does not by itself prove that the Android OpenXR loader and Meta Quest feature profile are enabled.

1. Open with Unity `6000.3.29f1` and let Package Manager resolve packages.
2. Install Meta's current Unity XR / Meta XR SDK package compatible with the editor version. Use the official Meta XR Plugin Management and OpenXR instructions; do not mix unsupported package versions.
3. Project Settings → XR Plug-in Management → Android: enable **OpenXR** and install/enable the Meta Quest feature group. Enable the Touch Plus controller interaction profile.
4. Confirm the Android OpenXR loader is selected for the Android build target. Do not generate an APK until Unity reports the Android XR loader configured.
5. Run **CLAW → Generate All Prototype Scenes**. Check that all three `.unity` scenes appear in Build Settings.
6. Confirm Android settings: ARM64, IL2CPP, minimum API 29 (the build script applies these), landscape orientation, and a mobile URP renderer.
7. Check microphone permission / Android manifest behavior if Photon Voice is installed. CLAW requests microphone permission only when the user first holds X to talk; voice transmission remains push-to-talk and is muted by default.
8. The Android manifest declares microphone permission for the optional Photon Voice path; the app requests it when the player first holds X to talk.
9. Build Warehouse Lobby first. Install on Quest 3S and test: HMD pose, controller tracking, hand push against a wall/floor, capsule collision, falling recovery, world-space menu rays, map transitions, frame pacing, and app pause/resume.
10. Test two or more Quest headsets for player avatars, room codes, text chat, voice, mute, proximity falloff, disconnect/reconnect, and leaving a room.

Do not call the game tested until these checks are completed on-device. Target 72 FPS as a baseline and profile before trying higher refresh rates; no FPS measurement has yet been made for this project.


## Automated part

After Package Manager finishes resolving packages, the Android build script runs **CLAW → Quest → Configure Android OpenXR** automatically. It creates Android XR Plug-in Management settings, assigns the Unity OpenXR loader, and attempts to enable a feature set whose name includes “Meta Quest”. The helper uses Unity's OpenXR feature-set API; it logs a warning rather than guessing when the feature set is not discoverable.

Before a real Quest build, open **Edit → Project Settings → XR Plug-in Management → OpenXR (Android)** and verify the **Meta Quest feature group** and an Oculus Touch controller interaction profile are enabled. Confirm Android is the active build target, Android Build Support modules are installed, and the OpenXR Project Validation panel has no blocking errors. Run **CLAW → Build → Check Android OpenXR Setup**.

Unity lists `com.unity.xr.meta-openxr` 2.7.0 as released for Unity 6000.3. The package is included in this source project's manifest. Unity and Meta document enabling the Android OpenXR provider and Meta Quest feature group as part of Quest setup.
