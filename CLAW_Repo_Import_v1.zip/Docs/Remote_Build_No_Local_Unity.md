# Remote Android build from a phone

This project includes a GitHub Actions workflow at `.github/workflows/build-claw-quest-apk.yml`. It asks GameCI to run Unity `6000.3.29f1`, generate the CLAW scenes, and produce `Builds/Android/CLAW-Quest.apk` for Android ARM64 / IL2CPP.

## One-time repository setup

1. In `deletedfortbyte/Claw-quest`, replace the incorrect root file `CLAW_Repo_Import_v1.zip` with the valid import archive supplied with this project. Keep the exact filename and commit the replacement. The existing import workflow extracts the Unity project into the repository root. It also copies the `.github` directory from the project archive, which installs the APK build workflow alongside the importer.
2. Open the repository's **Settings → Secrets and variables → Actions** and add a repository secret named `UNITY_LICENSE`.
3. The value must be a Unity license file/serial authorization accepted by GameCI for the Unity Personal account that owns the project. Obtain/export it through Unity's official license process. Do not paste the license into chat, commit it to Git, or place it in the Unity project. The workflow cannot compile without a valid license secret.

## Start a cloud APK build

1. Open the repository's **Actions** tab.
2. Select **Build CLAW Quest APK**.
3. Press **Run workflow** on branch `main`.
4. Open the run and wait for a completed result. If it fails, open the failed step's log; common blockers are missing/invalid `UNITY_LICENSE`, Unity package resolution, XR/OpenXR configuration, or C# compiler/API errors.
5. For a successful run, open its **Artifacts** section and download `CLAW-Quest-APK`. The artifact ZIP contains `CLAW-Quest.apk`.

The workflow is included as source automation only; it has not been run successfully in this archive's authoring environment. A successful compile is not proof of correct headset behavior. Install and test the APK on Quest 3S before calling the game playable.

## Required online integrations remain separate

The offline source build does not turn on live multiplayer or voice automatically. To enable those paths, install compatible official Photon Fusion 2, Photon Voice 2/Fusion Voice integration, and PlayFab Unity SDK packages; set the appropriate App IDs; define the documented scripting symbols; generate/register the network avatar prefab; and test with multiple Quest clients. A Fusion App ID must be created separately in Photon Console; the Realtime App ID is not a Fusion App ID. Keep PlayFab Developer Secret Keys server-side only.
