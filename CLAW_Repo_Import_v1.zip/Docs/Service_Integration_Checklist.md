# CLAW online services and voice integration

This source contains optional integration code; the services are not live until the official SDKs are imported, configured, compiled, and tested. Keep the default offline build usable by leaving the scripting symbols undefined until setup is complete.

## 1. Photon Fusion 2 — rooms, players, text chat, map travel

1. Create a Photon application of type **Fusion** in the Photon dashboard. Do not reuse the supplied Realtime App ID as the Fusion ID; app types are distinct.
2. Import Photon Fusion 2 using the official Fusion Hub / package instructions for the chosen Fusion 2 version.
3. In Player Settings → Other Settings → Scripting Define Symbols, add `CLAW_PHOTON_FUSION` for both Editor and Android. Ensure the Fusion package compiles before enabling the symbol.
4. Run **CLAW → Networking → Apply Known Photon App IDs**. This editor utility fills the already supplied Realtime and Voice IDs when the installed SDK exposes those settings. Enter the new Fusion App ID in `AppIdFusion` manually.
5. Run **CLAW → Generate All Prototype Scenes** again after the Fusion symbol is enabled. This places the network scene coordinator in the three generated map scenes.
6. Run **CLAW → Networking → Build Network Avatar Prefab**. This creates `Assets/Resources/CLAW_NetworkPlayer.prefab` with a NetworkObject, NetworkTransform, player display model, name label, and chat relay. If Photon Voice is installed, it also attempts to attach the VoiceNetworkObject / Recorder / Speaker components.
7. In Fusion Hub, rebuild / update the Fusion Network Project Config prefab object table after creating the prefab.
8. Test with two separately installed Quest builds. Public Quick Play searches the `CLAW` lobby. Private rooms use six-character session names; joining a private code has client-side session creation disabled so a mistyped code cannot create a new room.

Implemented in the optional Fusion path: Shared Mode player avatar pose/name/color replication, short transient room text chat (with a basic send cooldown), public Quick Play filtered by selected mode, private room codes that carry the room creator's selected mode to joiners, shared signal-core/extraction callbacks, and Master Client coordinated map travel. The player avatar is a procedural placeholder. These paths have not been compiled or tested against a concrete Fusion SDK version yet. Shared Mode rooms use Photon Cloud sessions/relay and do not constitute dedicated authoritative game servers.

## 2. PlayFab account and Photon token

1. Import the official PlayFab Unity SDK.
2. Verify Title ID `A03E5` in the PlayFab Game Manager.
3. Configure Photon custom authentication to use the server-side PlayFab Photon integration and the matching endpoint: `https://A03E5.playfabapi.com/photon/authenticate`.
4. Ensure both symbols are defined: `CLAW_PHOTON_FUSION;CLAW_PLAYFAB_PHOTON`.
5. Use the in-game PlayFab sign-in button for the device-login prototype. The code logs in with a device custom ID and requests a Photon token for the Fusion App ID.
6. Confirm the PlayFab Photon add-on / custom-auth settings accept the token request before testing rooms.

Device Custom ID is an early prototype identity only. Before release, add account linking, account recovery, age-appropriate safety/reporting, service-side progression validation, and a safer identity flow.

**Never place the PlayFab Developer Secret Key in Unity assets, client code, Android builds, GitHub, or Obsidian.** The key belongs only in protected server-side service configuration. Rotate it if it was exposed.

## 3. Photon Voice 2 — room voice

1. Install Photon Voice 2 and the Fusion Voice integration through the official Fusion Hub Addons workflow for a supported Fusion 2.1+ setup.
2. Set the supplied Voice App ID as `AppIdVoice` in Photon Realtime Settings. The editor helper can apply it if the installed SDK exposes the standard settings field.
3. Build the network avatar prefab again after Voice is imported. Confirm the prefab has a `VoiceNetworkObject`, `Recorder`, `Speaker`, and a spatial AudioSource; the generated source uses reflection to avoid a hard dependency in offline builds.
4. The runner bootstrap looks for `FusionVoiceClient` and configures it to use Fusion App Settings and the per-avatar Recorder. `Assets/Plugins/Android/AndroidManifest.xml` declares `RECORD_AUDIO`, and the app requests microphone permission when the player first holds X.
5. In headset, hold **X on the left controller** to transmit. Releasing X stops transmitting. Incoming speakers can be muted locally from the in-headset menu.
6. Approve the Android microphone permission prompt. Test two Quest headsets in the same room and verify spatial volume at different distances, mute, reconnect, app pause/resume, and microphone denial.
7. Validate whether your PlayFab/custom-auth flow also needs a separate Voice authentication token. Do not assume Fusion auth values automatically work for every Voice authentication configuration.

If the Fusion Voice add-on or its component types are missing at build time, online voice is unavailable; the project does not synthesize or simulate voice.

## 4. Pre-release online checklist

- Server-side validation for inventory/progression/objectives.
- Room abuse controls, kick/ban/report workflows and block/mute controls.
- Text chat filtering and rate limits.
- Voice privacy, consent, mute, and reporting UX.
- Reconnection, host migration / Shared Mode master-client departure, and room closure behavior.
- Network latency and Quest performance tests with multiple real headsets.

## Supplied application identifiers

The Realtime and Voice App IDs were supplied in the project conversation and are stored in the optional editor helper. A Fusion-type App ID has not been supplied, so this project intentionally does not invent one. No secret key is stored in this project.
