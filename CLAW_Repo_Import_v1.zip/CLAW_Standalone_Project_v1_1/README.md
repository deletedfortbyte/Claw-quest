# CLAW Standalone Project v1.1 — playable training-slice source

This is an expanded Unity project scaffold for CLAW, not a prebuilt APK. It contains three original map blockouts, gameplay scene-generation tools, local XR player bootstrap, arm-push movement prototype, spawn/checkpoint/respawn support, and a local collect-and-extract objective loop.

## Maps and training run
Each generated scene starts the local player at a marked start pad. Touch the two checkpoint pads to update your respawn location. Collect all three glowing power cells, then enter the green extraction gate. Falling below the map returns the player to the active checkpoint. The Warehouse Lobby has portals to Cold Storage and Maintenance Tunnels; both secondary maps have a portal back to the lobby. The overlay displays objective progress and status. See `Preview/Gameplay_Marker_Layout.png` for the positions of starts, checkpoints, pickups, extraction gates and travel portals.

## Build the scenes in Unity
1. Open this folder in **Unity 6.3 LTS / Editor 6000.3.29f1**. Let package import finish.
2. Open **CLAW → Maps → Build All Playable Map Scenes**. This generates Warehouse Lobby, Cold Storage and Maintenance Tunnels under `Assets/CLAW/Scenes/` and adds them to Build Settings.
3. Open **CLAW → Build → Configure Android ARM64 Player Settings**.
4. Open **Edit → Project Settings → XR Plug-in Management**. Enable **OpenXR** for Android (the project manifest includes the provider, but the loader is not auto-enabled in the serialized project settings). Select the Meta Quest feature group / Quest controller interaction profile available in the installed OpenXR package. Set the Android target to ARM64 and IL2CPP (the menu above sets these player settings).
5. Set the first scene, `Warehouse_Lobby`, first in Build Settings if it is not already first.
6. Choose **CLAW → Build → Build Quest APK**. Output target: `Builds/Android/CLAW.apk`.

## Controls and locomotion
The runtime player rig reads the HMD and left/right XR controller/hand-device poses exposed by Unity XR Input Devices. Actual optical hand tracking must be enabled by the selected OpenXR hand-tracking provider/profile; it is not guaranteed by this scaffold alone. Push tracked hands against environment surfaces to move the body. There is no joystick walking in the player locomotion script. The capsule body uses gravity and static environment collision.

## Current limits — read before calling this release-ready
- The scenes are blockout geometry with static combined MeshColliders, not final art.
- The current locomotion is an early arm-push solver; it needs Quest testing for hand locking/sliding, corner contacts, tracking dropouts, two-hand conflicts, slopes and comfort.
- The game loop is local/offline only. Fusion rooms, PlayFab login, network avatar sync, color UI, voice, monster AI and full mode selection are not connected. The warehouse station labels explicitly say online is not configured.
- No generated Unity scene, C# compilation, Android APK, or Quest 3S test is included in this ZIP. The Editor must import the project and run the scene builder before a real APK build.
- The optional GLB player reference in `Assets/CLAW/Models/Player/` is not wired into the runtime rig; it is retained as a reference asset. The runtime uses a simple procedural training-body placeholder.
- If Unity reports package-resolution or API errors, fix those using the actual Editor/Build log; the versions in `Packages/manifest.json` have not been compiled in this environment.

## Project settings
Editor version selected: 6000.3.29f1. Packages: URP is intentionally not required by the runtime scripts; XR Management 4.6.1, OpenXR 1.15.1 and UGUI 2.0.0 are included as the planned Quest baseline. URP can be added from Package Manager if the project uses it.

## Contents
- `Assets/CLAW/Maps/` — visual OBJ/MTL and separate collision OBJ/MTL for all three maps.
- `Assets/CLAW/Scripts/Runtime/` — player, XR pose, arm-push, spawn, checkpoint, respawn, objective and exit scripts.
- `Assets/Editor/ClawMapSceneBuilder.cs` — generate scenes and place gameplay systems.
- `Assets/Editor/ClawAndroidBuild.cs` — configure Android player settings and invoke a local Unity APK build.
- `Assets/CLAW/Models/Player/Claw_Legless_Player_Prototype.glb` — previous rigged GLB reference; not integrated in this playable slice.
- `Preview/` and `CLAW_Maps_v1_0_Overview.png` — visual references.
