#if UNITY_EDITOR
using System.Collections.Generic;
using CLAW;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

public static class ClawMapSceneBuilder
{
    private const string MapFolder = "Assets/CLAW/Maps/";
    private const string SceneFolder = "Assets/CLAW/Scenes/";

    private sealed class MapDef
    {
        public string Name, Title;
        public Vector3 Start, StartEuler, CheckpointA, CheckpointB, Exit;
        public Vector3[] Pickups;
        public Vector3 BoundsSize;
    }

    private static readonly MapDef[] Maps =
    {
        new MapDef { Name="Warehouse_Lobby", Title="WAREHOUSE LOBBY", Start=new Vector3(0,.06f,-13),
            StartEuler=Vector3.zero, CheckpointA=new Vector3(0,.06f,5), CheckpointB=new Vector3(-7.2f,4.85f,23.3f),
            Exit=new Vector3(0,.1f,-20.2f), Pickups=new[]{new Vector3(0,1.25f,5.0f),new Vector3(0,1.25f,18.3f),new Vector3(0,5.7f,23.2f)}, BoundsSize=new Vector3(58,2,72) },
        new MapDef { Name="Cold_Storage", Title="COLD STORAGE", Start=new Vector3(0,.06f,-13.7f),
            StartEuler=Vector3.zero, CheckpointA=new Vector3(-5,.06f,-5), CheckpointB=new Vector3(5,.06f,9),
            Exit=new Vector3(14,.1f,13), Pickups=new[]{new Vector3(-5,1.2f,-5.5f),new Vector3(5,1.2f,1.0f),new Vector3(5,1.2f,9.0f)}, BoundsSize=new Vector3(52,2,50) },
        new MapDef { Name="Maintenance_Tunnels", Title="MAINTENANCE TUNNELS", Start=new Vector3(0,.06f,-12),
            StartEuler=new Vector3(0,0,0), CheckpointA=new Vector3(0,.06f,4), CheckpointB=new Vector3(0,.06f,19),
            Exit=new Vector3(2,.1f,-24), Pickups=new[]{new Vector3(0,1.2f,15),new Vector3(15,1.2f,0),new Vector3(-15,1.2f,0)}, BoundsSize=new Vector3(64,2,64) }
    };

    [MenuItem("CLAW/Maps/Build All Playable Map Scenes")]
    public static void BuildAll()
    {
        EnsureFolder("Assets/CLAW", "Scenes");
        List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>();
        foreach (EditorBuildSettingsScene entry in EditorBuildSettings.scenes)
            if (entry.enabled && !entry.path.StartsWith(SceneFolder)) scenes.Add(entry);
        foreach (MapDef map in Maps)
        {
            string path = BuildOne(map);
            if (!string.IsNullOrEmpty(path)) scenes.Add(new EditorBuildSettingsScene(path, true));
        }
        EditorBuildSettings.scenes = scenes.ToArray();
        AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        Debug.Log("CLAW: Built 3 training-run scenes with start spawns, checkpoints, pickups, exits, and fall recovery.");
    }

    [MenuItem("CLAW/Maps/Build Warehouse Lobby")]
    private static void BuildWarehouse() => BuildOneAndSave(Maps[0]);
    [MenuItem("CLAW/Maps/Build Cold Storage")]
    private static void BuildCold() => BuildOneAndSave(Maps[1]);
    [MenuItem("CLAW/Maps/Build Maintenance Tunnels")]
    private static void BuildMaintenance() => BuildOneAndSave(Maps[2]);

    private static void BuildOneAndSave(MapDef map)
    {
        EnsureFolder("Assets/CLAW", "Scenes");
        string path = BuildOne(map);
        if (!string.IsNullOrEmpty(path)) { AssetDatabase.SaveAssets(); AssetDatabase.Refresh(); Debug.Log("CLAW scene saved: " + path); }
    }

    private static string BuildOne(MapDef map)
    {
        GameObject visualAsset = AssetDatabase.LoadAssetAtPath<GameObject>(MapFolder + map.Name + ".obj");
        GameObject collisionAsset = AssetDatabase.LoadAssetAtPath<GameObject>(MapFolder + map.Name + "_Collision.obj");
        if (visualAsset == null || collisionAsset == null)
        {
            Debug.LogError("CLAW: Missing OBJ or collision OBJ for " + map.Name + ". Check Assets/CLAW/Maps.");
            return null;
        }

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("CLAW_MAP_" + map.Name);
        GameObject visual = PrefabUtility.InstantiatePrefab(visualAsset) as GameObject;
        visual.name = map.Name + "_Visible_Geometry"; visual.transform.SetParent(root.transform, false);
        GameObject collision = PrefabUtility.InstantiatePrefab(collisionAsset) as GameObject;
        collision.name = map.Name + "_Collision_Import"; collision.transform.SetParent(root.transform, false);
        BuildCombinedCollider(collision, root.transform);

        GameObject systems = new GameObject("CLAW_Gameplay_Systems");
        ClawMapSpawnManager spawns = systems.AddComponent<ClawMapSpawnManager>();
        ClawFacilityRunManager run = systems.AddComponent<ClawFacilityRunManager>();
        run.Configure(map.Title, map.Pickups.Length);
        ClawRuntimeBootstrap bootstrap = systems.AddComponent<ClawRuntimeBootstrap>();
        var serialized = new SerializedObject(bootstrap);
        serialized.FindProperty("spawnManager").objectReferenceValue = spawns;
        serialized.ApplyModifiedPropertiesWithoutUndo();

        CreateSpawnPoint(root.transform, "START_Courtyard", map.Start, map.StartEuler, ClawSpawnPointKind.Start, true, "Main Spawn", true);
        CreateCheckpoint(root.transform, "CHECKPOINT_A", map.CheckpointA, "Checkpoint A");
        CreateCheckpoint(root.transform, "CHECKPOINT_B", map.CheckpointB, "Checkpoint B");
        for (int i=0;i<map.Pickups.Length;i++) CreatePickup(root.transform, "POWER_CELL_"+(i+1), map.Pickups[i]);
        CreateExit(root.transform, map.Exit);
        CreateMapPortals(root.transform, map.Name);
        CreateFallRecovery(root.transform, map.BoundsSize);
        CreateMapLighting(root.transform, map.Name);
        CreateStationLabels(root.transform, map.Name);

        string output = SceneFolder + map.Name + ".unity";
        EditorSceneManager.SaveScene(scene, output);
        return output;
    }

    private static void BuildCombinedCollider(GameObject source, Transform root)
    {
        List<CombineInstance> combine = new List<CombineInstance>();
        foreach (MeshFilter filter in source.GetComponentsInChildren<MeshFilter>(true))
            if (filter.sharedMesh != null) combine.Add(new CombineInstance { mesh=filter.sharedMesh, transform=filter.transform.localToWorldMatrix });
        if (combine.Count == 0) { Debug.LogError("CLAW: Collision OBJ has no meshes."); return; }
        Mesh mesh = new Mesh { name="CLAW_Combined_Static_Collision", indexFormat=combine.Count*24>65000?IndexFormat.UInt32:IndexFormat.UInt16 };
        mesh.CombineMeshes(combine.ToArray(), true, true, false); mesh.RecalculateBounds();
        GameObject colliderObject = new GameObject("CLAW_Static_Environment_Collider");
        colliderObject.transform.SetParent(root, false);
        MeshCollider collider = colliderObject.AddComponent<MeshCollider>(); collider.sharedMesh = mesh;
        colliderObject.isStatic = true;
        source.SetActive(false);
    }

    private static ClawSpawnPoint CreateSpawnPoint(Transform parent,string name,Vector3 position,Vector3 euler,
        ClawSpawnPointKind kind,bool primary,string label,bool visual)
    {
        GameObject point = new GameObject(name); point.transform.SetParent(parent,false);
        point.transform.SetPositionAndRotation(position,Quaternion.Euler(euler));
        ClawSpawnPoint component = point.AddComponent<ClawSpawnPoint>(); component.Configure(kind,primary,label);
        if (visual) CreatePad(parent,name+"_Visual",position,new Color(.15f,.65f,.62f),2.4f);
        return component;
    }

    private static void CreateCheckpoint(Transform parent,string name,Vector3 position,string label)
    {
        ClawSpawnPoint point = CreateSpawnPoint(parent,name+"_Spawn",position,Vector3.zero,ClawSpawnPointKind.Checkpoint,false,label,true);
        GameObject trigger = new GameObject(name+"_Trigger"); trigger.transform.SetParent(parent,false); trigger.transform.position=position+Vector3.up*.8f;
        SphereCollider collider=trigger.AddComponent<SphereCollider>(); collider.isTrigger=true; collider.radius=1.1f;
        ClawCheckpoint checkpoint=trigger.AddComponent<ClawCheckpoint>();
        SerializedObject so=new SerializedObject(checkpoint); so.FindProperty("spawnPoint").objectReferenceValue=point; so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void CreatePad(Transform parent,string name,Vector3 position,Color color,float diameter)
    {
        GameObject pad=GameObject.CreatePrimitive(PrimitiveType.Cylinder); pad.name=name; pad.layer=0;
        pad.transform.SetParent(parent,false); pad.transform.position=position+Vector3.up*.025f;
        pad.transform.localScale=new Vector3(diameter,.035f,diameter);
        Collider c=pad.GetComponent<Collider>(); if(c!=null) Object.DestroyImmediate(c);
        pad.GetComponent<Renderer>().sharedMaterial=MakeMaterial("CLAW_Marker_"+name,color);
    }

    private static void CreatePickup(Transform parent,string name,Vector3 position)
    {
        GameObject pickup=GameObject.CreatePrimitive(PrimitiveType.Sphere); pickup.name=name; pickup.layer=0;
        pickup.transform.SetParent(parent,false); pickup.transform.position=position; pickup.transform.localScale=Vector3.one*.42f;
        SphereCollider collider=pickup.GetComponent<SphereCollider>(); collider.isTrigger=true; collider.radius=1.8f;
        pickup.AddComponent<ClawObjectivePickup>();
        pickup.GetComponent<Renderer>().sharedMaterial=MakeMaterial("CLAW_PowerCell_Mat",new Color(.2f,.9f,.78f),true);
        GameObject ring=GameObject.CreatePrimitive(PrimitiveType.Cylinder); ring.name=name+"_Ring"; ring.transform.SetParent(pickup.transform,false);
        ring.transform.localPosition=Vector3.zero; ring.transform.localScale=new Vector3(1.8f,.05f,1.8f);
        Collider ringCollider=ring.GetComponent<Collider>(); if(ringCollider!=null) Object.DestroyImmediate(ringCollider);
        ring.GetComponent<Renderer>().sharedMaterial=MakeMaterial("CLAW_PowerCell_Ring",new Color(.5f,.32f,.95f),true);
    }

    private static void CreateExit(Transform parent,Vector3 position)
    {
        GameObject exit=GameObject.CreatePrimitive(PrimitiveType.Cube); exit.name="CLAW_Extraction_Exit"; exit.layer=0;
        exit.transform.SetParent(parent,false); exit.transform.position=position+new Vector3(0,1.2f,0); exit.transform.localScale=new Vector3(4.5f,2.4f,1.2f);
        BoxCollider box=exit.GetComponent<BoxCollider>(); box.isTrigger=true;
        exit.AddComponent<ClawExitZone>();
        exit.GetComponent<Renderer>().sharedMaterial=MakeMaterial("CLAW_Exit_Glow",new Color(.1f,.8f,.55f),true);
    }

    private static void CreateFallRecovery(Transform parent,Vector3 size)
    {
        GameObject volume=new GameObject("CLAW_Fall_Recovery_Volume"); volume.transform.SetParent(parent,false);
        volume.transform.position=new Vector3(0,-5,0);
        BoxCollider box=volume.AddComponent<BoxCollider>(); box.isTrigger=true; box.size=size;
        volume.AddComponent<ClawRespawnVolume>();
    }


    private static void CreateMapPortals(Transform parent,string mapName)
    {
        if(mapName=="Warehouse_Lobby")
        {
            CreatePortal(parent,"PORTAL_COLD_STORAGE",new Vector3(-11,.1f,-19.2f),"Cold_Storage","COLD STORAGE",new Color(.25f,.75f,1f));
            CreatePortal(parent,"PORTAL_MAINTENANCE",new Vector3(11,.1f,-19.2f),"Maintenance_Tunnels","MAINTENANCE",new Color(.7f,.35f,1f));
        }
        else if(mapName=="Cold_Storage")
            CreatePortal(parent,"PORTAL_RETURN_LOBBY",new Vector3(14,.1f,-12.5f),"Warehouse_Lobby","RETURN TO LOBBY",new Color(.2f,.85f,.65f));
        else
            CreatePortal(parent,"PORTAL_RETURN_LOBBY",new Vector3(-2.2f,.1f,-22.5f),"Warehouse_Lobby","RETURN TO LOBBY",new Color(.2f,.85f,.65f));
    }

    private static void CreatePortal(Transform parent,string name,Vector3 position,string destination,string label,Color color)
    {
        GameObject portal=new GameObject(name); portal.transform.SetParent(parent,false); portal.transform.position=position+Vector3.up*1.55f;
        BoxCollider trigger=portal.AddComponent<BoxCollider>(); trigger.isTrigger=true; trigger.size=new Vector3(2.8f,3.2f,1.2f);
        ClawScenePortal portalScript=portal.AddComponent<ClawScenePortal>(); portalScript.Configure(destination);
        Material frame=MakeMaterial("CLAW_Portal_"+destination,color,true);
        CreatePortalPart(portal.transform,"Frame_Left",new Vector3(-1.3f,0,0),new Vector3(.18f,3.1f,.24f),frame);
        CreatePortalPart(portal.transform,"Frame_Right",new Vector3(1.3f,0,0),new Vector3(.18f,3.1f,.24f),frame);
        CreatePortalPart(portal.transform,"Frame_Top",new Vector3(0,1.48f,0),new Vector3(2.75f,.18f,.24f),frame);
        CreatePortalPart(portal.transform,"Frame_Bottom",new Vector3(0,-1.48f,0),new Vector3(2.75f,.18f,.24f),frame);
        CreateText(portal.transform,"Portal_Label",new Vector3(0,1.85f,0),label,Color.white);
    }

    private static void CreatePortalPart(Transform parent,string name,Vector3 localPosition,Vector3 scale,Material material)
    {
        GameObject part=GameObject.CreatePrimitive(PrimitiveType.Cube); part.name=name; part.transform.SetParent(parent,false);
        part.transform.localPosition=localPosition; part.transform.localScale=scale;
        Collider collider=part.GetComponent<Collider>(); if(collider!=null) Object.DestroyImmediate(collider);
        part.GetComponent<Renderer>().sharedMaterial=material;
    }

    private static void CreateStationLabels(Transform parent,string mapName)
    {
        if(mapName!="Warehouse_Lobby") return;
        CreateText(parent,"RoomCode_Status_Label",new Vector3(-8,2.95f,-7.65f),"ROOM CODES\nONLINE NOT CONFIGURED",Color.white);
        CreateText(parent,"ColorStation_Label",new Vector3(8,2.95f,-7.65f),"PLAYER COLOR\nLOCAL TEST",Color.white);
    }

    private static void CreateText(Transform parent,string name,Vector3 position,string value,Color color)
    {
        GameObject go=new GameObject(name); go.transform.SetParent(parent,false); go.transform.position=position;
        TextMesh text=go.AddComponent<TextMesh>(); text.text=value; text.fontSize=44; text.characterSize=.045f;
        text.anchor=TextAnchor.MiddleCenter; text.alignment=TextAlignment.Center; text.color=color;
    }

    private static void CreateMapLighting(Transform parent,string mapName)
    {
        GameObject lightObject=new GameObject("CLAW_Map_Directional_Light"); lightObject.transform.SetParent(parent,false);
        lightObject.transform.rotation=Quaternion.Euler(48,-32,0);
        Light light=lightObject.AddComponent<Light>(); light.type=LightType.Directional; light.intensity=1.0f; light.shadows=LightShadows.None;
        light.color=mapName=="Cold_Storage"?new Color(.78f,.9f,1f):new Color(1f,.88f,.74f);
        RenderSettings.ambientMode=AmbientMode.Flat;
        RenderSettings.ambientLight=mapName=="Cold_Storage"?new Color(.34f,.43f,.52f):new Color(.34f,.32f,.3f);
        RenderSettings.fog=true; RenderSettings.fogMode=FogMode.ExponentialSquared;
        RenderSettings.fogDensity=mapName=="Maintenance_Tunnels"?.006f:.003f;
        RenderSettings.fogColor=mapName=="Cold_Storage"?new Color(.2f,.3f,.37f):new Color(.12f,.14f,.17f);
    }

    private static Material MakeMaterial(string name,Color color,bool emission=false)
    {
        Shader shader=Shader.Find("Universal Render Pipeline/Lit"); if(shader==null) shader=Shader.Find("Standard");
        Material material=new Material(shader){name=name,color=color};
        if(emission){material.EnableKeyword("_EMISSION"); material.SetColor("_EmissionColor",color*1.5f);}
        string folder="Assets/CLAW/Materials"; EnsureFolder("Assets/CLAW","Materials");
        string path=folder+"/"+name+".mat";
        Material existing=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(existing!=null){existing.shader=material.shader; existing.color=color; if(emission){existing.EnableKeyword("_EMISSION");existing.SetColor("_EmissionColor",color*1.5f);} Object.DestroyImmediate(material); return existing;}
        AssetDatabase.CreateAsset(material,path); return material;
    }

    private static void EnsureFolder(string parent,string child)
    {
        string path=parent+"/"+child; if(!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent,child);
    }
}
#endif
