#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class ClawAndroidBuild
{
    [MenuItem("CLAW/Build/Configure Android ARM64 Player Settings")]
    public static void Configure()
    {
        PlayerSettings.productName = "CLAW";
        PlayerSettings.companyName = "CLAW";
        PlayerSettings.bundleVersion = "0.1.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.clawvr.game");
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29;
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        Debug.Log("CLAW Android player settings configured: ARM64 + IL2CPP. Enable OpenXR for Android in Project Settings > XR Plug-in Management before building.");
    }

    [MenuItem("CLAW/Build/Build Quest APK")]
    public static void BuildApk()
    {
        System.Collections.Generic.List<string> enabledScenes = new System.Collections.Generic.List<string>();
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
            if (scene.enabled) enabledScenes.Add(scene.path);
        string[] scenes = enabledScenes.ToArray();
        if (scenes.Length == 0) { Debug.LogError("CLAW: No scenes in Build Settings. Run CLAW > Maps > Build All Playable Map Scenes first."); return; }
        if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android &&
            !EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
        { Debug.LogError("CLAW: Could not switch to Android. Install the Android Build Support module through Unity Hub."); return; }
        EditorUserBuildSettings.buildAppBundle = false;
        EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
        string output = "Builds/Android/CLAW.apk";
        Directory.CreateDirectory(Path.GetDirectoryName(output));
        BuildPlayerOptions options = new BuildPlayerOptions { scenes=scenes, locationPathName=output, target=BuildTarget.Android, options=BuildOptions.None };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            Debug.Log("CLAW APK BUILD SUCCEEDED: " + Path.GetFullPath(output) + " (" + report.summary.totalSize + " bytes)");
        else
            Debug.LogError("CLAW APK BUILD FAILED: " + report.summary.result + " | " + report.summary.totalErrors + " errors | " + report.summary.totalWarnings + " warnings. See the Editor log for details.");
    }
}
#endif
