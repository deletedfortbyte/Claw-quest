using UnityEngine;

namespace CLAW
{
    /// <summary>Creates the local Quest player rig at runtime. No external prefab is required.</summary>
    [DisallowMultipleComponent]
    public sealed class ClawLocalPlayerRig : MonoBehaviour
    {
        public Rigidbody Body { get; private set; }
        public ClawXRTrackedPoseDriver Tracking { get; private set; }
        public ClawArmPushLocomotion Locomotion { get; private set; }
        public Transform Head { get; private set; }
        private Transform leftArmVisual;
        private Transform rightArmVisual;

        public static ClawLocalPlayerRig Create()
        {
            GameObject root = new GameObject("CLAW_Local_Player");
            root.layer = 2; // Ignore Raycast; player is excluded from hand/environment casts.
            return root.AddComponent<ClawLocalPlayerRig>();
        }

        private void Awake()
        {
            Body = gameObject.AddComponent<Rigidbody>();
            Body.mass = 55f;
            Body.useGravity = true;
            Body.interpolation = RigidbodyInterpolation.Interpolate;
            Body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            Body.constraints = RigidbodyConstraints.FreezeRotation;

            CapsuleCollider capsule = gameObject.AddComponent<CapsuleCollider>();
            capsule.center = new Vector3(0f, 0.78f, 0f);
            capsule.height = 1.56f;
            capsule.radius = 0.29f;

            GameObject trackingSpace = new GameObject("TrackingSpace");
            trackingSpace.layer = 2;
            trackingSpace.transform.SetParent(transform, false);

            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            cameraObject.layer = 2;
            cameraObject.transform.SetParent(trackingSpace.transform, false);
            cameraObject.transform.localPosition = new Vector3(0f, 1.62f, 0f);
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.nearClipPlane = 0.05f; camera.farClipPlane = 100f;
            cameraObject.AddComponent<AudioListener>();
            Head = cameraObject.transform;

            Transform left = CreateHand(trackingSpace.transform, "LeftHand", new Vector3(-0.28f, 1.18f, 0.34f), new Color(0.25f, 0.85f, 0.78f));
            Transform right = CreateHand(trackingSpace.transform, "RightHand", new Vector3(0.28f, 1.18f, 0.34f), new Color(0.55f, 0.38f, 0.95f));
            Renderer leftRenderer = left.GetComponent<Renderer>();
            Renderer rightRenderer = right.GetComponent<Renderer>();

            Tracking = trackingSpace.AddComponent<ClawXRTrackedPoseDriver>();
            Tracking.Configure(Head, left, right, leftRenderer, rightRenderer);
            Locomotion = gameObject.AddComponent<ClawArmPushLocomotion>();
            Locomotion.Configure(Body, Tracking, left, right, Head);

            CreateBodyVisual();
            leftArmVisual = CreateArmVisual("CLAW_Left_Arm", new Color(0.33f, 0.22f, 0.58f));
            rightArmVisual = CreateArmVisual("CLAW_Right_Arm", new Color(0.33f, 0.22f, 0.58f));
        }

        private void Update()
        {
            if (Tracking == null) return;
            if (leftArmVisual != null) leftArmVisual.gameObject.SetActive(Tracking.LeftTracked);
            if (rightArmVisual != null) rightArmVisual.gameObject.SetActive(Tracking.RightTracked);
            if (Tracking.LeftTracked) UpdateArmVisual(leftArmVisual, new Vector3(-0.27f, 1.2f, 0.02f), Tracking.transform.Find("LeftHand"));
            if (Tracking.RightTracked) UpdateArmVisual(rightArmVisual, new Vector3(0.27f, 1.2f, 0.02f), Tracking.transform.Find("RightHand"));
        }

        private Transform CreateHand(Transform parent, string objectName, Vector3 localPosition, Color color)
        {
            GameObject hand = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            hand.name = objectName; hand.layer = 2;
            hand.transform.SetParent(parent, false);
            hand.transform.localPosition = localPosition;
            hand.transform.localScale = Vector3.one * 0.17f;
            Collider collider = hand.GetComponent<Collider>();
            if (collider != null) Destroy(collider);
            Renderer renderer = hand.GetComponent<Renderer>();
            renderer.material = CreateMaterial(color);
            return hand.transform;
        }

        private Transform CreateArmVisual(string objectName, Color color)
        {
            GameObject arm = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            arm.name = objectName; arm.layer = 2;
            arm.transform.SetParent(transform, false);
            Collider collider = arm.GetComponent<Collider>(); if (collider != null) Destroy(collider);
            arm.GetComponent<Renderer>().material = CreateMaterial(color);
            return arm.transform;
        }

        private void UpdateArmVisual(Transform arm, Vector3 shoulderLocal, Transform hand)
        {
            if (arm == null || hand == null) return;
            Vector3 end = hand.localPosition;
            Vector3 delta = end - shoulderLocal;
            float length = delta.magnitude;
            if (length < 0.05f) { arm.gameObject.SetActive(false); return; }
            arm.gameObject.SetActive(true);
            arm.localPosition = (shoulderLocal + end) * 0.5f;
            arm.localRotation = Quaternion.FromToRotation(Vector3.up, delta / length);
            arm.localScale = new Vector3(0.19f, length * 0.5f, 0.19f);
        }

        private void CreateBodyVisual()
        {
            GameObject torso = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            torso.name = "CLAW_Training_Body_Visual"; torso.layer = 2;
            torso.transform.SetParent(transform, false);
            torso.transform.localPosition = new Vector3(0f, 0.78f, 0f);
            torso.transform.localScale = new Vector3(0.58f, 0.78f, 0.48f);
            Collider collider = torso.GetComponent<Collider>(); if (collider != null) Destroy(collider);
            torso.GetComponent<Renderer>().material = CreateMaterial(new Color(0.33f, 0.22f, 0.58f));
        }

        private static Material CreateMaterial(Color color)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            Material material = new Material(shader) { color = color };
            return material;
        }

        public void TeleportTo(Transform spawn)
        {
            if (spawn == null || Body == null) return;
            Body.linearVelocity = Vector3.zero;
            Body.angularVelocity = Vector3.zero;
            Body.position = spawn.position;
            Body.rotation = Quaternion.Euler(0f, spawn.eulerAngles.y, 0f);
            Physics.SyncTransforms();
            if (Tracking != null) Tracking.ResetTrackingDevices();
            if (Locomotion != null) Locomotion.ResetHistory();
        }
    }
}
