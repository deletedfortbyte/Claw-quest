using UnityEngine;

namespace CLAW
{
    [RequireComponent(typeof(Collider))]
    public sealed class ClawCheckpoint : MonoBehaviour
    {
        [SerializeField] private ClawSpawnPoint spawnPoint;
        private void Reset() { GetComponent<Collider>().isTrigger = true; }
        private void Awake()
        {
            if (spawnPoint == null) spawnPoint = GetComponent<ClawSpawnPoint>();
        }
        private void OnTriggerEnter(Collider other)
        {
            if (other.GetComponentInParent<ClawLocalPlayerRig>() == null || spawnPoint == null) return;
            ClawMapSpawnManager manager = FindObjectOfType<ClawMapSpawnManager>();
            if (manager != null) manager.ActivateCheckpoint(spawnPoint);
        }
    }
}
