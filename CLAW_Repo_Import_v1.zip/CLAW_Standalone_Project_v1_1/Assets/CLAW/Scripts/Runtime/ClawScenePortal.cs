using UnityEngine;
using UnityEngine.SceneManagement;

namespace CLAW
{
    [RequireComponent(typeof(BoxCollider))]
    public sealed class ClawScenePortal : MonoBehaviour
    {
        [SerializeField] private string destinationScene;
        private bool isLoading;

        public void Configure(string sceneName) { destinationScene = sceneName; }
        private void Reset() { GetComponent<BoxCollider>().isTrigger = true; }

        private void OnTriggerEnter(Collider other)
        {
            if (isLoading || other.GetComponentInParent<ClawLocalPlayerRig>() == null) return;
            if (string.IsNullOrWhiteSpace(destinationScene)) return;
            if (!Application.CanStreamedLevelBeLoaded(destinationScene))
            {
                ClawFacilityRunManager run = FindObjectOfType<ClawFacilityRunManager>();
                if (run != null) run.SetStatus("Portal unavailable: add " + destinationScene + " to Build Settings.");
                Debug.LogError("CLAW portal destination is not in Build Settings: " + destinationScene);
                return;
            }
            isLoading = true;
            SceneManager.LoadScene(destinationScene, LoadSceneMode.Single);
        }
    }
}
