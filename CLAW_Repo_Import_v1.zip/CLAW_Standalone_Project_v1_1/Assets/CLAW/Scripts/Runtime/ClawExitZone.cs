using UnityEngine;

namespace CLAW
{
    [RequireComponent(typeof(Collider))]
    public sealed class ClawExitZone : MonoBehaviour
    {
        private void Reset() { GetComponent<Collider>().isTrigger = true; }
        private void OnTriggerEnter(Collider other)
        {
            if (other.GetComponentInParent<ClawLocalPlayerRig>() == null) return;
            ClawFacilityRunManager manager = FindObjectOfType<ClawFacilityRunManager>();
            if (manager != null) manager.CompleteRun();
        }
    }
}
