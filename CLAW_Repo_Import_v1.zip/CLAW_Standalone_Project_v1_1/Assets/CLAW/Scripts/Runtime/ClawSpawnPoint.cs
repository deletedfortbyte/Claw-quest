using UnityEngine;

namespace CLAW
{
    public enum ClawSpawnPointKind { Start, Checkpoint }

    [DisallowMultipleComponent]
    public sealed class ClawSpawnPoint : MonoBehaviour
    {
        [SerializeField] private ClawSpawnPointKind kind = ClawSpawnPointKind.Start;
        [SerializeField] private bool primary;
        [SerializeField] private string displayName = "Spawn";

        public ClawSpawnPointKind Kind => kind;
        public bool IsPrimary => primary;
        public string DisplayName => displayName;

        public void Configure(ClawSpawnPointKind pointKind, bool isPrimary, string label)
        {
            kind = pointKind;
            primary = isPrimary;
            displayName = string.IsNullOrWhiteSpace(label) ? "Spawn" : label;
        }
    }
}
