using UnityEngine;

namespace CLAW
{
    /// <summary>
    /// First playable arm-push solver. Tracked hand sweeps against environment colliders;
    /// blocked hand travel pushes the rigidbody in the opposite direction.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public sealed class ClawArmPushLocomotion : MonoBehaviour
    {
        [SerializeField] private Rigidbody body;
        [SerializeField] private ClawXRTrackedPoseDriver tracking;
        [SerializeField] private Transform leftHand, rightHand, head;
        [SerializeField, Min(0.02f)] private float handRadius = 0.085f;
        [SerializeField, Min(0.01f)] private float headRadius = 0.13f;
        [SerializeField, Min(0.01f)] private float maxCorrectionPerStep = 0.12f;
        [SerializeField, Min(0.1f)] private float maxHorizontalSpeed = 7.0f;
        [SerializeField, Min(0.1f)] private float maxVerticalSpeed = 8.0f;
        [SerializeField, Min(0.05f)] private float maxTrackedDelta = 0.45f;
        [SerializeField] private LayerMask environmentMask = ~0;

        private Vector3 previousLeft, previousRight, previousHead, previousBody;
        private bool historyReady;

        public void Configure(Rigidbody rigidbody, ClawXRTrackedPoseDriver poseDriver,
            Transform left, Transform right, Transform headTarget)
        {
            body = rigidbody; tracking = poseDriver; leftHand = left; rightHand = right; head = headTarget;
            ResetHistory();
        }

        private void Awake()
        {
            if (body == null) body = GetComponent<Rigidbody>();
            environmentMask &= ~(1 << 2); // Ignore Raycast layer: excludes this player rig.
        }

        private void OnEnable() => ResetHistory();

        private void FixedUpdate()
        {
            if (body == null || tracking == null || leftHand == null || rightHand == null) return;
            if (!historyReady) { ResetHistory(); return; }

            Vector3 bodyStep = body.position - previousBody;
            Vector3 correction = Vector3.zero;
            int contacts = 0;

            if (tracking.LeftTracked)
                AddHandContact(previousLeft + bodyStep, leftHand.position, handRadius, ref correction, ref contacts);
            if (tracking.RightTracked)
                AddHandContact(previousRight + bodyStep, rightHand.position, handRadius, ref correction, ref contacts);
            if (tracking.HeadTracked && head != null)
                AddHandContact(previousHead + bodyStep, head.position, headRadius, ref correction, ref contacts);

            if (contacts > 0)
            {
                correction /= contacts;
                correction = Vector3.ClampMagnitude(correction, maxCorrectionPerStep);
                if (correction.sqrMagnitude > 0.000001f)
                    body.AddForce(correction / Time.fixedDeltaTime, ForceMode.VelocityChange);
            }

            LimitVelocity();
            previousLeft = leftHand.position;
            previousRight = rightHand.position;
            if (head != null) previousHead = head.position;
            previousBody = body.position;
        }

        private void AddHandContact(Vector3 from, Vector3 to, float radius,
            ref Vector3 correctionSum, ref int contactCount)
        {
            Vector3 travel = to - from;
            float distance = travel.magnitude;
            if (distance < 0.0005f || distance > maxTrackedDelta) return;

            if (!Physics.SphereCast(from, radius, travel / distance, out RaycastHit hit,
                distance, environmentMask, QueryTriggerInteraction.Ignore)) return;

            Vector3 resolved = hit.point + hit.normal * radius;
            Vector3 correction = resolved - to;
            if (correction.sqrMagnitude < 0.000001f) return;
            correctionSum += correction;
            contactCount++;
        }

        private void LimitVelocity()
        {
            Vector3 velocity = body.linearVelocity;
            Vector3 horizontal = new Vector3(velocity.x, 0f, velocity.z);
            if (horizontal.sqrMagnitude > maxHorizontalSpeed * maxHorizontalSpeed)
            {
                horizontal = horizontal.normalized * maxHorizontalSpeed;
                velocity.x = horizontal.x; velocity.z = horizontal.z;
            }
            velocity.y = Mathf.Clamp(velocity.y, -maxVerticalSpeed, maxVerticalSpeed);
            body.linearVelocity = velocity;
        }

        public void ResetHistory()
        {
            if (body == null) body = GetComponent<Rigidbody>();
            if (body == null || leftHand == null || rightHand == null) { historyReady = false; return; }
            previousLeft = leftHand.position; previousRight = rightHand.position;
            previousHead = head != null ? head.position : Vector3.zero;
            previousBody = body.position; historyReady = true;
        }
    }
}
