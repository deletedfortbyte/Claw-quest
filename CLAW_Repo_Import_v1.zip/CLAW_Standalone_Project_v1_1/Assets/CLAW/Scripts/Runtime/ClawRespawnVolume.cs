using UnityEngine;

namespace CLAW
{
    [RequireComponent(typeof(Collider))]
    public sealed class ClawRespawnVolume : MonoBehaviour
    {
        private void Reset() { GetComponent<Collider>().isTrigger = true; }
        private void OnTriggerEnter(Collider other)
        {
            ClawLocalPlayerRig player = other.GetComponentInParent<ClawLocalPlayerRig>();
            if (player == null) return;
            ClawMapSpawnManager manager = FindObjectOfType<ClawMapSpawnManager>();
            if (manager != null) manager.Respawn(player);
        }
    }
}
