using UnityEngine;

namespace CLAW
{
    /// <summary>Bootstraps the local XR player when a generated map scene loads.</summary>
    public sealed class ClawRuntimeBootstrap : MonoBehaviour
    {
        [SerializeField] private ClawMapSpawnManager spawnManager;

        private void Start()
        {
            if (FindObjectOfType<ClawLocalPlayerRig>() != null) return;
            if (spawnManager == null) spawnManager = FindObjectOfType<ClawMapSpawnManager>();
            ClawLocalPlayerRig player = ClawLocalPlayerRig.Create();
            if (spawnManager != null) spawnManager.PlaceAtStart(player);
            else Debug.LogError("CLAW: Spawn manager is missing from this map scene.");
        }
    }
}
