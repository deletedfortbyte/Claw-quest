using System.Linq;
using UnityEngine;

namespace CLAW
{
    [DisallowMultipleComponent]
    public sealed class ClawMapSpawnManager : MonoBehaviour
    {
        [SerializeField] private ClawSpawnPoint[] spawnPoints;
        private ClawSpawnPoint primarySpawn;
        private ClawSpawnPoint activeCheckpoint;

        public ClawSpawnPoint ActiveCheckpoint => activeCheckpoint;

        private void Awake()
        {
            if (spawnPoints == null || spawnPoints.Length == 0)
                spawnPoints = FindObjectsOfType<ClawSpawnPoint>(true);

            primarySpawn = spawnPoints.FirstOrDefault(p => p != null && p.Kind == ClawSpawnPointKind.Start && p.IsPrimary)
                ?? spawnPoints.FirstOrDefault(p => p != null && p.Kind == ClawSpawnPointKind.Start);
            activeCheckpoint = primarySpawn;
        }

        public void PlaceAtStart(ClawLocalPlayerRig player)
        {
            if (player == null) return;
            if (primarySpawn == null)
            {
                Debug.LogError("CLAW: This scene has no Start spawn point.");
                return;
            }
            player.TeleportTo(primarySpawn.transform);
        }

        public void ActivateCheckpoint(ClawSpawnPoint point)
        {
            if (point == null || point.Kind != ClawSpawnPointKind.Checkpoint) return;
            activeCheckpoint = point;
            ClawFacilityRunManager run = FindObjectOfType<ClawFacilityRunManager>();
            if (run != null) run.SetStatus("Checkpoint reached: " + point.DisplayName);
        }

        public void Respawn(ClawLocalPlayerRig player)
        {
            if (player == null) return;
            ClawSpawnPoint destination = activeCheckpoint != null ? activeCheckpoint : primarySpawn;
            if (destination == null) return;
            player.TeleportTo(destination.transform);
            ClawFacilityRunManager run = FindObjectOfType<ClawFacilityRunManager>();
            if (run != null) run.SetStatus("Respawned at " + destination.DisplayName);
        }
    }
}
