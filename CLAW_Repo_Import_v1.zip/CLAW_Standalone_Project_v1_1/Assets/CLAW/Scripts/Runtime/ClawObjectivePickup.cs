using UnityEngine;

namespace CLAW
{
    [RequireComponent(typeof(SphereCollider))]
    public sealed class ClawObjectivePickup : MonoBehaviour
    {
        [SerializeField] private float rotationSpeed = 65f;
        [SerializeField] private float bobHeight = 0.15f;
        [SerializeField] private float bobSpeed = 1.7f;
        private Vector3 startPosition;
        private bool collected;

        private void Awake()
        {
            SphereCollider trigger = GetComponent<SphereCollider>();
            trigger.isTrigger = true; trigger.radius = 0.72f;
            startPosition = transform.position;
        }
        private void Update()
        {
            if (collected) return;
            transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime, Space.World);
            Vector3 p = startPosition; p.y += Mathf.Sin(Time.time * bobSpeed) * bobHeight;
            transform.position = p;
        }
        private void OnTriggerEnter(Collider other)
        {
            if (collected || other.GetComponentInParent<ClawLocalPlayerRig>() == null) return;
            ClawFacilityRunManager manager = FindObjectOfType<ClawFacilityRunManager>();
            if (manager == null) return;
            collected = true;
            manager.CollectObjective();
            gameObject.SetActive(false);
        }
    }
}
