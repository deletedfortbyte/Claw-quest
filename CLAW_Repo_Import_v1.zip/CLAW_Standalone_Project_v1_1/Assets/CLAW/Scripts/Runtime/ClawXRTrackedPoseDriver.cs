using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

namespace CLAW
{
    /// <summary>Reads local HMD and controller/hand poses from Unity XR input devices.</summary>
    public sealed class ClawXRTrackedPoseDriver : MonoBehaviour
    {
        [SerializeField] private Transform head;
        [SerializeField] private Transform leftHand;
        [SerializeField] private Transform rightHand;
        [SerializeField] private Renderer leftHandRenderer;
        [SerializeField] private Renderer rightHandRenderer;

        private InputDevice headDevice, leftDevice, rightDevice;
        private Vector3 trackingOriginOffset;
        private bool originConfigured;
        public bool LeftTracked { get; private set; }
        public bool RightTracked { get; private set; }
        public bool HeadTracked { get; private set; }

        public void Configure(Transform headTarget, Transform leftTarget, Transform rightTarget,
            Renderer leftRenderer, Renderer rightRenderer)
        {
            head = headTarget; leftHand = leftTarget; rightHand = rightTarget;
            leftHandRenderer = leftRenderer; rightHandRenderer = rightRenderer;
        }

        private void Start()
        {
            ConfigureFloorTrackingOrigin();
        }

        private void ConfigureFloorTrackingOrigin()
        {
            List<XRInputSubsystem> subsystems = new List<XRInputSubsystem>();
            SubsystemManager.GetInstances(subsystems);
            bool floorMode = false;
            foreach (XRInputSubsystem subsystem in subsystems)
            {
                if (subsystem == null || !subsystem.running) continue;
                TrackingOriginModeFlags supported = subsystem.GetSupportedTrackingOriginModes();
                if ((supported & TrackingOriginModeFlags.Floor) != 0)
                {
                    subsystem.TrySetTrackingOriginMode(TrackingOriginModeFlags.Floor);
                    floorMode = subsystem.GetTrackingOriginMode() == TrackingOriginModeFlags.Floor;
                    if (floorMode) break;
                }
            }
            // Device-origin runtimes report the headset as (0,0,0); lift the rig-space
            // poses by a standing-height offset so the body capsule remains floor-based.
            trackingOriginOffset = floorMode ? Vector3.zero : Vector3.up * 1.62f;
            originConfigured = true;
        }

        private void Update()
        {
            if (!originConfigured) ConfigureFloorTrackingOrigin();
            RefreshDevice(ref headDevice, XRNode.Head);
            RefreshDevice(ref leftDevice, XRNode.LeftHand);
            RefreshDevice(ref rightDevice, XRNode.RightHand);

            HeadTracked = UpdatePose(headDevice, head, new Vector3(0f, 1.62f, 0f), trackingOriginOffset);
            LeftTracked = UpdatePose(leftDevice, leftHand, new Vector3(-0.28f, 1.18f, 0.34f), trackingOriginOffset);
            RightTracked = UpdatePose(rightDevice, rightHand, new Vector3(0.28f, 1.18f, 0.34f), trackingOriginOffset);

            if (leftHandRenderer != null) leftHandRenderer.enabled = LeftTracked;
            if (rightHandRenderer != null) rightHandRenderer.enabled = RightTracked;
        }

        private static void RefreshDevice(ref InputDevice device, XRNode node)
        {
            if (!device.isValid) device = InputDevices.GetDeviceAtXRNode(node);
        }

        private static bool UpdatePose(InputDevice device, Transform target, Vector3 fallbackPosition, Vector3 originOffset)
        {
            if (target == null) return false;
            if (device.isValid && device.TryGetFeatureValue(CommonUsages.devicePosition, out Vector3 position))
            {
                target.localPosition = position + originOffset;
                if (device.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion rotation))
                    target.localRotation = rotation;
                return true;
            }
            target.localPosition = fallbackPosition;
            return false;
        }

        public void ResetTrackingDevices()
        {
            headDevice = default; leftDevice = default; rightDevice = default;
        }
    }
}
