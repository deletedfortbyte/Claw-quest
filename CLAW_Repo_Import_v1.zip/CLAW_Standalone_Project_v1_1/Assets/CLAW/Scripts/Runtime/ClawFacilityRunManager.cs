using UnityEngine;

namespace CLAW
{
    /// <summary>Small local training objective loop: collect all cells, then reach the exit.</summary>
    public sealed class ClawFacilityRunManager : MonoBehaviour
    {
        [SerializeField] private string mapTitle = "CLAW Facility";
        [SerializeField] private int requiredObjectives = 3;
        private int collected;
        private string status = "Find the power cells and return to the marked exit.";
        private bool completed;

        public int Collected => collected;
        public int Required => requiredObjectives;
        public bool IsComplete => collected >= requiredObjectives;
        public bool Completed => completed;

        public void Configure(string title, int objectiveCount)
        {
            mapTitle = title; requiredObjectives = Mathf.Max(1, objectiveCount);
        }
        public void CollectObjective()
        {
            if (completed) return;
            collected = Mathf.Min(requiredObjectives, collected + 1);
            status = IsComplete ? "All power cells secured. Return to the exit." : "Power cell secured.";
        }
        public void SetStatus(string message) { status = message ?? string.Empty; }
        public void CompleteRun()
        {
            if (!IsComplete) { status = "The exit is locked. Find all power cells first."; return; }
            completed = true; status = "FACILITY CLEARED — TRAINING RUN COMPLETE";
        }
        private void OnGUI()
        {
            const int margin = 20;
            GUI.Box(new Rect(margin, margin, 520, 136), GUIContent.none);
            GUIStyle style = new GUIStyle(GUI.skin.label) { fontSize = 22, wordWrap = true };
            GUI.Label(new Rect(margin + 16, margin + 10, 490, 30), "CLAW  /  " + mapTitle, style);
            GUI.Label(new Rect(margin + 16, margin + 46, 490, 30), "POWER CELLS   " + collected + " / " + requiredObjectives, style);
            GUI.Label(new Rect(margin + 16, margin + 82, 490, 48), status, style);
        }
    }
}
