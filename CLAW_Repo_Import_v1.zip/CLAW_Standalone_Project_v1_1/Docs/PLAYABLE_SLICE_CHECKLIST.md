# CLAW Playable Slice Acceptance Checklist

## Scene generation
- [ ] Unity imports OBJ and MTL files without errors.
- [ ] `CLAW → Maps → Build All Playable Map Scenes` completes.
- [ ] All three scene assets are added to Build Settings.
- [ ] Each map has a primary start, two checkpoints, three objectives, an exit, static collision and a fall-recovery trigger.

## Quest 3S runtime
- [ ] OpenXR loader initializes on Quest 3S.
- [ ] HMD, left hand and right hand poses are aligned.
- [ ] Hand pushes move the body opposite contact travel.
- [ ] Capsule collides with floors, walls and map structures.
- [ ] Checkpoint trigger changes the respawn position.
- [ ] Fall-recovery volume respawns without retaining momentum.
- [ ] Three cells can be collected; the extraction gate succeeds only after all three.
- [ ] No excessive jitter, tunneling, hand drift, clipping or uncomfortable acceleration.
- [ ] Measure stable Quest 3S frame rate; 72 FPS is a target, not a verified result.

## Online / release readiness (not in this slice)
- [ ] Photon Fusion rooms, PlayFab auth, and player replication.
- [ ] Photon Voice with opt-in mic, push-to-talk, mute and report controls.
- [ ] Original final player mesh/rig and animation.
- [ ] Monster AI, complete modes, polished UI, audio, save system, QA and release build.
