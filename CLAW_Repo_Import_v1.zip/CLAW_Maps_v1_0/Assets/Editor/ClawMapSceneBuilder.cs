#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>
/// Builds lightweight Unity blockout scenes from the CLAW OBJ map assets.
/// Imported OBJ objects prefixed COLL_ receive static MeshColliders.
/// Objects prefixed VIS_ remain visual-only to avoid decorative snag points.
/// </summary>
public static class ClawMapSceneBuilder
{
    private const string MapFolder = "Assets/CLAW/Maps/";
    private const string SceneFolder = "Assets/CLAW/Scenes/";

    private sealed class MapDefinition
    {
        public string Name;
        public Vector3 SpawnPosition;
        public Vector3 SpawnEuler;
    }

    private static readonly MapDefinition[] Maps =
    {
        new MapDefinition
        {
            Name = "Warehouse_Lobby",
            SpawnPosition = new Vector3(0f, 1.1f, -13f),
            SpawnEuler = Vector3.zero,
        },
        new MapDefinition
        {
            Name = "Cold_Storage",
            SpawnPosition = new Vector3(0f, 1.1f, -14f),
            SpawnEuler = Vector3.zero,
        },
        new MapDefinition
        {
            Name = "Maintenance_Tunnels",
            SpawnPosition = new Vector3(0f, 1.1f, -27f),
            SpawnEuler = new Vector3(0f, 90f, 0f),
        }
    };

    [MenuItem("CLAW/Maps/Build All Map Scenes")]
    public static void BuildAllMapScenes()
    {
        EnsureFolder("Assets/CLAW", "Scenes");
        var scenePaths = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);

        foreach (MapDefinition map in Maps)
        {
            string scenePath = BuildMapScene(map);
            if (!string.IsNullOrEmpty(scenePath))
            {
                bool alreadyListed = false;
                foreach (EditorBuildSettingsScene existing in scenePaths)
                {
                    if (existing.path == scenePath) { alreadyListed = true; break; }
                }
                if (!alreadyListed)
                    scenePaths.Add(new EditorBuildSettingsScene(scenePath, true));
            }
        }

        EditorBuildSettings.scenes = scenePaths.ToArray();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("CLAW: Generated " + scenePaths.Count + " map scenes. These are blockout scenes; add the XR player rig and gameplay systems next.");
    }

    [MenuItem("CLAW/Maps/Build Warehouse Lobby")]
    private static void BuildWarehouse() { BuildSingle(Maps[0]); }

    [MenuItem("CLAW/Maps/Build Cold Storage")]
    private static void BuildColdStorage() { BuildSingle(Maps[1]); }

    [MenuItem("CLAW/Maps/Build Maintenance Tunnels")]
    private static void BuildMaintenance() { BuildSingle(Maps[2]); }

    private static void BuildSingle(MapDefinition map)
    {
        EnsureFolder("Assets/CLAW", "Scenes");
        string path = BuildMapScene(map);
        if (!string.IsNullOrEmpty(path))
        {
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("CLAW: Generated scene at " + path);
        }
    }

    private static string BuildMapScene(MapDefinition map)
    {
        string modelPath = MapFolder + map.Name + ".obj";
        GameObject modelAsset = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
        if (modelAsset == null)
        {
            Debug.LogError("CLAW: Could not find imported map model: " + modelPath + ". Make sure the OBJ and MTL files are inside Assets/CLAW/Maps.");
            return null;
        }

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject mapRoot = new GameObject("CLAW_MAP_" + map.Name);
        GameObject modelInstance = PrefabUtility.InstantiatePrefab(modelAsset) as GameObject;
        if (modelInstance == null)
        {
            Debug.LogError("CLAW: Failed to instantiate " + modelPath);
            return null;
        }
        modelInstance.name = map.Name + "_Geometry";
        modelInstance.transform.SetParent(mapRoot.transform, false);

        string collisionPath = MapFolder + map.Name + "_Collision.obj";
        GameObject collisionAsset = AssetDatabase.LoadAssetAtPath<GameObject>(collisionPath);
        if (collisionAsset == null)
        {
            Debug.LogError("CLAW: Missing collision OBJ: " + collisionPath);
            return null;
        }
        GameObject collisionInstance = PrefabUtility.InstantiatePrefab(collisionAsset) as GameObject;
        if (collisionInstance == null)
        {
            Debug.LogError("CLAW: Failed to instantiate collision mesh " + collisionPath);
            return null;
        }
        collisionInstance.name = map.Name + "_Collision_Source";
        collisionInstance.transform.SetParent(mapRoot.transform, false);
        ConfigureImportedCollision(collisionInstance, mapRoot.transform);

        CreateMarker(mapRoot.transform, "PlayerSpawn", map.SpawnPosition, map.SpawnEuler);
        CreateMarker(mapRoot.transform, "MapOrigin", Vector3.zero, Vector3.zero);

        CreateLighting(mapRoot.transform, map.Name);

        string outputPath = SceneFolder + map.Name + ".unity";
        EditorSceneManager.SaveScene(scene, outputPath);
        return outputPath;
    }

    private static void ConfigureImportedCollision(GameObject collisionSource, Transform mapRoot)
    {
        var combine = new List<CombineInstance>();
        foreach (MeshFilter filter in collisionSource.GetComponentsInChildren<MeshFilter>(true))
        {
            if (filter.sharedMesh == null) continue;
            combine.Add(new CombineInstance
            {
                mesh = filter.sharedMesh,
                transform = filter.transform.localToWorldMatrix
            });
        }

        if (combine.Count == 0)
        {
            Debug.LogError("CLAW: Collision OBJ imported without a readable mesh.");
            return;
        }

        Mesh combinedMesh = new Mesh();
        combinedMesh.name = "CLAW_Combined_Environment_Collision";
        combinedMesh.indexFormat = combine.Count * 24 > 65000
            ? IndexFormat.UInt32
            : IndexFormat.UInt16;
        combinedMesh.CombineMeshes(combine.ToArray(), true, true, false);
        combinedMesh.RecalculateBounds();

        GameObject colliderObject = new GameObject("CLAW_Environment_Collider");
        colliderObject.transform.SetParent(mapRoot, false);
        MeshCollider environmentCollider = colliderObject.AddComponent<MeshCollider>();
        environmentCollider.sharedMesh = combinedMesh;
        colliderObject.isStatic = true;

        // The collision source is hidden after its geometry has been combined;
        // the visible map OBJ remains the rendered map.
        collisionSource.SetActive(false);
    }

    private static void CreateMarker(Transform parent, string markerName, Vector3 position, Vector3 euler)
    {
        GameObject marker = new GameObject(markerName);
        marker.transform.SetParent(parent, false);
        marker.transform.localPosition = position;
        marker.transform.localEulerAngles = euler;
    }

    private static void CreateLighting(Transform parent, string mapName)
    {
        GameObject lightObject = new GameObject("CLAW_Directional_Light");
        lightObject.transform.SetParent(parent, false);
        lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        Light sun = lightObject.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.05f;
        sun.color = mapName == "Cold_Storage"
            ? new Color(0.76f, 0.88f, 1f)
            : new Color(1f, 0.88f, 0.72f);
        sun.shadows = LightShadows.None;

        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = mapName == "Cold_Storage"
            ? new Color(0.34f, 0.43f, 0.52f)
            : new Color(0.34f, 0.32f, 0.30f);
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogDensity = mapName == "Maintenance_Tunnels" ? 0.008f : 0.004f;
        RenderSettings.fogColor = mapName == "Cold_Storage"
            ? new Color(0.20f, 0.30f, 0.37f)
            : new Color(0.12f, 0.14f, 0.17f);
    }

    private static void EnsureFolder(string parent, string child)
    {
        string path = parent + "/" + child;
        if (!AssetDatabase.IsValidFolder(path))
            AssetDatabase.CreateFolder(parent, child);
    }
}
#endif
