# Geometry Report — CLAW Map Pack v1.0

All dimensions use Unity-style units (intended metres). OBJ face references were generated in sequence and rechecked with a mesh loader. The visible OBJ identifies collision-intended geometry (`COLL_`) separately from decorative visual-only geometry (`VIS_`). A dedicated `_Collision.obj` for each map consolidates collision-intended geometry for one static Unity MeshCollider.

- Warehouse Lobby: 221 OBJ objects, 2,408 vertices, 3,932 triangles.
- Cold Storage: 219 OBJ objects, 2,252 vertices, 3,628 triangles.
- Maintenance Tunnels: 128 OBJ objects, 1,672 vertices, 2,832 triangles.

These counts are for environment blockout meshes only. They do not include a player, monster, UI, or runtime systems. Low triangle counts do not guarantee Quest performance; collider count, draw calls, material count, lighting, and runtime scripts also matter.
