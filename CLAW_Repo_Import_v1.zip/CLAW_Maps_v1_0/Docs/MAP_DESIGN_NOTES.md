# CLAW Map Design Notes — v1.0

## Traversal goals

The blockouts prioritize a readable central route with optional elevated routes, alternate side paths, climbable pipes, and enough space to swing/push the tracked hands. The initial map test should focus on whether a player can cross the environment without hand snagging or getting trapped between props.

## Warehouse Lobby route

- Courtyard spawn is the safe social staging zone.
- The room-code and color station placeholders sit on opposite sides of the spawn route.
- A broad loading opening leads into the warehouse.
- The central packing island is the primary landmark.
- Rack rows and crates create side routes while retaining a broad central aisle.
- The rear catwalk and suspended pipework provide elevated traversal options.

## Cold Storage route

- The entrance-side conveyor is a clear landmark.
- Three rack lines create parallel routes with cross-aisles.
- Coolant pipes provide overhead climbing opportunities.
- A rear freezer door and control panel form a future objective location.
- The rear raised walkway offers an alternate elevated route.

## Maintenance Tunnels route

- The central pump room provides a strong orientation landmark.
- Four connected branches create route choice without dead-end-only progression.
- Wall rungs, pipe lines, and cross-pipes give the arm-push movement system vertical and overhead surfaces.
- Service crates and drain grates add small navigation beats without filling the corridors.

## Required in-headset validation

- Test floor, wall, pipe, shelf, railing, and catwalk contact.
- Check the scale from a Quest 3S player's eye height.
- Confirm the main route is always readable.
- Check hand radii against shelf gaps and rail spacing.
- Remove or reshape any geometry that repeatedly catches the hands.
- Profile frame rate only after scenes, player rig, and target graphics settings are imported into the real Unity project.
