from pathlib import Path
import numpy as np, trimesh, vtk
from vtk.util import numpy_support
from PIL import Image, ImageDraw, ImageFont
ROOT=Path('/mnt/data/CLAW_Maps_v1_0')
MAP=ROOT/'Assets/CLAW/Maps'
PRE=ROOT/'Preview'; PRE.mkdir(exist_ok=True)

def parse_mtl(p):
    d={}; cur=None
    for line in p.read_text().splitlines():
        s=line.strip()
        if s.startswith('newmtl '):cur=s.split(None,1)[1]; d[cur]=(0.5,0.5,0.5)
        elif s.startswith('Kd ') and cur:d[cur]=tuple(float(x) for x in s.split()[1:4])
    return d

def mesh_polydata(mesh, matrix=None):
    verts=np.asarray(mesh.vertices,dtype=np.float64)
    if matrix is not None: verts=trimesh.transform_points(verts,matrix)
    faces=np.asarray(mesh.faces,dtype=np.int64)
    pts=vtk.vtkPoints(); pts.SetData(numpy_support.numpy_to_vtk(verts,deep=True))
    polys=vtk.vtkCellArray(); arr=np.hstack([np.full((len(faces),1),3,dtype=np.int64),faces]).ravel()
    polys.SetCells(len(faces),numpy_support.numpy_to_vtkIdTypeArray(arr,deep=True))
    poly=vtk.vtkPolyData(); poly.SetPoints(pts); poly.SetPolys(polys)
    norm=vtk.vtkPolyDataNormals(); norm.SetInputData(poly); norm.ConsistencyOn(); norm.AutoOrientNormalsOn(); norm.SplittingOff(); norm.Update()
    return norm.GetOutput()

def render(name,mode='iso'):
    scene=trimesh.load(str(MAP/f'{name}.obj'),force='scene',process=False)
    mats=parse_mtl(MAP/f'{name}.mtl')
    ren=vtk.vtkRenderer(); ren.SetBackground(0.035,0.045,0.065); ren.SetBackground2(0.11,0.14,0.19); ren.GradientBackgroundOn()
    for node in scene.graph.nodes_geometry:
        matrix,gn=scene.graph[node]; mesh=scene.geometry[gn]
        poly=mesh_polydata(mesh,matrix)
        mapper=vtk.vtkPolyDataMapper(); mapper.SetInputData(poly)
        actor=vtk.vtkActor(); actor.SetMapper(mapper)
        material=getattr(getattr(mesh,'visual',None),'material',None)
        matname=getattr(material,'name',gn)
        rgb=mats.get(matname,(0.48,0.52,0.56))
        prop=actor.GetProperty(); prop.SetColor(*rgb); prop.SetAmbient(0.42); prop.SetDiffuse(0.68); prop.SetSpecular(0.18); prop.SetSpecularPower(24)
        ren.AddActor(actor)
    b=ren.ComputeVisiblePropBounds(); center=np.array([(b[0]+b[1])/2,(b[2]+b[3])/2,(b[4]+b[5])/2]); ext=np.array([b[1]-b[0],b[3]-b[2],b[5]-b[4]]); span=float(max(ext))
    cam=ren.GetActiveCamera(); cam.SetFocalPoint(*center)
    if mode=='top':
        cam.SetPosition(*(center+np.array([0,span*2.8,0.001]))); cam.SetViewUp(0,0,-1); cam.ParallelProjectionOn(); cam.SetParallelScale(max(ext[0],ext[2])*0.55)
    else:
        # elevated three-quarter, high enough to see route and vertical objects
        offset=np.array([1.35,1.05,1.5]); offset/=np.linalg.norm(offset)
        cam.SetPosition(*(center+offset*span*2.35)); cam.SetViewUp(0,1,0); cam.ParallelProjectionOn(); cam.SetParallelScale(span*0.54)
    ren.ResetCameraClippingRange()
    light=vtk.vtkLight(); light.SetLightTypeToSceneLight(); light.SetPosition(*(center+np.array([span,span*1.8,span]))); light.SetFocalPoint(*center); light.SetIntensity(0.95); ren.AddLight(light)
    win=vtk.vtkRenderWindow(); win.SetOffScreenRendering(1); win.SetSize(1600,1150); win.AddRenderer(ren); win.SetMultiSamples(8); win.Render()
    cap=vtk.vtkWindowToImageFilter(); cap.SetInput(win); cap.SetInputBufferTypeToRGBA(); cap.ReadFrontBufferOff(); cap.Update()
    out=PRE/f'{name}_{"Top_Down" if mode=="top" else "3D_View"}.png'
    writer=vtk.vtkPNGWriter(); writer.SetFileName(str(out)); writer.SetInputConnection(cap.GetOutputPort()); writer.Write(); win.Finalize()
    return out, sum(len(m.faces) for m in scene.geometry.values())

files=[]
for n in ['Warehouse_Lobby','Cold_Storage','Maintenance_Tunnels']:
    a,fa=render(n,'iso'); b,fb=render(n,'top'); files += [a,b]
    print(n,fa,a,b)
# Make a labelled contact sheet of the three perspective views.
thumbs=[]
for n in ['Warehouse_Lobby','Cold_Storage','Maintenance_Tunnels']:
    im=Image.open(PRE/f'{n}_3D_View.png').convert('RGB')
    im.thumbnail((850,610))
    thumbs.append(im)
canvas=Image.new('RGB',(1800,1990),(18,23,33)); draw=ImageDraw.Draw(canvas)
try: title=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',54); sub=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',28)
except: title=sub=None
draw.text((65,35),'CLAW — MAP BLOCKOUTS v1.0',font=title,fill=(235,240,248))
draw.text((68,108),'Three original environments • low-poly geometry • Unity-importable OBJ/MTL',font=sub,fill=(160,182,202))
labels=['01  WAREHOUSE LOBBY','02  COLD STORAGE','03  MAINTENANCE TUNNELS']
for i,(im,label) in enumerate(zip(thumbs,labels)):
    x=70+(i%2)*880; y=180+(i//2)*850
    draw.text((x,y),label,font=sub,fill=(238,181,89))
    canvas.paste(im,(x,y+48))
canvas.save(ROOT/'CLAW_Maps_v1_0_Overview.png')
