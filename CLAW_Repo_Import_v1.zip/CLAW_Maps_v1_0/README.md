# CLAW Map Pack v1.0

Three original, low-poly 3D environment blockouts for the CLAW VR project. The assets are designed around hand-powered VR traversal and are supplied as Unity-importable Wavefront OBJ + MTL files.

## Included maps

### 1. Warehouse Lobby
Outdoor courtyard and social start area leading into an abandoned industrial warehouse. Includes a spawn pad, room-code and color-station placeholders, loading entrance, storage racks, crates, packing island, support columns, rear catwalk, overhead climb pipes, and industrial service lines.

### 2. Cold Storage
Insulated warehouse with three shelf rows, wide aisles, conveyor/packing line, rear freezer door/control panel, overhead coolant pipes, raised rear walkway, and cargo blocks.

### 3. Maintenance Tunnels
Central pump chamber with four connected branches (north, south, east and west), pump tanks, control island, overhead pipes, wall rungs, grates, service crates, and utility fixtures.

## Files

- `Assets/CLAW/Maps/*.obj` — map geometry.
- `Assets/CLAW/Maps/*.mtl` — material definitions referenced by each OBJ.
- `Assets/CLAW/Maps/*_Collision.obj` and `.mtl` — collision-only copies used by the scene builder.
- `Assets/Editor/ClawMapSceneBuilder.cs` — Unity Editor helper to generate one scene per map and combine each map’s collision-only OBJ into one static MeshCollider.
- `Preview/` — perspective and top-down previews.
- `build_claw_maps.py` — procedural source used to create the OBJ geometry.
- `render_previews.py` — preview rendering source.

## Unity import

1. Extract the pack into the root of a Unity project, preserving the `Assets/` folder structure.
2. In Unity, wait for the OBJ and MTL models to import.
3. Confirm the three OBJ files appear under `Assets/CLAW/Maps/` and that Unity has assigned their MTL materials.
4. Use the Unity menu **CLAW → Maps → Build All Map Scenes**.
5. The builder creates `Assets/CLAW/Scenes/Warehouse_Lobby.unity`, `Cold_Storage.unity`, and `Maintenance_Tunnels.unity`, combines the collision-only geometry into one static MeshCollider per map, creates a `PlayerSpawn` marker, adds simple ambient/directional lighting, and adds the scenes to Build Settings without removing existing scenes.

The visible OBJ separates collision-intended geometry (`COLL_`) from visual-only details (`VIS_`). A separate `*_Collision.obj` contains only collision-intended geometry. The builder uses that dedicated mesh instead of placing a separate collider on every prop.

## Important status / limitations

These are expanded geometry blockouts, not complete shipped levels. They do not yet contain the CLAW XR player rig, arm-push movement, working station UI, monsters, objectives, networking, final textures, baked lighting, or audio. The Unity scene-builder script has not been run in the Unity Editor and has not been compiled against a project. The maps have only been checked as OBJ/MTL geometry and rendered for preview. Collision, traversal, comfort, Quest 3S performance, and visual polish still require Unity/Quest testing.

No Unity APK is included. No third-party game model, map, or protected asset is included in this pack.

## Optional 3D previews
The `Preview/*.glb` files are convenient copies of the visible map geometry for inspection in a compatible glTF/GLB viewer. The OBJ files remain the import source used by the included Unity scene builder.

Each map also has a dedicated `*_Collision.obj` file. The scene builder combines it into one static MeshCollider per map, while the regular OBJ supplies the visible geometry. This is an initial collision approximation and must still be play-tested.
