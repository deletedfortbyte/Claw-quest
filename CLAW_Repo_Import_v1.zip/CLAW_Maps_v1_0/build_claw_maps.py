from pathlib import Path
import math, zipfile, json
import numpy as np

ROOT = Path('/mnt/data/CLAW_Maps_v1_0')
MAPDIR = ROOT/'Assets/CLAW/Maps'

MATERIALS = {
    'Concrete': (0.34,0.37,0.40),
    'ConcreteLight': (0.49,0.51,0.52),
    'ConcreteDark': (0.19,0.22,0.25),
    'Steel': (0.43,0.49,0.54),
    'SteelDark': (0.22,0.28,0.33),
    'Rust': (0.48,0.22,0.10),
    'Hazard': (0.94,0.58,0.10),
    'Purple': (0.39,0.18,0.67),
    'Teal': (0.08,0.53,0.56),
    'Amber': (0.96,0.67,0.20),
    'Rubber': (0.07,0.08,0.09),
    'Ice': (0.55,0.78,0.88),
    'IceDark': (0.19,0.40,0.51),
    'Frost': (0.77,0.87,0.90),
    'PipeBlue': (0.16,0.45,0.66),
    'WarningRed': (0.65,0.12,0.12),
    'Wood': (0.37,0.25,0.13),
    'PaleWood': (0.58,0.43,0.23),
    'PumpGreen': (0.19,0.42,0.34),
}

class ObjBuilder:
    def __init__(self, name):
        self.name=name
        self.lines=[f'# CLAW {name} 3D blockout v1.0', f'mtllib {name}.mtl']
        self.coll_lines=[f'# CLAW {name} collision mesh v1.0', f'mtllib {name}_Collision.mtl', 'o COLL_Environment']
        self.vcount=0; self.objects=0; self.coll_vcount=0
    def mesh(self, name, verts, faces, mat, collidable=True):
        prefix='COLL_' if collidable else 'VIS_'
        self.lines.append(f'o {prefix}{name}')
        self.lines.append(f'usemtl {mat}')
        for v in verts:
            self.lines.append('v %.4f %.4f %.4f'%tuple(v))
        for f in faces:
            self.lines.append('f '+' '.join(str(self.vcount+i+1) for i in f))
        self.vcount += len(verts); self.objects += 1
        if collidable:
            self.coll_lines.append('usemtl Concrete')
            for v in verts:
                self.coll_lines.append('v %.4f %.4f %.4f'%tuple(v))
            for f in faces:
                self.coll_lines.append('f '+' '.join(str(self.coll_vcount+i+1) for i in f))
            self.coll_vcount += len(verts)
    def box(self, name, x,y,z, sx,sy,sz, mat='Steel', collidable=True):
        x0,x1=x-sx/2,x+sx/2; y0,y1=y-sy/2,y+sy/2; z0,z1=z-sz/2,z+sz/2
        v=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
           (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
        f=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
        self.mesh(name,v,f,mat,collidable)
    def cylinder(self,name,a,b,radius,mat='Steel',segments=10,collidable=True):
        a=np.array(a,dtype=float); b=np.array(b,dtype=float)
        d=b-a; L=np.linalg.norm(d)
        if L<1e-6:return
        w=d/L; helper=np.array([0.,1.,0.]) if abs(w[1])<0.9 else np.array([1.,0.,0.])
        u=np.cross(w,helper); u/=np.linalg.norm(u); v=np.cross(w,u); v/=np.linalg.norm(v)
        verts=[]
        for p in (a,b):
            for i in range(segments):
                ang=2*math.pi*i/segments
                pt=p+radius*(math.cos(ang)*u+math.sin(ang)*v)
                verts.append(tuple(pt))
        faces=[]
        for i in range(segments):
            j=(i+1)%segments
            faces.append((i,j,segments+j,segments+i))
        faces.append(tuple(reversed(range(segments))))
        faces.append(tuple(range(segments,2*segments)))
        self.mesh(name,verts,faces,mat,collidable)
    def stairs(self,name,x,z,width,count,step_depth,rise,mat='ConcreteLight'):
        for i in range(count):
            self.box(f'{name}_step_{i+1}',x,rise*(i+0.5),z+i*step_depth,width,rise*(i+1),step_depth,mat,True)
    def save(self):
        (MAPDIR/f'{self.name}.obj').write_text('\n'.join(self.lines)+'\n')
        (MAPDIR/f'{self.name}_Collision.obj').write_text('\n'.join(self.coll_lines)+'\n')
        m=['# CLAW material library']
        for n,c in MATERIALS.items():
            m += [f'newmtl {n}',f'Ka {c[0]*0.22:.3f} {c[1]*0.22:.3f} {c[2]*0.22:.3f}',f'Kd {c[0]:.3f} {c[1]:.3f} {c[2]:.3f}','Ks 0.12 0.12 0.12','Ns 28','d 1.0','illum 2','']
        (MAPDIR/f'{self.name}.mtl').write_text('\n'.join(m))
        collision_mtl=['# Collision mesh material','newmtl Concrete','Ka 0.075 0.081 0.088','Kd 0.34 0.37 0.40','Ks 0.0 0.0 0.0','Ns 1','d 1.0','illum 1','']
        (MAPDIR/f'{self.name}_Collision.mtl').write_text('\n'.join(collision_mtl))
        return self.objects, self.vcount

def warehouse():
    o=ObjBuilder('Warehouse_Lobby')
    # exterior courtyard apron and inner slab
    o.box('Courtyard_concrete',0,-0.22,-14,30,0.44,18,'Concrete')
    o.box('Warehouse_main_floor',0,-0.25,13,36,0.5,28,'Concrete')
    o.box('Loading_dock_threshold',0,0.05,-0.3,11,0.25,1.0,'Hazard')
    # warehouse walls with central loading doorway
    for x in (-18,18): o.box(f'Warehouse_side_wall_{x}',x,4.3,13,0.6,8.6,28,'ConcreteDark')
    o.box('Warehouse_back_wall',0,4.3,27.2,36,8.6,0.6,'ConcreteDark')
    o.box('Warehouse_front_wall_left',-13,4.3,-1,10,8.6,0.6,'ConcreteDark')
    o.box('Warehouse_front_wall_right',13,4.3,-1,10,8.6,0.6,'ConcreteDark')
    o.box('Loading_door_header',0,7.6,-1,16,1.8,0.7,'SteelDark')
    # beams & roof trusses
    for z in (2,9,16,23):
        o.cylinder(f'Roof_truss_crossbeam_{z}',(-17,8,z),(17,8,z),0.18,'SteelDark',8)
        for x in (-15,0,15):
            o.cylinder(f'Roof_brace_{z}_{x}',(x,6.7,z),(x+1.5,8,z),0.09,'Steel',8)
    # industrial columns
    for x in (-15,15):
        for z in (4,13,22):
            o.box(f'Support_column_{x}_{z}',x,3.9,z,0.9,7.8,0.9,'ConcreteLight')
            o.box(f'Column_base_{x}_{z}',x,0.35,z,1.3,0.7,1.3,'SteelDark')
    # main packing island
    o.box('Packing_island_base',0,0.7,12,9,1.4,4,'SteelDark')
    o.box('Packing_surface',0,1.5,12,9.4,0.25,4.4,'Steel')
    for x in (-3.5,0,3.5):
        o.box(f'Packing_bay_{x}',x,2.1,12,1.4,0.9,1.4,'Wood')
        o.box(f'Packing_bay_top_{x}',x,2.65,12,1.6,0.15,1.6,'PaleWood')
    # storage racks left and right with shelves and pallets
    for side in (-1,1):
        x=side*11
        for z in (4,10,16,22):
            for y in (1.25,2.7,4.15):
                o.box(f'Rack_{side}_{z}_{y}_shelf',x,y,z,5.2,0.18,1.0,'SteelDark')
            for dx in (-2.45,2.45):
                o.box(f'Rack_{side}_{z}_post_{dx}',x+dx,2.8,z,0.18,5.6,0.18,'Hazard')
            for y in (1.85,3.3):
                o.box(f'Rack_{side}_{z}_cargo_{y}',x,y,z,3.4,0.9,0.8,'Wood')
                o.box(f'Rack_{side}_{z}_cargo_strap_{y}',x,y,z-0.42,3.45,0.08,0.04,'Hazard',False)
    # crates and loose obstacles leave main aisle open
    for i,(x,z,s) in enumerate([(-6,5,1.5),(6,7,1.3),(-6,18,1.6),(7,20,1.4),(-2,23,1.0),(3,4,1.0)]):
        o.box(f'Crate_{i+1}',x,s/2,z,s,s,s,'Wood')
        o.box(f'Crate_{i+1}_top_band',x,s+0.02,z,s+0.04,0.08,s+0.04,'Hazard',False)
    # rear and side catwalks
    o.box('Rear_catwalk_deck',0,4.5,23.3,24,0.5,3,'SteelDark')
    o.box('Rear_catwalk_walkway',0,4.78,23.3,24,0.08,2.8,'Steel')
    for x in np.arange(-12,13,2):
        o.cylinder(f'Rear_catwalk_rail_post_{x}',(x,4.9,21.9),(x,6.0,21.9),0.055,'Hazard',8)
        o.cylinder(f'Rear_catwalk_rail_post_back_{x}',(x,4.9,24.7),(x,6.0,24.7),0.055,'Hazard',8)
    for z in (21.9,24.7):
        o.cylinder(f'Rear_catwalk_rail_{z}',(-12,5.95,z),(12,5.95,z),0.06,'Steel',8)
    # access stairs and vertical climbing pipes
    o.stairs('Catwalk_stair_left',-8,15,2.6,8,0.8,0.55,'ConcreteLight')
    for x in (-4,4):
        o.cylinder(f'Climb_pipe_vertical_{x}',(x,0.2,18),(x,6.4,18),0.16,'PipeBlue',10)
        for y in (1,2,3,4,5):
            o.cylinder(f'Climb_pipe_grip_{x}_{y}',(x-0.32,y,18),(x+0.32,y,18),0.055,'Hazard',8)
    # overhead horizontal climb pipes
    for x in (-8,0,8):
        o.cylinder(f'Overhead_climb_pipe_{x}',(x,6.5,3),(x,6.5,21),0.16,'PipeBlue',10)
        for z in (5,9,13,17):
            o.cylinder(f'Pipe_hanger_{x}_{z}',(x,7.5,z),(x,6.5,z),0.07,'Steel',8)
    for z in (6,14,22):
        o.cylinder(f'Cross_pipe_{z}',(-15,7,z),(15,7,z),0.13,'Rust',10)
    # exterior lobby markings, stations, lamps
    o.box('Spawn_pad_outer',0,0.04,-13,5.6,0.12,5.6,'SteelDark')
    o.box('Spawn_pad_inner',0,0.13,-13,4.7,0.08,4.7,'Teal')
    o.box('Room_code_station_base',-8,1.0,-8.5,2.0,2.0,1.3,'SteelDark')
    o.box('Room_code_screen',-8,2.05,-7.82,1.45,0.85,0.08,'Purple',False)
    o.box('Room_code_station_top',-8,2.53,-8.5,2.2,0.12,1.45,'Steel')
    o.box('Color_station_base',8,1.0,-8.5,2.0,2.0,1.3,'SteelDark')
    o.box('Color_station_screen',8,2.05,-7.82,1.45,0.85,0.08,'Teal',False)
    o.box('Color_station_top',8,2.53,-8.5,2.2,0.12,1.45,'Steel')
    for x in (-13,13):
        o.cylinder(f'Courtyard_lamp_post_{x}',(x,0,-12),(x,4,-12),0.10,'Steel',8)
        o.box(f'Courtyard_lamp_head_{x}',x,4,-12,0.7,0.25,0.7,'Amber',False)
    # floor lane markings
    for x in (-14,-7,7,14):
        o.box(f'Warehouse_floor_lane_{x}',x,0.015,12,0.08,0.03,22,'Hazard',False)
    # wall-mounted signage blocks and vent grilles
    o.box('Rear_control_panel',0,2.8,26.75,4.5,2.1,0.18,'SteelDark')
    o.box('Rear_control_panel_display',0,3.2,26.63,2.4,0.9,0.08,'Teal',False)
    for x in (-12,-10,-8,8,10,12):
        o.box(f'Wall_vent_slats_{x}',x,6.1,26.78,1.0,0.12,0.08,'Steel',False)
    return o

def cold_storage():
    o=ObjBuilder('Cold_Storage')
    # room shell
    o.box('Cold_room_floor',0,-0.25,0,36,0.5,32,'IceDark')
    for x in (-18,18):
        o.box(f'Insulated_side_wall_{x}',x,4,0,0.6,8,32,'Frost')
        # wall ribs
        for z in range(-14,16,4):
            o.box(f'Wall_rib_{x}_{z}',x-0.32 if x<0 else x+0.32,4,z,0.15,8,0.22,'IceDark')
    o.box('Rear_insulated_wall',0,4,16,36,8,0.6,'Frost')
    o.box('Front_wall_left',-13,4,-16,10,8,0.6,'Frost')
    o.box('Front_wall_right',13,4,-16,10,8,0.6,'Frost')
    o.box('Loading_header',0,7.4,-16,16,1.2,0.7,'IceDark')
    # freezer door and frame at back
    o.box('Freezer_door_frame_left',-5,3,15.5,0.5,6,0.5,'Steel')
    o.box('Freezer_door_frame_right',5,3,15.5,0.5,6,0.5,'Steel')
    o.box('Freezer_door_header',0,6,15.5,10,0.5,0.5,'Steel')
    o.box('Freezer_bulkhead_door',0,3,15.3,9,5.7,0.35,'IceDark')
    o.box('Freezer_door_warning',0,6.2,15.05,4.2,0.35,0.08,'WarningRed',False)
    o.box('Freezer_control_panel',7.1,1.7,14.6,1.0,2.4,0.5,'SteelDark')
    o.box('Freezer_control_display',7.1,2.2,14.32,0.65,0.55,0.05,'Teal',False)
    # rack rows with shelves, braces, cargo
    for row,x in enumerate((-10,0,10)):
        for z in (-10,-3,4,11):
            for y in (1.4,3.1,4.8):
                o.box(f'Cold_rack_{row}_{z}_shelf_{y}',x,y,z,5.8,0.16,1.3,'SteelDark')
            for dx in (-2.7,2.7):
                o.box(f'Cold_rack_{row}_{z}_upright_{dx}',x+dx,3.1,z,0.18,6.2,0.18,'PipeBlue')
            for y in (2.0,3.7):
                o.box(f'Cold_cargo_{row}_{z}_{y}',x,y,z,4.6,0.95,1.0,'Ice')
                o.box(f'Cold_cargo_strap_{row}_{z}_{y}',x,y,z-0.52,4.65,0.06,0.06,'Hazard',False)
    # accessible cross aisle and work line near entrance
    o.box('Packing_conveyor_base',0,0.7,-12,12,1.4,2.0,'SteelDark')
    o.box('Packing_conveyor_belt',0,1.45,-12,12.3,0.14,2.15,'Rubber')
    for x in np.arange(-5.5,6,1.5):
        o.cylinder(f'Conveyor_roller_{x}',(x,1.37,-13),(x,1.37,-11),0.09,'Steel',8)
    o.box('Packing_terminal',-8,1.2,-12,1.3,2.4,1.0,'SteelDark')
    o.box('Packing_terminal_screen',-8,1.8,-11.45,0.9,0.75,0.08,'Teal',False)
    # insulated pallets / crates
    for i,(x,z) in enumerate([(-14,7),(14,8),(-14,-7),(14,-8),(-4,-7),(4,7)]):
        o.box(f'Ice_crate_{i}',x,0.8,z,2.0,1.6,1.8,'IceDark')
        o.box(f'Ice_crate_lid_{i}',x,1.65,z,2.1,0.12,1.9,'Frost')
    # overhead coolant lines, brackets and drops
    for x in (-13,-4,4,13):
        o.cylinder(f'Coolant_main_pipe_{x}',(x,7,-14),(x,7,13),0.20,'PipeBlue',12)
        for z in (-10,-4,2,8,12):
            o.cylinder(f'Coolant_pipe_hanger_{x}_{z}',(x,7.7,z),(x,7,z),0.07,'Steel',8)
    for z in (-8,0,8):
        o.cylinder(f'Coolant_cross_pipe_{z}',(-16,6.8,z),(16,6.8,z),0.14,'IceDark',10)
    # overhead catwalk over rear cross aisle
    o.box('Cold_catwalk_deck',0,4.7,12,18,0.4,2.2,'SteelDark')
    for x in np.arange(-9,10,2):
        o.cylinder(f'Cold_catwalk_post_{x}',(x,4.9,10.8),(x,5.9,10.8),0.05,'Hazard',8)
        o.cylinder(f'Cold_catwalk_post_back_{x}',(x,4.9,13.2),(x,5.9,13.2),0.05,'Hazard',8)
    o.cylinder('Cold_catwalk_rail_front',(-9,5.85,10.8),(9,5.85,10.8),0.06,'Steel',8)
    o.cylinder('Cold_catwalk_rail_back',(-9,5.85,13.2),(9,5.85,13.2),0.06,'Steel',8)
    # floor markings and entry lights
    for x in (-16,-6,6,16):
        o.box(f'Cold_aisle_marker_{x}',x,0.02,-1,0.06,0.03,28,'Hazard',False)
    for x in (-12,0,12):
        o.box(f'Ceiling_light_{x}',x,7.85,-14,2.2,0.12,0.5,'Amber',False)
    return o

def maintenance():
    o=ObjBuilder('Maintenance_Tunnels')
    # central pump chamber (open top blockout) and floors
    o.box('Pump_chamber_floor',0,-0.25,0,18,0.5,18,'ConcreteDark')
    # Four branch corridors, each connected to center at the chamber edges.
    # North/south run along Z; east/west run along X.
    for sign,label in ((1,'North'),(-1,'South')):
        zc=sign*17
        o.box(f'{label}_tunnel_floor',0,-0.22,zc,8,0.44,20,'Concrete')
        for x in (-4.2,4.2):
            o.box(f'{label}_tunnel_wall_{x}',x,3,zc,0.4,6,20,'ConcreteDark')
        for z in (sign*9,sign*15,sign*21,sign*25):
            o.box(f'{label}_tunnel_ceiling_rib_{z}',0,5.8,z,8.5,0.35,0.35,'SteelDark')
        o.cylinder(f'{label}_main_pipe',( -2.4,5.0,sign*8),(-2.4,5.0,sign*26),0.18,'PipeBlue',10)
        o.cylinder(f'{label}_side_pipe',(2.4,4.8,sign*8),(2.4,4.8,sign*26),0.13,'Rust',10)
        # wall rungs on one side of each corridor
        x= -3.86 if sign>0 else 3.86
        for z in range(10,27,2):
            o.cylinder(f'{label}_wall_rung_{z}',(x,1.2,sign*z),(x,2.8,sign*z),0.055,'Hazard',8)
    for sign,label in ((1,'East'),(-1,'West')):
        xc=sign*17
        o.box(f'{label}_tunnel_floor',xc,-0.22,0,20,0.44,8,'Concrete')
        for z in (-4.2,4.2):
            o.box(f'{label}_tunnel_wall_{z}',xc,3,z,20,6,0.4,'ConcreteDark')
        for x in (sign*9,sign*15,sign*21,sign*25):
            o.box(f'{label}_tunnel_ceiling_rib_{x}',x,5.8,0,0.35,0.35,8.5,'SteelDark')
        o.cylinder(f'{label}_main_pipe',(sign*8,5.0,-2.4),(sign*26,5.0,-2.4),0.18,'PipeBlue',10)
        o.cylinder(f'{label}_side_pipe',(sign*8,4.8,2.4),(sign*26,4.8,2.4),0.13,'Rust',10)
        z= -3.86 if sign>0 else 3.86
        for x in range(10,27,2):
            o.cylinder(f'{label}_wall_rung_{x}',(sign*x,1.2,z),(sign*x,2.8,z),0.055,'Hazard',8)
    # Pump tanks and platforms in central room
    for i,(x,z) in enumerate([(-5,-5),(5,-5),(-5,5),(5,5)]):
        o.box(f'Pump_tank_plinth_{i}',x,0.45,z,3.0,0.9,3.0,'SteelDark')
        o.cylinder(f'Pump_tank_body_{i}',(x,0.9,z),(x,4.2,z),1.05,'PumpGreen',12)
        o.cylinder(f'Pump_tank_top_{i}',(x,4.2,z),(x,4.55,z),1.13,'Steel',12)
        o.cylinder(f'Pump_tank_pipe_{i}',(x,4.55,z),(x,5.5,z),0.18,'PipeBlue',10)
    o.box('Central_pump_service_island',0,0.55,0,5.4,1.1,3.2,'SteelDark')
    o.box('Central_pump_control_panel',0,1.55,-1.75,2.8,1.6,0.25,'Steel')
    o.box('Central_pump_control_screen',0,1.9,-1.91,1.5,0.65,0.07,'Teal',False)
    # central overhead pipe crossings
    for y,mat in ((5.7,'PipeBlue'),(6.4,'Rust')):
        o.cylinder(f'Central_overhead_pipe_x_{y}',(-8,y,0),(8,y,0),0.16,mat,10)
        o.cylinder(f'Central_overhead_pipe_z_{y}',(0,y,-8),(0,y,8),0.16,mat,10)
    # maintenance catwalk perimeter edges and short raised routes
    for z in (-7,7):
        o.box(f'Pump_room_side_platform_{z}',0,2.1,z,10,0.35,1.5,'SteelDark')
    # grates along branch center lines
    for sign,label in ((1,'N'),(-1,'S')):
        for z in range(12,27,5):
            o.box(f'Drain_grate_{label}_{z}',0,0.04,sign*z,2.3,0.08,1.0,'SteelDark')
    for sign,label in ((1,'E'),(-1,'W')):
        for x in range(12,27,5):
            o.box(f'Drain_grate_{label}_{x}',sign*x,0.04,0,1.0,0.08,2.3,'SteelDark')
    # service crates and warning panels in branch ends
    for i,(x,z) in enumerate([(0,26),(0,-26),(26,0),(-26,0)]):
        o.box(f'Branch_service_crate_{i}',x,0.55,z,1.8,1.1,1.8,'Wood')
        o.box(f'Branch_end_marker_{i}',x,3.8,z,2.0,0.6,0.15,'Hazard',False)
    # lamps and wall fixtures
    for x,z in [(0,0),(0,12),(0,-12),(12,0),(-12,0)]:
        o.cylinder(f'Utility_lamp_drop_{x}_{z}',(x,5.6,z),(x,5.0,z),0.05,'Steel',8)
        o.box(f'Utility_lamp_{x}_{z}',x,4.9,z,0.8,0.18,0.5,'Amber',False)
    return o

maps=[warehouse(),cold_storage(),maintenance()]
summary={}
for m in maps:
    summary[m.name]=m.save()
print(json.dumps(summary,indent=2))
